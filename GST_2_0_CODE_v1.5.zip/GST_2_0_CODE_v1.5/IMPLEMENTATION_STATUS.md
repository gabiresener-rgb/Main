# Implementation status — GST 2.0 Code v1.5

## Implemented and regression-tested

- unlimited registry-driven slot/source count; no hardcoded 23 ceiling;
- canonical Offset sweep `-5..+5`, fixed negative/zero/positive semantics;
- five-child-order replay, BAD/TP1..TP5 completed-only quality taxonomy;
- unresolved open positions retained in financial expectancy/equity by horizon MTM;
- Bid/Ask execution sides, first executable gap-stop fill, adverse slippage;
- broker-side initial/modified stop-distance checks;
- tick normalization and effective SL/TP/RR recomputation;
- explicit nominal vs effective export fields;
- pool-R, weighted order-R sum, account-currency modeled PnL;
- synchronous timestamp-group portfolio MTM drawdown plus separate close-event DD;
- full source→built→replay→financial denominator accounting;
- open-order, build-diagnostic and replay-error ledgers;
- equal-symbol primary selection, cross-symbol OOS gates, robustness/Pareto;
- practical-equivalence CI with time-cluster moving-block bootstrap;
- train/selection/WF/final-holdout full-lifetime barriers;
- WF final fold capped by the external final-holdout boundary;
- immutable selected-config lock before holdout;
- execution evidence fail-closed against artifact/data/model fingerprints;
- production gates cannot be disabled;
- strict production instrument-spec loading;
- code/spec/registry/input/evidence fingerprints in lineage;
- MT5 bootstrap fail-closed on export/tick failures; production frozen-export rule.

## Still external before real production use

1. real source/slot mappings and provider hashes;
2. MQL5 compilation and target-terminal runtime test;
3. provider streaming/repaint/closed-bar/MTF evidence;
4. broker/EA execution reconciliation and account-currency PnL comparison;
5. broker-specific time-varying contract/conversion details where a constant value coefficient is not exact;
6. validated real observation/expiry horizon for every TF used;
7. new untouched forward period after code/methodology freeze.

The known historical failed period remains a regression benchmark, not a pristine holdout.

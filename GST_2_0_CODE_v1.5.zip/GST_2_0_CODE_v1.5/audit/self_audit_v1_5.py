from __future__ import annotations

import copy
import hashlib
import json
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

import yaml

from gst2.audit.pre_gst import run_pre_gst_audit
from gst2.config import DEFAULT_CONFIG, load_config
from gst2.domain.models import CausalityStatus, Direction, InstrumentSpec, JointCandidate, MarketPoint, OffsetScenario, RawEpisode, SignalSeed
from gst2.metrics.core import mark_to_market_drawdown, summarize_replayed
from gst2.replay.five_order import ExecutionModelError, ExecutionPolicy, replay_episode
from gst2.service import _execution_ledger_rows
from gst2.validate.evidence import load_execution_reconciliation
from gst2.validate.splits import expanding_walk_forward


def check(name, fn, results):
    try:
        details = fn()
        results.append({"check": name, "status": "PASS", "details": details})
    except Exception as exc:
        results.append({"check": name, "status": "FAIL", "error": f"{type(exc).__name__}: {exc}"})


def seed(i, hour):
    t=datetime(2026,1,1,hour,tzinfo=timezone.utc)
    return SignalSeed(f'S{i}', '1','FOREX','EURUSD','H1',Direction.BUY,t,provider_hash='PH',source_channel='BUY_BUFFER')


def episode(direction, prices, sid):
    t=datetime(2026,1,1,tzinfo=timezone.utc)
    sd=SignalSeed(sid,'1','FOREX','EURUSD','H1',direction,t,provider_hash='PH',source_channel='BUY_BUFFER' if direction is Direction.BUY else 'SELL_BUFFER')
    sc=OffsetScenario(sid,0,t,t,t,100.0,t,CausalityStatus.STANDARD_CAUSAL,True)
    pts=tuple(MarketPoint(t+timedelta(minutes=i),p,p) for i,p in enumerate(prices))
    return RawEpisode(sid+'|0',sd,sc,pts[-1].ts,pts)


def main(out_path: str):
    results=[]

    def evidence_fail_closed():
        with tempfile.TemporaryDirectory() as td:
            td=Path(td); art=td/'artifact.csv'; art.write_text('x\n',encoding='utf-8')
            data={"evidence_id":"E","evidence_hash":"0"*64,"evidence_path":art.name,"pass":True,"matched_trade_count":0,"max_price_error_ticks":0,"max_time_error_seconds":0,"max_account_pnl_error":0,"data_fingerprint":"a"*64,"execution_model_fingerprint":"b"*64}
            p=td/'e.json'; p.write_text(json.dumps(data),encoding='utf-8')
            r,_=load_execution_reconciliation(str(p),expected_data_fingerprint='a'*64,expected_execution_model_fingerprint='b'*64,min_matched_trade_count=1,allowed_max_account_pnl_error=0)
            assert r['claimed_pass'] is True and r['pass'] is False and r['artifact_hash_verified'] is False
            return {"claimed_pass":r['claimed_pass'],"computed_pass":r['pass']}
    check('execution_evidence_fail_closed',evidence_fail_closed,results)

    def wf_outer_boundary():
        b=datetime(2026,1,1,16,tzinfo=timezone.utc)
        f=expanding_walk_forward([seed(i,i) for i in range(16)],4,0.4,outer_end_exclusive=b)
        assert f and f[-1].test_end_exclusive==b and all(x.test_end_exclusive<=b for x in f)
        return {"folds":len(f),"last_test_end":f[-1].test_end_exclusive.isoformat()}
    check('walk_forward_final_holdout_barrier',wf_outer_boundary,results)

    def open_loss_accounted():
        c=JointCandidate(0,0.35,(0.4,0.7,1.2,2,3)); p=ExecutionPolicy(default_tick_size=.00001)
        w=replay_episode(episode(Direction.BUY,[100,101.2],'W'),c,p)
        l=replay_episode(episode(Direction.BUY,[100,99.8],'L'),c,p)
        m=summarize_replayed(c,[w,l],source_signal_count=2,built_episode_count=2)
        assert l.open_orders and l.pool_unrealized_R<0 and m.financial_episode_count==2
        assert abs(m.pool_net_R-(w.pool_R+l.pool_R))<1e-12
        return {"completed":m.episode_count,"financial":m.financial_episode_count,"open_loss_pool_R":l.pool_R,"total_pool_R":m.pool_net_R}
    check('unresolved_open_loss_in_economics',open_loss_accounted,results)

    def atomic_mtm():
        c=JointCandidate(0,1.0,(2,3,4,5,6)); p=ExecutionPolicy(default_tick_size=.01)
        b=replay_episode(episode(Direction.BUY,[100,100.5,100],'B'),c,p)
        s=replay_episode(episode(Direction.SELL,[100,100.5,100],'S'),c,p)
        dd=mark_to_market_drawdown([], [b,s])
        assert abs(dd)<1e-12
        return {"drawdown_R":dd}
    check('synchronous_mtm_update',atomic_mtm,results)

    def bid_side_stop():
        t=datetime(2026,1,1,tzinfo=timezone.utc)
        sd=SignalSeed('S','1','FOREX','EURUSD','H1',Direction.BUY,t,provider_hash='PH',source_channel='BUY_BUFFER')
        sc=OffsetScenario('S',0,t,t,t,100,t,CausalityStatus.STANDARD_CAUSAL,True)
        e=RawEpisode('S|0',sd,sc,t,(MarketPoint(t,99.8,100.0),))
        c=JointCandidate(0,.30,(1,1.5,2,2.5,3)); spec=InstrumentSpec('EURUSD',tick_size=.1,stops_level_price=.2,spec_id='T')
        try:
            replay_episode(e,c,ExecutionPolicy(instrument_specs={'EURUSD':spec},require_instrument_specs=True))
        except ExecutionModelError:
            return {"rejected":True}
        raise AssertionError('invalid BUY stop was accepted')
    check('initial_stop_uses_exit_side_quote',bid_side_stop,results)

    def immutable_production_gates():
        with tempfile.TemporaryDirectory() as td:
            cfg=copy.deepcopy(DEFAULT_CONFIG); cfg['run_mode']='PRODUCTION'
            cfg['execution_policy'].update(require_instrument_specs=True,require_account_economics=True,instrument_specs_csv='i.csv',observation_horizon_bars={tf:48 for tf in ('M15','M30','H1','H4','D1','W1')})
            cfg['input_validation']['slot_registry_csv']='s.csv'
            cfg['validation']['external_evidence'].update(provider_equivalence_csv='p.csv',execution_reconciliation_json='e.json',max_account_pnl_error=.01)
            cfg['validation']['production_gates']['require_holdout']=False
            p=Path(td)/'c.yaml'; p.write_text(yaml.safe_dump(cfg,sort_keys=False),encoding='utf-8')
            try: load_config(str(p))
            except ValueError as exc:
                assert 'cannot disable mandatory gate' in str(exc); return {"rejected":True}
            raise AssertionError('production accepted disabled mandatory gate')
    check('production_gates_immutable',immutable_production_gates,results)

    def nominal_effective_export():
        c=JointCandidate(0,.37,(.4,.8,1.2,2,3)); spec=InstrumentSpec('EURUSD',tick_size=.1,spec_id='R')
        r=replay_episode(episode(Direction.BUY,[100,101.5],'R'),c,ExecutionPolicy(instrument_specs={'EURUSD':spec},require_instrument_specs=True))
        row=_execution_ledger_rows([r],'AUDIT')[0]
        assert row['nominal_target_R']!=row['effective_target_R'] and row['nominal_sl_pct']!=row['effective_sl_pct']
        return {k:row[k] for k in ('nominal_target_R','effective_target_R','nominal_sl_pct','effective_sl_pct','target_price')}
    check('nominal_effective_output_separated',nominal_effective_export,results)

    def mql_bridge_static():
        q=Path(__file__).resolve().parents[1]/'mt5/Experts/SMD/GST/GST_MT5_Bridge.mq5'
        s=q.read_text(encoding='utf-8')
        assert 'const int SIGNAL_COLUMNS=19;' in s
        assert 'bool GstExportTicksCsv()' in s and 'bootstrap EXPORT FAILED' in s
        pos=s.index('CopyTicksRange failed')
        assert 'export_ok=false;' in s[pos:pos+500]
        assert 'slot limit=NONE' in s and 'NO MAX_SLOTS' in s
        return {"bridge_sha256":hashlib.sha256(q.read_bytes()).hexdigest()}
    check('mt5_bridge_fail_closed_static',mql_bridge_static,results)

    payload={"version":"GST 2.0 Code v1.5","generated_utc":datetime.now(timezone.utc).isoformat(),"checks":results,"passed":sum(x['status']=='PASS' for x in results),"failed":sum(x['status']=='FAIL' for x in results)}
    Path(out_path).write_text(json.dumps(payload,indent=2,ensure_ascii=False),encoding='utf-8')
    if payload['failed']:
        raise SystemExit(1)
    print(json.dumps(payload,indent=2,ensure_ascii=False))

if __name__=='__main__':
    import sys
    main(sys.argv[1] if len(sys.argv)>1 else 'SELF_AUDIT_RESULTS_v1.5.json')

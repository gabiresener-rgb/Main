from __future__ import annotations
import hashlib, json, shutil
from datetime import datetime, timedelta, timezone
from pathlib import Path
import pandas as pd, yaml

from gst2.config import load_config
from gst2.service import _code_fingerprint, _sha256_file, _sha256_json, run_from_files

ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT/'audit'/'synthetic_production_smoke'
if WORK.exists(): shutil.rmtree(WORK)
WORK.mkdir(parents=True)

start=datetime(2026,1,1,tzinfo=timezone.utc)
bars=[]; ticks=[]
for h in range(400):
    t=start+timedelta(hours=h)
    px=100.0+0.08*h
    bars.append(dict(symbol='EURUSD',timeframe='H1',open_time=t.isoformat().replace('+00:00','Z'),open=px,high=px+.10,low=px-.05,close=px+.08))
    ticks.append(dict(symbol='EURUSD',timestamp=t.isoformat().replace('+00:00','Z'),bid=px,ask=px+.01))
pd.DataFrame(bars).to_csv(WORK/'bars_input.csv',index=False)
pd.DataFrame(ticks).to_csv(WORK/'ticks_input.csv',index=False)

signals=[]
for i in range(40):
    h=30+i*8; t=start+timedelta(hours=h)
    signals.append(dict(signal_id=f'S{i:03d}',slot_id='1',asset_group='FOREX',symbol='EURUSD',timeframe='H1',direction='BUY',signal_time=t.isoformat().replace('+00:00','Z'),provider_version='TEST1',provider_hash='PH_SYNTH',source_channel='BUY_BUFFER',offset_semantics_id='canonical_earlier_negative_later_positive_v1'))
pd.DataFrame(signals).to_csv(WORK/'signals_input.csv',index=False)

pd.DataFrame([dict(symbol='EURUSD',tick_size=.01,stops_level_price=0,freeze_level_price=0,slippage_price=0,commission_per_order_account=.01,swap_per_order_account=0,swap_long_per_day_account=0,swap_short_per_day_account=0,rollover_hour_utc=0,triple_swap_weekday=2,value_per_price_unit_per_unit=1,order_units=1,account_currency='USD',spec_id='SYNTH_V1')]).to_csv(WORK/'instrument_specs.csv',index=False)

pd.DataFrame([dict(enabled=1,slot_id='1',slot_name='Synthetic',provider_type='DUAL_BUFFER',indicator_path='SyntheticAdapter',handle_timeframe='H1',signal_timeframe='H1',buy_buffer=0,sell_buffer=1,direction_buffer=-1,buy_value=1,sell_value=-1,emit_on_change=0,symbols='EURUSD',live_buffer_shift=1,provider_version='TEST1',provider_hash='PH_SYNTH',horizon_bars=6)]).to_csv(WORK/'slot_registry.csv',index=False)

provider_art=WORK/'provider_artifact.txt'; provider_art.write_text('synthetic provider equivalence evidence',encoding='utf-8')
provider_hash=hashlib.sha256(provider_art.read_bytes()).hexdigest()
pd.DataFrame([dict(slot_id='1',symbol='EURUSD',timeframe='H1',provider_hash='PH_SYNTH',window_start='2025-12-01T00:00:00Z',window_end='2027-01-01T00:00:00Z',streaming_equivalence_pass=True,closed_bar_pass=True,repaint_test_pass=True,mtf_availability_pass=True,evidence_id='PE_SYNTH',evidence_hash=provider_hash,evidence_path=provider_art.name)]).to_csv(WORK/'provider_equivalence.csv',index=False)

cfg={
 'schema_version':'1.6.0','run_mode':'PRODUCTION',
 'scope':{'slots':['1'],'asset_groups':['FOREX'],'timeframes':['H1'],'symbols':['EURUSD']},
 'offset_search':{'full_sweep_min':-5,'full_sweep_max':5,'full_sweep_step':1,'causality_evidence':None},
 'joint_search':{
   'sl':{'min_pct':.25,'max_pct':.35,'coarse_step_pct':.05,'refine_step_pct':.05},
   'rr_ladder':{'min_R':.4,'max_R':.8,'coarse_step_R':.1,'refine_step_R':.1,'min_separation_R':.1,'legacy_ladder_R':[.4,.5,.6,.7,.8]},
   'max_coarse_ladders_per_sl':20,'refinement_seed_count':3,'refinement_passes':1,'min_episodes':8,
   'scope_overrides':{'FOREX:H1':{'sl':{'min_pct':.25,'max_pct':.35,'coarse_step_pct':.05,'refine_step_pct':.05}}},
   'boundary_expansion':{'enabled':False,'max_rounds':0,'expansion_factor':1.5,'sl_floor_pct':.05,'sl_ceiling_pct':20,'rr_floor_R':.05,'rr_ceiling_R':12,'expand_rr':True,'fail_if_unresolved':False}},
 'execution_policy':{'order_weights':[1,1,1,1,1],'modified_stop_profit_pct':.10,'cost_R_per_weight':0,'fill_model':'FIRST_EXECUTABLE_QUOTE','require_instrument_specs':True,'require_account_economics':True,'instrument_specs_csv':'instrument_specs.csv','default_tick_size':.00001,'observation_horizon_bars':{tf:6 for tf in ['M15','M30','H1','H4','D1','W1']}},
 'validation':{
   'final_holdout_fraction':.20,'selection_oos_fraction':.15,'selection_candidates_per_offset':2,
   'walk_forward':{'enabled':True,'folds':2,'min_train_fraction':.40,'min_positive_fold_share':.50,'require_positive_aggregate_oos':True},
   'robustness':{'min_neighbors':1,'min_neighbor_expectancy_ratio':.50,'max_neighbor_dd_ratio':3.0,'min_profitable_neighbor_share':.50,'min_worst_neighbor_expectancy_R':-.1,'min_positive_symbol_share':1.0,'expectancy_equivalence_abs_R':.05,'equivalence_bootstrap_samples':100,'equivalence_alpha':.05},
   'external_evidence':{'provider_equivalence_csv':'provider_equivalence.csv','execution_reconciliation_json':'execution_reconciliation.json','min_matched_trade_count':10,'max_price_error_ticks':0,'max_time_error_seconds':0,'max_account_pnl_error':0},
   'production_gates':{'require_walk_forward':True,'require_holdout':True,'require_robust':True,'require_cross_symbol':True,'require_boundary_resolved':True,'require_zero_execution_invalid':True,'require_zero_replay_errors':True,'max_excluded_episode_share':.35,'max_unresolved_episode_share':.35}},
 'input_validation':{'slot_registry_csv':'slot_registry.csv','allow_non_mt5_input':True},
 'storage':{'persist_full_surface':False}}
(WORK/'production.yaml').write_text(yaml.safe_dump(cfg,sort_keys=False),encoding='utf-8')
merged=load_config(str(WORK/'production.yaml'))
input_hashes={k:_sha256_file(WORK/f'{k}_input.csv') for k in ('signals','bars','ticks')}
data_fp=_sha256_json(input_hashes)
spec_hash=_sha256_file(WORK/'instrument_specs.csv')
model_fp=_sha256_json({'execution_policy':merged['execution_policy'],'instrument_specs_hash':spec_hash,'code_fingerprint':_code_fingerprint()})
exec_art=WORK/'execution_artifact.csv'; exec_art.write_text('synthetic independent execution reconciliation\n',encoding='utf-8')
exec_hash=hashlib.sha256(exec_art.read_bytes()).hexdigest()
(WORK/'execution_reconciliation.json').write_text(json.dumps({'evidence_id':'ER_SYNTH','evidence_hash':exec_hash,'evidence_path':exec_art.name,'pass':True,'matched_trade_count':40,'max_price_error_ticks':0,'max_time_error_seconds':0,'max_account_pnl_error':0,'data_fingerprint':data_fp,'execution_model_fingerprint':model_fp},indent=2),encoding='utf-8')

out=WORK/'out'
result=run_from_files(signals=str(WORK/'signals_input.csv'),bars=str(WORK/'bars_input.csv'),ticks=str(WORK/'ticks_input.csv'),config=str(WORK/'production.yaml'),out=str(out))
summary={'scope_count':len(result['scopes']),'statuses':[x.get('final_validation_status') for x in result['scopes']],'out':str(out)}
(WORK/'SMOKE_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))

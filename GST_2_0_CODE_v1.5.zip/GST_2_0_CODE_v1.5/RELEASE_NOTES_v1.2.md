# GST 2.0 Code v1.2 — Release Notes

## Added
- Mandatory explicit initial SL search bounds for all 30 `AssetGroup × TF` scopes.
- Automatic SL/RR search-boundary detection and expansion.
- Up to 3 default expansion rounds with factor 1.5.
- Hard search safety limits: SL 0.05%..20.00%, RR 0.05R..12.00R.
- `SEARCH_BOUNDARY_HIT_UNRESOLVED` production blocker.
- Boundary history and final bounds in Offset summaries and final result artifacts.

## Preserved
- TFs: M15/M30/H1/H4/D1/W1.
- Offsets: -5..+5.
- Joint `Offset × SL × RR1..RR5` optimization.
- Five-order pool, BAD/TP1..TP5=100%, BE+0.1% execution ledger.
- Negative Offset causality gate.
- Dynamic slot registry (no 23-slot hard limit).

## Verification
- pytest: 35/35 PASS.
- compileall: PASS.
- production example config validation: PASS.

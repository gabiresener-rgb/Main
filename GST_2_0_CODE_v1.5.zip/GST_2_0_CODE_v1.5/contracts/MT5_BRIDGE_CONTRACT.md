# GST MT5 Bridge Contract v1.3

Bridge обязан экспортировать `signals.csv`, `bars.csv`, `ticks.csv`, `bridge_manifest.csv` и работать от dynamic slot registry без hardcoded slot limit.

Для production provider mapping обязан содержать реальный `provider_hash`; signals.csv переносит этот hash вместе с `source_channel`. Closed-bar semantics: `live_buffer_shift >= 1`. Generic bridge требует `handle_timeframe == signal_timeframe`; сложный MTF источник подключается через отдельный adapter.

Экспорт с `bootstrap_status=FAILED`, provider construction failures, tick export failure, source-channel/direction mismatch, пустым provider hash или неполным market-data coverage является блокером. Live signal polling без синхронного bars/ticks refresh не является production historical evidence; такие данные должны пройти отдельную frozen-export validation.

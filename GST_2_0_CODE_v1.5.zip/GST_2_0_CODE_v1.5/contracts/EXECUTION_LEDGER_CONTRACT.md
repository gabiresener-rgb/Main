# GST 2.0 Execution Ledger Contract v1.5

A `SignalEpisode` contains exactly five child orders. DEVELOPMENT, SELECTION_OOS and FINAL_HOLDOUT are persisted separately.

## Closed-order ledger

Required identity/execution fields include sample, episode/signal/slot/source scope, direction/offset, source and entry timestamps, order index/weight, entry price, close time/price/reason, initial/active/modified SL, gross/cost/net R, account risk/PnL, instrument tick size and instrument-spec fingerprint.

Target and stop fields are explicit:

- `nominal_target_R`, `effective_target_R`;
- `nominal_target_pct`, `effective_target_pct`;
- `target_price`;
- `nominal_sl_pct`, `effective_sl_pct`.

No consumer may infer effective RR from nominal fields after tick normalization.

## Open-order ledger

Unresolved orders are not silently discarded. `open_order_ledger_*` stores mark time/price, nominal/effective target fields, current active SL, estimated close cost, mark-to-market R/account PnL, and episode residual open weight/risk.

## TradeEvent ledger

`trade_event_ledger_*` stores deterministic ENTRY, TP_HIT, STOP_MODIFIED, STOP_MODIFICATION_REJECTED, ORDER_CLOSE, stop-hit and unresolved-horizon events with time/price/order/level/R details.

## Diagnostics

`build_diagnostics_*` reconciles source signals to built/skipped episodes with reasons. `replay_errors_*` preserves candidate-specific replay failures. Summary denominators must reconcile source→built→replayed→financial/completed counts.

`MODIFIED_SL` is an execution close reason, not a seventh public outcome. `UNRESOLVED_TIMEOUT`, `INCOMPLETE_DATA`, `EXECUTION_INVALID` do not enter BAD/TP1..TP5 percentages.

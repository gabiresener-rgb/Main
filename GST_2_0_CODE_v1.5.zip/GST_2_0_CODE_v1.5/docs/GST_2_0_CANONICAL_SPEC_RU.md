% GST 2.0 Integrated Technical Documentation v1.5
% Canonical package for implementation
% 2026-09-25


# Назначение документа

Этот документ является объединённой канонической спецификацией GST 2.0 v1.5 для непосредственной реализации кода. Он объединяет актуальную пятиордерную модель, Joint `Offset × SL × RR1..RR5` оптимизацию, обязательный диапазон Offset `-5..+5`, безопасную causal-валидацию отрицательных Offset, Pre-GST audit и инженерные принципы donor backend v0.4. При конфликте с предыдущими пакетами настоящая версия имеет приоритет.

\newpage


\newpage

# 00 — Master Index and Authority

## 1. Purpose

GST 2.0 is a research and validation system for discovering **real, executable and robust** signal settings rather than maximizing a legacy `GOOD%` statistic. The system must reproduce the actual adviser execution model, test signal timing and risk/profit geometry, and reject historical artifacts that do not survive unseen data.

## 2. Authority hierarchy

1. This v1.5 canonical documentation.
2. Contracts and schemas shipped with v1.5.
3. Acceptance/traceability requirements.
4. Engineering reference v0.4 only where it does not conflict with 1–3.

No implementation decision may silently override the canonical model.

## 3. Canonical research grain

The primary analysis scope is:

`Slot × AssetGroup × Timeframe`

Within each scope GST explores:

`Offset[-5..+5] × SL × ordered(RR1..RR5)`

All eleven Offset values are tested independently. Negative values require causality classification before production promotion.

Cross-symbol analysis is used to determine whether a group-level configuration is stable. Per-symbol results remain available for diagnostics.

## 4. Canonical trading episode

One source signal creates one `SignalEpisode` containing five child orders. All five start from the same signal/entry and initial SL. Each child order is assigned TP1..TP5 respectively. After TP1, the remaining open orders receive the configured modified stop; the current canonical baseline is `BE +0.1% of entry price`.

## 5. Canonical signal-quality outcome

Exactly one:

- `BAD`
- `TP1`
- `TP2`
- `TP3`
- `TP4`
- `TP5`

The class is the **highest TP level reached before the active stop terminates further progression**. If the initial SL occurs before TP1, the result is permanently `BAD`.

The six classes are exhaustive and mutually exclusive. Aggregate percentage = 100%.

## 6. Separate execution truth

Execution outcomes are stored separately per child order:

- target close;
- initial SL close;
- modified stop `BE+0.1%` close;
- timeout/forced close if configured;
- broker/execution anomaly.

Execution truth produces pool P&L. It never creates extra signal-quality classes.

## 7. Required optimization outputs

Per `Slot × AssetGroup × TF`:

- complete Offset sweep `-5..+5`, causality status, robust Offset zone and selected Offset;
- robust SL zone and selected SL `%`;
- joint robust TP1..TP5/RR zones and selected five-level ladder;
- selected TP distances in `%` and `R`;
- BAD/TP1..TP5 distribution = 100%;
- five-order pool net result, expectancy and drawdown;
- cross-symbol stability;
- walk-forward results;
- final holdout result;
- execution ledger statistics, including `BE+0.1%` closes;
- legacy baseline comparison.

## 8. Core quality gates

No configuration can become production-validated unless:

- Pre-GST structural audit passes;
- signal/entry mapping is causal and reproducible; negative Offset must pass dedicated causality validation before production use;
- tick/Bid-Ask replay is used for final execution validation;
- Offset scenario is rebuilt, not reused;
- configuration is robust, not a single historical spike;
- walk-forward OOS passes;
- final holdout is consumed only after configuration lock;
- cross-symbol stability is acceptable for any group-level recommendation.

## 9. Legacy compatibility

The historical ladder `0.4R / 0.7R / 1.2R / 2R / 3R` is stored as `LEGACY_TP_LADDER`. It is a comparator only.

Legacy `GOOD%` may be preserved as `legacy_good_rate` for forensic comparison but cannot rank or validate candidates.


\newpage

# 01 — Canonical Product and Functional Requirements

## 1. Product goal

GST 2.0 must determine, for every registered slot and supported market scope, the most robust executable settings for signal timing, risk distance and five-target profit extraction.

The system is not a trading agent and does not automatically rewrite production indicator logic.

## 2. Mandatory supported dimensions

### 2.1 Slots

- dynamic registry;
- no `MAX_SLOTS` or hardcoded 22/23 limit;
- every result carries `slot_id` and provider version/hash.

### 2.2 Asset groups

- FOREX
- COMMODITIES
- CRYPTO
- INDICES
- STOCKS

### 2.3 Timeframes

Canonical GST 2.0 test set is fixed to **M15, M30, H1, H4, D1, W1**. MN1 and all other timeframes are outside the standard production test scope. A run may narrow this set for diagnostics, but production full-scope validation must use the six canonical TFs.

### 2.4 Symbols

Every signal and price record carries symbol. Group optimization must preserve per-symbol evidence.

## 3. Required optimization dimensions

For every `Slot × AssetGroup × TF`:

1. **Offset search** — mandatory full automatic sweep `-5..+5` inclusive; manual subset allowed only for diagnostics/debugging.
2. **Negative Offset causality** — `-1..-5` are diagnostic by default and require streaming/future-mutation/MTF validation for production eligibility.
3. **SL search** — explicit configurable grid/range in `% of entry price` and derived R-base.
4. **TP/RR ladder search** — exactly five strictly ordered RR levels; old values are baseline only.
5. **Joint optimization** — final candidate is the full `Offset × SL × RR1..RR5` tuple; independent SL/TP winners are forbidden.
6. **RR mapping** — every selected TP must be reported in `%` and as `TP_distance / SL_distance`.

### 3.1 Search-bound policy

Search bounds are not market constants. The run must explicitly persist the SL and RR bounds/steps used for each scope/profile. The example YAML values are illustrative only and cannot silently become production defaults.

## 4. Five-order pool

One episode opens five logical orders. For economic replay, actual order weights/lots must be supplied by configuration or execution ledger. Default test fixture may use equal weights, but production code must not assume equality if real adviser weights differ.

All five share the same initial SL for the selected scope/configuration.

## 5. Modified stop

Current adviser behavior to reproduce:

- TP1 hit closes order 1 at TP1;
- remaining open orders receive modified stop at `BE +0.1%` in profitable direction unless configuration specifies another production baseline;
- every modification is stored with timestamp, old stop, new stop and trigger event;
- every child-order close at modified SL is stored explicitly.

The modified stop is execution policy, not a signal-quality class.

## 6. Exclusive outcome classification

Each SignalEpisode must resolve to exactly one class:

`BAD | TP1 | TP2 | TP3 | TP4 | TP5`

Rules:

- initial SL before TP1 => BAD permanently;
- TP1 then modified stop before TP2 => TP1;
- TP2 then active stop before TP3 => TP2;
- etc.;
- TP5 hit => TP5;
- later price action after terminating stop cannot revise the class.

There is no `FIX` class.

## 7. Aggregate distribution

For every candidate and every final scope:

`BAD% + TP1% + TP2% + TP3% + TP4% + TP5% = 100%`

Allow only explicit floating-point rounding tolerance in presentation; counts must match exactly.

## 8. Final result row

Minimum canonical fields:

- slot_id
- asset_group
- timeframe
- selected_offset
- selected_offset_causality_status
- selected_offset_production_eligible
- offset_robust_zone
- selected_sl_pct
- sl_robust_zone_pct
- tp1_pct / tp1_R / tp1_zone
- tp2_pct / tp2_R / tp2_zone
- tp3_pct / tp3_R / tp3_zone
- tp4_pct / tp4_R / tp4_zone
- tp5_pct / tp5_R / tp5_zone
- bad_pct
- tp1_result_pct
- tp2_result_pct
- tp3_result_pct
- tp4_result_pct
- tp5_result_pct
- episode_count
- order_count
- modified_stop_close_count
- modified_stop_close_pct_of_orders
- pool_net_R
- pool_expectancy_R_per_episode
- pool_max_drawdown_R
- walk_forward_status
- holdout_status
- cross_symbol_status
- final_validation_status

## 9. Group optimization

Group-level statistics must not be dominated by symbols with more signals. Produce both:

- raw pooled statistics;
- equal-symbol-weighted statistics.

A group recommendation requires cross-symbol stability evidence.

## 10. Condition analysis

Signal-condition analysis is a **secondary stage**. It runs only after the core Offset/SL/TP search shows no satisfactory robust configuration or a controlled research task explicitly requests it.

Allowed first-stage logic research:

- threshold changes;
- one-condition ablation;
- limited pair-interaction checks.

No uncontrolled automatic generation of large rule sets, indicators or black-box strategies.

## 11. User interface requirements

The UI must support:

- run setup and validation status;
- asset group / slot / TF selection;
- standard Offset sweep `-5..+5`, negative-Offset causality status and manual diagnostic subset;
- SL search bounds;
- joint SL/RR search settings and TP ladder bounds;
- legacy baseline comparison;
- results matrix and robust zones;
- final selected configuration table;
- BAD/TP1..TP5 100% distribution;
- execution ledger with `BE+0.1%` filter;
- per-symbol stability view;
- walk-forward and holdout status;
- export of all canonical artifacts.

## 12. Non-goals

GST 2.0 core does not need:

- autonomous production trading;
- automatic rewriting of indicator source code;
- ML-generated opaque signal formulas;
- unrelated portfolio optimization;
- dozens of redundant performance scores.


\newpage

# 02 — Trading Domain Model and Replay Semantics

## 1. Entity hierarchy

### SignalSeed
Immutable source event exported from the real indicator/provider before GST execution assumptions are applied.

Required fields:
- signal_id
- slot_id
- provider_version/hash
- asset_group
- symbol
- timeframe
- direction
- signal_time
- source_channel/buffer
- raw metadata

### OffsetScenario
A complete historical-entry interpretation of the frozen SignalSeed.

Canonical full sweep is integer Offset `-5..+5`. Changing Offset must rebuild:
- entry bar/time;
- first executable tick;
- entry Bid/Ask side;
- SL absolute price;
- all TP absolute prices;
- subsequent path;
- all outcomes/metrics.

Nothing from another Offset scenario may be reused except the immutable SignalSeed. Every scenario also stores `source_signal_time`, `candidate_entry_time`, `data_cutoff_time`, `causality_mode`, `causality_status`, `production_eligible` and `causality_evidence_id`.

### SignalEpisode
Primary statistical unit: one signal under one candidate configuration.

Contains:
- SignalSeed reference;
- OffsetScenario;
- selected SL;
- ordered five-level TP ladder;
- five child orders;
- chronological event stream;
- final six-class outcome;
- pool economics.

### ChildOrder
Five orders indexed 1..5. Each maps to exactly one TP level.

### TradeEvent
Canonical event types:
- ENTRY
- TP_HIT
- STOP_MODIFIED
- INITIAL_SL_HIT
- MODIFIED_SL_HIT
- TIMEOUT_EXIT
- FORCED_EXIT
- DATA_AMBIGUITY

## 2. Bid/Ask execution

Minimum executable-price rule:

- BUY entry = Ask;
- SELL entry = Bid;
- BUY stop/target exit evidence = Bid;
- SELL stop/target exit evidence = Ask.

Any broker-specific deviation must be adapter/config driven and recorded.

## 3. Stop loss representation

Canonical optimization representation: `% of entry price`.

For BUY:
`SL_raw = entry * (1 - sl_pct / 100)`

For SELL:
`SL_raw = entry * (1 + sl_pct / 100)`

Exact broker rounding/tick-size normalization applies before replay.

`R` is the absolute entry-to-initial-SL price distance for that episode.

## 4. TP representation

Each TP is stored in both forms:

- `tp_i_pct`: absolute percentage distance from entry;
- `tp_i_R = tp_i_distance / initial_sl_distance`.

Ordering invariant:
`0 < TP1 < TP2 < TP3 < TP4 < TP5`

The old ladder is baseline only:
`[0.4R, 0.7R, 1.2R, 2.0R, 3.0R]`.

## 5. Modified stop BE+0.1%

After TP1 trigger:

BUY modified stop baseline:
`entry * (1 + 0.001)`

SELL modified stop baseline:
`entry * (1 - 0.001)`

Before applying, normalize to broker tick size and ensure the level is executable/legal relative to current Bid/Ask if production policy requires it.

Record for each remaining child order:
- trigger_time;
- trigger_price context;
- old_stop;
- new_stop;
- new_stop_pct_from_entry;
- new_stop_R;
- later close reason and close price;
- realized P&L.

## 6. Signal-class state machine

Initial state: `PRE_TP1`.

### If initial SL occurs before TP1
- close all still-open orders according to policy;
- signal outcome = `BAD`;
- outcome locked permanently.

### If TP1 occurs first
- close child 1 at TP1;
- set provisional highest TP = 1;
- modify stop for remaining eligible orders to BE+0.1%;
- continue chronological replay.

### If TP2 occurs before active stop
- close child 2;
- highest TP = 2;
- continue.

Repeat through TP5.

### If active stop occurs after TPk and before TP(k+1)
- close remaining orders using active stop policy;
- signal outcome = `TPk`.

### If TP5 occurs
- close child 5;
- outcome = `TP5`.

No later price path can revise a resolved outcome.

## 7. Same-tick/gap handling

With tick data, process timestamp order. If a single observed tick jumps across multiple target levels, target fills follow the configured broker fill model and all crossed TPs are considered reached at that executable instant. Persist the raw tick and applied fill rule.

If only OHLC data makes stop-vs-target ordering ambiguous, mark `AMBIGUOUS` internally and do not fabricate a favorable sequence. Final production validation requires tick-exact replay.

## 8. Statistical independence

Five child orders from one signal are **not five independent samples**.

Primary sample counts/confidence intervals use SignalEpisodes. Child-order counts are execution diagnostics only.

## 9. Offset semantics

Every provider must declare an `offset_semantics_id`.

Generic historical-bar convention may be:
- 0 = first causal entry bar associated with signal;
- positive = later;
- negative = earlier.

But provider-specific signal-buffer offsets may have different semantics. They must be documented and tested rather than inferred.

If an Offset yields entry before the source signal was knowable in real time, mark `causal_entry=false`; it may be research evidence but cannot receive production validation.


\newpage

# 03 — Analytical and Optimization Methodology

## 1. Principle

GST must not optimize a vague `GOOD%`. It must discover robust executable configurations over the complete joint tuple:

`Offset × SL × RR1 × RR2 × RR3 × RR4 × RR5`

and validate them out of sample.

## 2. Canonical pipeline

1. Pre-GST structural/end-to-end audit.
2. Freeze SignalSeeds.
3. Partition development / walk-forward / final holdout chronologically.
4. For each `Slot × AssetGroup × TF`:
   - test Offset values `-5..+5` inclusive;
   - rebuild entry/path independently for each Offset;
   - classify Offset causality;
   - for each Offset run joint SL/RR five-target search;
   - tick/Bid-Ask replay of five-order SignalEpisodes;
   - exclusive `BAD/TP1..TP5` distribution;
   - pool economics and modified-stop ledger;
   - robust-zone and Pareto analysis on complete tuples;
   - equal-symbol and per-symbol stability;
   - walk-forward OOS validation of production-eligible tuples;
   - lock final candidate;
   - one-time sealed final holdout evaluation.
5. Optional controlled condition analysis only if core search fails or negative diagnostic evidence reveals signal lateness that requires causal redesign.

## 3. Offset search: -5..+5

Full automatic runs test exactly these integer values:

`[-5,-4,-3,-2,-1,0,1,2,3,4,5]`.

Each Offset is a separate scenario. Entry time, first executable price, future path, SL/TP absolute levels and all results are recalculated. Nothing outcome-related is reused from another Offset.

### 3.1 Offset 0
Provider-defined canonical signal entry.

### 3.2 Positive Offset +1..+5
Delayed entry according to provider semantics. Still requires fresh entry/path replay.

### 3.3 Negative Offset -1..-5
Always starts as diagnostic unless provider causality validation proves the earlier signal/state was knowable at the candidate time.

Mandatory checks for production eligibility:
- streaming replay;
- future-mutation invariance;
- MTF closed-bar cutoff;
- provider-semantic equivalence;
- first executable Bid/Ask entry;
- `data_cutoff_time <= candidate_entry_time`.

Negative Offset with `NON_CAUSAL_DIAGNOSTIC` or `CAUSAL_FAIL` may inform signal redesign but is excluded from production candidate selection.

## 4. Joint SL/RR search

SL and TP/RR are not independent winners. The atomic candidate is:

`(offset, sl_pct, rr1, rr2, rr3, rr4, rr5)`.

For every Offset separately:
1. enumerate SL candidates from explicit configured bounds;
2. for each SL compute R-base after broker tick normalization;
3. generate legal ordered five-RR ladders from explicit configured bounds;
4. convert RR to target prices/% distances;
5. replay the full five-order episode;
6. persist outcome distribution and economics for the complete tuple.

## 5. SL search

Canonical representation is `% of entry price`. Bounds/steps are versioned run inputs and may vary by AssetGroup × TF. There is no hidden universal SL range.

For every SL candidate:
- convert to executable stop price;
- enforce tick size;
- compute R-base;
- recompute every TP from the ladder RR;
- recompute BE+0.1% in both price/% and R terms;
- replay every episode.

Outputs include the complete SL surface conditional on Offset and RR ladder, joint robust SL neighborhood and sensitivity.

## 6. Five-TP RR ladder search

### 6.1 Constraints
- exactly five targets;
- strictly ordered `0 < RR1 < RR2 < RR3 < RR4 < RR5`;
- explicit configurable min/max RR;
- explicit configurable minimum separation;
- search bounds may vary by AssetGroup × TF;
- legacy ladder not hardcoded as optimal.

### 6.2 How GST determines TP1..TP5

GST does not assign TP1 first and extrapolate the rest. It generates complete legal five-level ladders from the RR grid, replays the full adviser model, and compares the resulting complete tuples.

Deterministic search:
1. coarse ordered RR grid;
2. full replay of complete tuples;
3. discard invalid/dominated regions;
4. retain several connected robust neighborhoods;
5. dense local refinement in SL and RR dimensions;
6. walk-forward validation of complete tuples;
7. final holdout only after lock.

Legacy `0.4/0.7/1.2/2/3R` is always a comparator when legal under configured bounds.

## 7. Signal outcome distribution

For each complete candidate count episodes in exactly six groups:

`N_total = N_BAD + N_TP1 + N_TP2 + N_TP3 + N_TP4 + N_TP5`.

Percentages are `N_class / N_total * 100` and sum to 100% within display rounding only.

No FIX/BE class exists. Modified-stop exits remain execution events.

## 8. Pool economics

Aggregate realized P&L of all five child orders using configured/adviser weights and execution costs.

Minimum metrics:
- pool_net_R;
- pool_expectancy_R_per_episode;
- gross profit/loss;
- profit factor;
- max drawdown R;
- max losing streak by episode;
- episode count;
- execution-cost total;
- modified-stop close count and realized contribution.

`legacy_good_rate` is diagnostic only.

## 9. Pareto efficiency

Do not collapse profit/risk into an arbitrary weighted score.

Canonical efficiency dimensions include:
- maximize validated pool expectancy;
- minimize drawdown;
- prefer smaller SL only when the paired confidence interval is fully inside the predeclared practical-equivalence margin;
- preserve stable TP-depth distribution and ordered ladder;
- require production causality.

Dominated configurations are removed only among comparable production-eligible tuples.

## 10. Deterministic default selection

1. candidate passes structural/data/causality gates;
2. candidate is a robust complete tuple;
3. rank using walk-forward OOS economics/efficiency;
4. if practically equivalent by the predeclared CI margin, prefer smaller SL;
5. then prefer greater validated TP depth/ladder under the declared tie-break policy;
6. final deterministic tie-break by stable configuration ID.

Final holdout never participates in ranking.

## 11. Robust zones

Robustness is joint, not dimension-by-dimension cherry-picking. Evaluate local neighborhoods across Offset, SL and RR-ladder dimensions:
- local minimum/median expectancy;
- local dispersion;
- worst local drawdown;
- profitable-neighbor share;
- connected-region size;
- cross-symbol stability;
- causality eligibility.

Persist both dimension projections and the complete joint robust region.

## 12. Cross-symbol group analysis

Produce pooled, equal-symbol-weighted and per-symbol evidence. A group-level result is blocked if driven by a small minority of symbols under configured stability rules.

## 13. Walk-forward

Candidate discovery occurs only on training/development data. Each fold evaluates locked complete tuples on the next OOS window. Noncausal negative Offset diagnostics are excluded from production WF promotion.

## 14. Final holdout

1. choose and lock a complete configuration hash;
2. record the lock manifest;
3. evaluate once on sealed holdout;
4. store immutably.

If methodology changes after viewing the holdout, that period is no longer untouched for the revised methodology.

## 15. Known-forward-failure benchmark

The already-known demo loss period is a regression/forensic benchmark, not untouched holdout.

## 16. Condition analysis

Only after core search. Strong noncausal negative-Offset evidence is a valid trigger for controlled research into making the signal available earlier without future data.


\newpage

# 04 — Mandatory Pre-GST End-to-End Signal Execution Audit

## 1. Purpose

Before optimizing Offset, SL or TP, verify that GST is testing the **same source signals and executable direction/entry semantics** that the production adviser actually receives.

This capability is adopted from the v0.4 backend and is mandatory.

## 2. Audit scope

Per `Slot × AssetGroup × TF`:

- signal source mapping;
- BUY/SELL buffer/channel mapping;
- timestamps and timezone normalization;
- signal availability/closed-bar causality;
- MTF leakage check;
- Offset semantics;
- entry Bid/Ask side;
- SL/TP unit conversion;
- actual/demo ledger reconciliation when supplied;
- original versus inverted direction evidence;
- basic Signal Truth horizons and MFE/MAE evidence.

## 3. Root-cause statuses

Retain explicit categories where supported:
- MAPPING_ERROR
- OFFSET_ERROR
- UNIT_ERROR
- DIRECTION_INVERTED
- SIGNAL_INVALID
- SIGNAL_VALID_EXECUTION_BROKEN
- SL_TOO_TIGHT
- BE_TOO_AGGRESSIVE
- GST_READY_FOR_PARAMETER_RESEARCH

Additional statuses may be added, but meanings must be versioned.

## 4. Hard blocking

Structural errors block only the affected scope. Unaffected slots/groups/TFs may continue.

Examples of hard blockers:
- reversed BUY/SELL mapping;
- entry generated from future information;
- broken timezone alignment;
- incompatible price units;
- missing tick data required by configured final validation.

## 5. Direction inversion audit

Run original and inverted direction as **diagnostic research scenarios**, not as an automatic production correction.

The inversion must replay the complete five-order execution model, including SL, five TP ladder and modified stop, rather than negating final P&L algebraically.

A reversed direction may become a candidate only through a separately versioned provider/logic research cycle.

## 6. Execution reconciliation

When actual/demo order history exists, reconcile:
- signal_id/episode mapping;
- direction;
- expected/actual entry time;
- expected/actual entry price;
- initial SL;
- TP levels;
- TP1 trigger time;
- modified stop update to BE+0.1%;
- each child-order close reason and price;
- actual vs reconstructed P&L.

This is a release gate for production-equivalence claims.

## 7. Required artifacts

`PRE_GST_AUDIT/`
- `signal_truth_audit.csv`
- `source_mapping_audit.csv`
- `offset_entry_diagnostics.csv`
- `direction_inversion_audit.csv`
- `execution_reconciliation.csv` when ledger supplied
- `pre_gst_root_cause_summary.csv`
- `pre_gst_e2e_audit.json`


\newpage

# 05 — MT5 Bridge and Provider Contract

## 1. Principle

The bridge freezes **actual source signal events** from the installed indicators. GST must not reconstruct or invent a provider formula when the production indicator can supply canonical outputs.

## 2. Dynamic registry

The MT5 bridge loads slots from registry. No fixed slot-count loop.

Minimum slot registry fields:
- slot_id
- enabled
- provider_name
- indicator_path
- provider_version
- asset_group mapping rule
- timeframe support
- direction mode
- buy_buffer
- sell_buffer
- direction_buffer
- signal timestamp semantics
- offset_semantics_id
- provider_adapter_id optional

## 3. Frozen exports

### signals.csv
Minimum:
`signal_id,slot_id,asset_group,symbol,timeframe,direction,signal_time,source_channel,provider_version`

### bars.csv
`open_time,symbol,timeframe,open,high,low,close[,atr]`

### ticks.csv
`timestamp,symbol,bid,ask`

### metadata
- broker server timezone / UTC normalization rules;
- symbol digits/tick size;
- export version;
- indicator/provider hashes;
- data range and completeness.

## 4. Causality

Signals must identify whether they are confirmed on closed bars, current bars or MTF data. Final production-validated provider mappings must not use future-complete higher-timeframe values at an earlier timestamp.

## 5. Offset contract

The bridge/provider adapter must expose a deterministic definition of Offset. Full GST runs request all integer values `-5..+5`. Never infer executability from sign alone.

Fields:
- offset_semantics_id
- zero_offset_definition
- positive_offset_definition
- negative_offset_definition
- whether each candidate entry is causal
- source signal knowable timestamp
- candidate `data_cutoff_time`
- streaming replay support for negative Offset causality validation

## 6. Provider equivalence tests

For every enabled slot:
- compare MT5 visual/source events to bridge export;
- verify sample BUY and SELL events;
- verify timestamps;
- verify source_channel;
- verify absence of phantom/duplicate signals;
- verify closed-bar/current-bar semantics;
- verify MTF synchronization.

No slot becomes production-enabled until these tests pass.

## 7. Donor component

The v0.4 `GST_MT5_Bridge.mq5`, `providers/mt5_bridge.py` and registry approach are approved engineering donors. They must be adapted to the canonical v1.5 episode/output contracts rather than rewritten without reason.


\newpage

# 06 — Python System Architecture

## 1. Architectural goal

Deterministic, inspectable research engine able to process many `Slot × AssetGroup × TF` scopes without hiding analytical decisions.

## 2. Recommended process model

### API / Supervisor process
Responsibilities:
- validate run config;
- create immutable run manifest;
- launch/monitor jobs;
- manage checkpoints;
- serve progress/results;
- never perform heavy candidate replay inline.

### Worker pool
Spawn-based multiprocessing. Work units should be coarse enough to avoid IPC overhead, typically scope/candidate batches.

Responsibilities:
- Offset rebuild;
- SL/TP candidate replay;
- episode classification;
- pool economics;
- fold evaluation.

### Single storage writer
Workers return/write immutable batch artifacts; one controlled writer commits DuckDB metadata/status to avoid concurrent database corruption.

## 3. Canonical package layout

```text
gst2/
  api/
  cli/
  config/
  domain/
    signal.py
    episode.py
    order.py
    events.py
    result.py
  providers/
    mt5_bridge.py
    registry.py
    offset_semantics.py
  audit/
    pre_gst.py
    execution_reconcile.py
  replay/
    pricing.py
    path.py
    episode_engine.py
    broker_rules.py
  optimize/
    offset_search.py
    negative_offset_causality.py
    joint_optimizer.py
    sl_candidate_grid.py
    rr_ladder_grid.py
    pareto.py
    robustness.py
  validate/
    splits.py
    walk_forward.py
    holdout.py
    cross_symbol.py
  metrics/
    episode_metrics.py
    pool_metrics.py
  storage/
    artifacts.py
    duckdb_repo.py
    manifest.py
  reporting/
    tables.py
    serialize.py
```

## 4. Required implementation boundaries

### SignalProvider
Produces immutable SignalSeeds only.

### OffsetResolver
Converts SignalSeed + Offset (`-5..+5`) into an entry scenario and lineage. Does not assume negative Offset is causal.

### NegativeOffsetCausalityValidator
Runs streaming replay, future-mutation invariance, MTF cutoff and provider-semantic checks. Produces `causality_status` and `production_eligible`.

### JointOptimizer
Generates/evaluates complete `(offset, sl_pct, rr1..rr5)` tuples. Staged search is allowed internally, but ranking/robustness/validation operates on complete tuples.

### EpisodeReplayEngine
Only component allowed to determine chronological TP/SL/modified-stop execution and six-class outcome.

### Optimizers
Never inspect final holdout. They consume development/WF replay results.

### Validator
Locks selected config before holdout.

## 5. Replay performance

For each Offset scenario, price paths may be cached in a way that is independent of SL/TP choices, provided the cache contains raw chronological executable-side price evidence and cannot leak results from another Offset.

Vectorization is allowed for candidate screening, but final selected candidates must be reproducible by the canonical event-driven replay engine.

## 6. Determinism

Run manifest records:
- code git hash/build hash;
- provider hashes;
- config hash;
- data manifest hash;
- timezone rules;
- random/bootstrap seed;
- candidate grids;
- split boundaries;
- schema version.

Identical inputs/config must produce identical canonical outputs.

## 7. Storage

Recommended:
- Parquet/Arrow for large tick/episode/candidate tables;
- DuckDB for queryable metadata and analytical summaries;
- JSON for immutable manifests/selected configurations;
- CSV for human-inspectable canonical exports.

## 8. Resume/checkpoint

Production implementation must resume without recomputing completed immutable scopes/candidate blocks when hashes match. A changed config/provider/data hash invalidates dependent checkpoints.

## 9. Engineering donor reuse

Prefer adapting v0.4 implementations for:
- audit_e2e;
- offset provider;
- Bid/Ask pricing;
- tick path;
- MT5 bridge;
- execution ledger reconciliation;
- walk-forward split logic;
- artifact persistence;
- FastAPI/CLI structure.

Replace/supersede v0.4 target/allocation logic with the canonical five-level episode optimizer.


\newpage

# 07 — Data, API and Artifact Specification

## 1. Run identity

Every run has immutable `run_id`, `schema_version`, `config_hash`, `data_hash`, `code_hash`.

## 2. Canonical configuration objects

### ScopeConfig
- slots
- asset_groups
- symbols/filter
- timeframes
- date range

### OffsetSearchConfig
Required production sweep: `-5..+5` inclusive. Manual subset is diagnostic only unless run manifest records an approved exception.

Negative values require causality-validation configuration and evidence persistence.

### JointOptimizationConfig
Contains explicit SL bounds/steps, RR bounds/steps, target count=5, min RR separation, coarse/refine strategy and asset-group/TF overrides. No hidden universal bounds.
- semantics id
- candidate offsets
- manual override optional

### JointOptimizationConfig details
- SL min/max/coarse/refine step in `% of entry`;
- RR min/max/coarse/refine step;
- exactly five ordered targets;
- minimum RR separation;
- per AssetGroup/TF overrides;
- legacy ladder comparator.

Separate SL/TP tables are reporting projections only; they do not define independent selection paths.

### ExecutionPolicy
- child-order weights/lots
- initial SL source
- TP1 action
- modified stop offset percent (baseline 0.1%)
- commission/swap/slippage adapter
- timeout/forced-exit policy

### ValidationConfig
- development range
- walk-forward folds
- final holdout range
- robustness rules
- cross-symbol rules
- bootstrap settings

## 3. Canonical selected configuration JSON

Must include:
- scope identity;
- Offset + semantics + causality status + production eligibility + data cutoff;
- SL selected and robust zone;
- TP1..TP5 selected in % and R + robust zones;
- legacy ladder comparison;
- six-class distribution counts/pcts;
- pool metrics;
- modified-stop execution stats;
- validation statuses;
- hashes/lineage.

## 4. Execution ledger

One row per child-order execution lifecycle or event-normalized row set. Required ability to reconstruct:
- episode/order identity;
- entry;
- target assignment;
- initial SL;
- TP1 trigger;
- stop modification to BE+0.1%;
- final exit reason;
- exit price/time;
- gross/net P&L;
- R result.

## 5. Canonical output tree

```text
RUN_<id>/
  manifest.json
  run_config.resolved.yaml
  PRE_GST_AUDIT/
  GROUP_INDEX.csv
  scopes/
    slot_<id>__<ASSET>__<TF>/
      scope_manifest.json
      offset_entry_diagnostics.csv
      offset_causality.csv
      negative_offset_validation/
      joint_candidate_surface.parquet
      joint_candidate_summary.csv
      sl_surface_projection.csv
      tp_ladder_projection.csv
      joint_robust_regions.json
      pareto_frontier.csv
      outcome_distribution.csv
      execution_ledger.parquet
      modified_stop_summary.csv
      cross_symbol_stability.csv
      walk_forward_folds.csv
      locked_configuration.json
      final_holdout_result.json
      FINAL_RESULT.csv
```

## 6. FINAL_RESULT.csv

One canonical selected row per scope plus optional efficient-set rows.

Required display fields are defined in Product Requirements and `schemas/result_row.schema.json`.

## 7. API outline

Minimum endpoints:
- `POST /runs/validate`
- `POST /runs`
- `GET /runs/{run_id}`
- `POST /runs/{run_id}/cancel`
- `GET /runs/{run_id}/progress`
- `GET /runs/{run_id}/scopes`
- `GET /runs/{run_id}/scopes/{scope_id}/result`
- `GET /runs/{run_id}/scopes/{scope_id}/artifacts`
- `POST /audit/e2e`

Server-Sent Events or equivalent may be used for progress.

## 8. Holdout access control

Optimization code path must not receive holdout rows or a handle capable of reading them. Holdout evaluation occurs in a separate stage after locked configuration persistence.

## 9. Versioning

Schemas use semantic versions. Any change to outcome taxonomy, Offset meaning, TP/SL units or modified-stop semantics requires a schema/methodology version bump.


## 10. v1.5 additional canonical artifacts

Per scope persist:
- `offset_causality.csv`;
- `negative_offset_validation/offset_-1.json` ... `offset_-5.json`;
- `joint_candidate_surface.parquet` (and optional CSV summary);
- `joint_robust_regions.json`;
- `joint_selected_config.json`.

Every joint candidate row carries a stable configuration hash over Offset, SL, RR1..RR5, execution policy, provider/data versions and search-space version.


\newpage

# 08 — UI/UX Specification

## 1. UI goal

Make GST auditable and operational without exposing users to unnecessary analytical clutter.

## 2. Main screens

### A. Run Setup
Fields:
- slot selection / all registered;
- asset groups;
- symbols;
- TFs;
- date ranges;
- canonical Offset sweep `-5..+5` (full run) and optional manual diagnostic subset;
- negative Offset causality mode/status display;
- SL search bounds by scope/profile;
- RR1..RR5 search bounds/steps and minimum separation;
- joint optimizer settings;
- modified stop baseline (`BE+0.1%` shown explicitly);
- development/WF/holdout split;
- legacy baseline toggle.

Pre-run validation must show causal/semantic warnings.

### B. Audit
Per scope:
- source mapping;
- direction mapping;
- timezone;
- Offset semantics;
- execution reconciliation;
- root-cause status.

Blocked scopes clearly separated from runnable scopes.

### C. Optimization Results
The scope detail must make all eleven Offset values visible with status `STANDARD_CAUSAL / CAUSAL_PASS / CAUSAL_FAIL / NON_CAUSAL_DIAGNOSTIC / NOT_APPLICABLE`. A strong negative diagnostic result must never be visually confused with a production-valid selected Offset.

Primary table by `Slot × AssetGroup × TF`:
- selected Offset + causality status + production eligibility;
- selected SL %;
- TP1..TP5 each as `% / R`;
- BAD / TP1 / TP2 / TP3 / TP4 / TP5 percentages;
- total 100%;
- pool expectancy;
- drawdown;
- cross-symbol status;
- WF status;
- holdout status.

### D. Scope Detail
Tabs/panels:
1. Offset surface and causality evidence
2. Joint Offset/SL/RR surface
3. TP ladder candidates / RR neighborhoods
4. Robust/Pareto candidates
5. Outcome distribution
6. Symbol stability
7. Walk-forward/holdout
8. Execution ledger

### E. Execution Ledger
Filter:
- order number;
- exit reason;
- `MODIFIED_SL_BE_PLUS_0_1`;
- symbol;
- date;
- signal ID.

Show stop modification timestamp/price and actual P&L.

## 3. Outcome presentation

Signal result uses only six categories. Do not display FIX/BE as peer categories.

The 100% distribution should be visible as a table and optional 100%-stacked visualization. Numeric table is authoritative.

## 4. Legacy comparison

Side-by-side:
- old Offset/SL/TP ladder if known;
- new selected configuration;
- BAD/TP distribution;
- pool economics;
- validation status.

Legacy GOOD% may appear only under a clearly labeled `Legacy diagnostic` section.

## 5. No arbitrary single score

Do not show a prominent composite GST score. Show raw decision variables, robust zones and validation statuses.

## 6. Status language

Recommended statuses:
- BLOCKED_AUDIT
- RESEARCH_ONLY_NONCAUSAL
- INSUFFICIENT_EVIDENCE
- DEVELOPMENT_CANDIDATE
- WF_VALIDATED
- HOLDOUT_VALIDATED
- GROUP_UNSTABLE
- ROBUST_VALIDATED

## 7. Performance

UI must paginate/virtualize large candidate and execution tables; never require loading millions of ledger rows into browser memory.


\newpage

# 09 — QA, Validation and Acceptance

## 1. Release blockers

Any failure below blocks production claim:

- future/look-ahead leakage;
- any negative Offset promoted without streaming/future-mutation/MTF causality PASS;
- full production optimization omits any Offset in `-5..+5` without explicit approved manifest exception;
- SL or RR ladder selected independently without full tuple replay;
- incorrect BUY/SELL Bid/Ask side;
- Offset not physically rebuilding entry/path;
- signal taxonomy not mutually exclusive;
- BAD episode later reclassified because price recovered;
- class percentages/counts do not reconcile;
- child orders counted as independent signal samples;
- modified stop closes lost or misclassified;
- final holdout read during candidate selection;
- hardcoded slot count;
- TP ordering violation;
- selected TP R values inconsistent with SL/price distances;
- group recommendation dominated by one high-frequency symbol without equal-symbol analysis.

## 2. Golden replay tests

Must include deterministic fixtures for:

1. SL before TP1, later TP5 => BAD.
2. TP1 then BE+0.1 stop for orders 2–5 => signal TP1; four modified-stop closes in ledger.
3. TP1, TP2 then BE+0.1 before TP3 => signal TP2.
4. TP1..TP4 then BE before TP5 => signal TP4.
5. TP5 hit => TP5.
6. BUY and SELL symmetry under mirrored prices.
7. spread prevents target touch that mid-price would falsely show.
8. gap/tick crossing multiple targets.
9. timeout if configured.
10. child order weighting reflected in pool P&L but not episode count.

## 3. 100% invariant tests

For every evaluated candidate:
- class counts sum exactly to valid episode count;
- percentages sum to 100 within display-rounding tolerance;
- each signal_id appears in exactly one class.

## 4. RR/unit tests

For selected and sampled candidates independently recompute:
- SL % from entry and SL price;
- each TP %;
- each TP R ratio;
- modified stop % and R;
- symbol tick rounding.

## 5. Offset and causality tests

- full sweep contains exactly `-5,-4,-3,-2,-1,0,+1,+2,+3,+4,+5`;
- same frozen SignalSeed lineage across semantically applicable offsets;
- entry time/price/path changes exactly per semantics;
- no reused MFE/MAE/outcome from another Offset;
- each negative Offset starts diagnostic unless causal evidence exists;
- streaming replay uses only data available by candidate time;
- future-mutation test leaves causal earlier decision invariant;
- MTF bars respect candidate-time cutoff;
- `data_cutoff_time <= candidate_entry_time` for CAUSAL_PASS;
- CAUSAL_FAIL/NON_CAUSAL_DIAGNOSTIC cannot production-pass.

## 6. Optimization tests

- complete candidate key includes Offset, SL and all five RR values;
- exact five targets;
- ordered targets only;
- deterministic search with same seed/config;
- coarse/refine joint search returns equivalent result to exhaustive small fixture;
- staged SL/RR search never publishes independently selected winners;
- dominated candidates removed correctly;
- robust-zone calculations independently checked.

## 7. Cross-symbol tests

Fixture where one symbol has many signals and extreme result must demonstrate difference between pooled and equal-symbol weighting. Group recommendation must follow configured stability rules.

## 8. Walk-forward/holdout tests

- chronological boundaries correct;
- no overlapping leakage beyond explicit design;
- selection sees no final holdout;
- holdout evaluated only after config lock;
- changing methodology invalidates untouched-holdout label.

## 9. MT5/provider tests

For every enabled production slot:
- source equivalence sample;
- BUY and SELL event mapping;
- timestamp/timezone;
- provider version/hash;
- buffer/source channel;
- no duplicate/phantom signals;
- MTF causality.

## 10. Execution reconciliation tests

When demo/live ledger available:
- reconcile five child orders to episode;
- initial SL;
- each target;
- TP1-triggered stop modifications;
- all `BE+0.1%` closes;
- final P&L tolerance.

## 11. Performance acceptance

Benchmark data size and target hardware must be declared. Production run must support checkpoint/resume and bounded memory. Speed improvements cannot change canonical results.

## 12. Documentation acceptance

Code is not complete until:
- schemas match implementation;
- API docs match actual payloads;
- artifacts are generated as specified;
- traceability matrix has no unresolved P0 requirement.


\newpage

# 10 — Implementation Plan

## Phase 0 — Freeze specification

- approve v1.5 schemas;
- bind provider Offset semantics for all `-5..+5`;
- implement/verify negative Offset causal reconstruction capability or mark research-only;
- confirm current adviser child-order weights;
- confirm exact BE+0.1% broker implementation/rounding;
- fill real slot/provider registry.

Exit: no unresolved semantic ambiguity affecting replay.

## Phase 1 — Reuse and refactor donor foundation

Adapt v0.4:
- MT5 bridge;
- SignalSeed freezing;
- Offset rebuild;
- Bid/Ask path engine;
- Pre-GST audit;
- execution reconciliation;
- splits/holdout isolation;
- storage/API/CLI scaffolding.

Do not yet port old target/allocation optimizer as canonical behavior.

Exit: frozen signals + exact Offset path + audit pass.

## Phase 2 — Canonical episode engine

Implement:
- SignalEpisode;
- five ChildOrders;
- event state machine;
- initial SL;
- five ordered targets;
- TP1 stop modification to BE+0.1%;
- exclusive outcome classification;
- pool P&L.

Exit: all replay golden tests pass.

## Phase 3 — Offset and Negative-Offset Causality

Implement full `-5..+5` sweep, provider semantics, streaming replay, future-mutation and MTF cutoff validation.

Exit: all negative-Offset anti-look-ahead fixtures pass and noncausal candidates are blocked from production selection.

## Phase 4 — Joint Offset/SL/RR Optimizer

Implement explicit SL bounds, ordered five-RR ladder generation, coarse-to-fine complete-tuple search, robust joint neighborhoods and canonical artifacts.

Exit: small exhaustive fixtures independently reproduce the same selected efficient/robust tuple; no independent SL/TP winner path exists.

## Phase 5 — Robust/Pareto/cross-symbol

Implement efficient set, sensitivity and equal-symbol group validation.

Exit: known synthetic dominance/group-instability fixtures pass.

## Phase 6 — Walk-forward and holdout

Integrate locked candidate lifecycle and one-time final holdout evaluation.

Exit: holdout isolation tests pass.

## Phase 7 — Production storage/supervisor

- worker pool;
- checkpoint/resume;
- Parquet/DuckDB;
- durable manifests;
- progress API.

## Phase 8 — UI

Implement setup, audit, results, scope details and execution ledger views.

## Phase 9 — Production provider validation

Compile/deploy MT5 bridge and validate every registered production slot.

## Phase 10 — Forward acceptance

Run frozen methodology on new forward data. Do not tune using that period and continue calling it untouched holdout/forward validation.

## Definition of Done

GST is ready only when:
- all P0/P1 tests pass;
- real provider mappings pass equivalence;
- five-order execution reconciliation works;
- canonical result rows generated for all requested scopes;
- no final-holdout leakage;
- UI and exports agree with raw artifacts;
- forward run demonstrates operational correctness.


\newpage

# 11 — Developer / Codex Handoff

## 1. Instruction

Implement GST 2.0 according to this v1.5 package. Treat `docs/`, `contracts/`, `schemas/` and `acceptance/` as normative. `engineering_reference/v0.4/` is donor code only.

## 2. Do not reinterpret these rules

- one signal = one SignalEpisode;
- exactly five TP-assigned child orders;
- exact six signal classes only;
- initial SL before TP1 => BAD forever;
- no FIX/BE class;
- BE+0.1% closes must be preserved per child order;
- TP1..TP5 are optimized, not hardcoded legacy values;
- selected TP shown in % and RR;
- SL optimized per Slot × AssetGroup × TF;
- Offset full sweep is `-5..+5` per scope with explicit semantics;
- negative Offset is diagnostic until dedicated causality PASS;
- final optimization is joint `Offset × SL × RR1..RR5`;
- no hardcoded slot count;
- final holdout cannot select/tune candidates.

## 3. Required first code tasks

1. Create canonical domain dataclasses/Pydantic models.
2. Port/adapt v0.4 SignalSeed/provider/offset foundation.
3. Implement EpisodeReplayEngine state machine.
4. Build golden replay tests before optimizer.
5. Implement result taxonomy invariants.
6. Add execution ledger stop-modification fields.
7. Implement full Offset -5..+5 resolver and NegativeOffsetCausalityValidator.
8. Implement JointOptimizer over Offset/SL/ordered five-RR tuples.
9. Add joint robust/Pareto/WF/holdout.
10. Build API/UI contracts last around stable engine.

## 4. Forbidden shortcuts

- classify by final price after SL;
- use OHLC favorable ordering for ambiguous intrabar events;
- calculate inverse P&L as `-original`;
- count five child orders as five statistical samples;
- choose target ladder from legacy values without testing;
- use final holdout in optimizer;
- silently change offset sign meaning;
- treat backward-shift negative Offset as causal without streaming proof;
- optimize/select SL and TP ladder independently;
- hide failed symbols inside pooled group result;
- replace raw result distribution with a single composite score.

## 5. Required tests before pull request acceptance

Every PR touching replay/optimization must run:
- unit tests;
- golden replay cases;
- 100% taxonomy invariant;
- holdout access test;
- deterministic reproducibility;
- RR/unit recomputation;
- BE+0.1 ledger test;
- negative Offset streaming/future-mutation/MTF causality tests;
- full -5..+5 sweep coverage test;
- joint-search exhaustive-small-fixture equivalence.

## 6. Required review artifacts

A code milestone is reviewable only if it produces inspectable files on a fixture run:
- manifest;
- offset diagnostics;
- SL/TP candidate surfaces;
- outcome distribution;
- execution ledger;
- selected config;
- validation outputs.

## 7. Reference modules worth reusing

See `docs/12_V04_REUSE_MIGRATION_MAP.md`. Prefer tested adaptation over unnecessary rewrite.


\newpage

# 12 — v0.4 Reuse and Migration Map

## 1. Goal

Preserve proven engineering work while replacing analytical behaviors that no longer match the canonical GST model.

## 2. Reuse/adapt

| v0.4 area | Action | v1.5 destination |
|---|---|---|
| `providers/mt5_bridge.py` | adapt | provider bridge |
| `providers/offset_provider.py` | reuse with semantics contract | OffsetResolver |
| `replay/pricing.py` | reuse | Bid/Ask pricing |
| `replay/path.py` | reuse/refactor | raw executable path |
| `audit_e2e.py` | reuse/extend | Pre-GST audit |
| `execution_ledger.py` | extend | five-order + stop modifications |
| `validate/splits.py` | reuse | WF/holdout split |
| `storage/*` | reuse/upgrade | artifacts/DuckDB |
| API/CLI | reuse patterns | run orchestration |
| MT5 EA bridge | adapt | production export |

## 3. Replace/supersede

| v0.4 behavior | Reason | v1.5 replacement |
|---|---|---|
| dense single-target discovery | not canonical adviser model | ordered five-TP ladder optimizer |
| arbitrary position allocation | adviser uses five target orders | configured five child orders |
| modified-stop optimizer as core | current need is exact baseline reproduction first | fixed/versioned execution policy; future optional research |
| target ranking detached from six-class taxonomy | insufficient | SignalEpisode outcome distribution + pool economics |

## 4. Extend

### Execution ledger
Add:
- episode_id/order_index;
- assigned TP;
- initial SL;
- TP1 trigger;
- stop modification old/new;
- BE+0.1% close reason;
- realized child P&L.

### Domain model
Replace any single-trade statistical assumptions with SignalEpisode as primary sample.

### Metrics
Add exclusive BAD/TP1..TP5 counts and assert 100%.

### Reporting
Add canonical per-scope final row and TP `% / R` fields.

## 5. Do not copy old semantics blindly

Any v0.4 config/comment that says there is no privileged TP1/five-level ladder is superseded by v1.5.


\newpage

# 13 — Non-Goals and Required Production Decisions

## 1. Non-goals for core release

- opaque ML signal generator;
- autonomous source-code rewriting;
- automatic creation of dozens of market-regime subgroups;
- portfolio allocation optimizer unrelated to five-order adviser;
- excessive metric catalog;
- automatic production trading.

## 2. Decisions that must be resolved from real production environment

### Provider binding for Offset semantics
The canonical sweep and negative-Offset causality rules are fixed by v1.5. What remains provider-specific is the exact meaning of one bar/unit of Offset, signal-knowable timestamp, and whether the provider can causally reconstruct an earlier eligible state. Any unresolved negative Offset stays research-only.

### Child-order volume weights
Signal classification does not depend on weights; pool economics does. Pull actual adviser values.

### Exact BE+0.1% implementation
Confirm:
- percentage reference (entry price);
- broker rounding;
- when modification is sent;
- what happens if market gaps beyond requested stop;
- commission effects.

### Timeout / forced close
If production adviser has such rules, encode explicitly. Do not invent them.

### Costs
Broker-specific commission, swap and slippage adapters are required for production economics.

### Timeframes and groups
Canonical test set: **M15, M30, H1, H4, D1, W1**. Registry rows outside this set are rejected by the production validator.

## 3. Future optional research

After core is validated, possible separately approved modules:
- optimization of modified-stop trigger/offset;
- alternative child-order weights;
- controlled signal-condition redesign;
- justified volatility subgroups.

These are not required to complete core GST 2.0.


\newpage

# 14 — Core Pseudocode

## 1. Run orchestration

```python
manifest = freeze_run_manifest(config, data, code_version, provider_versions)
scopes = build_scopes(registry, config)  # Slot × AssetGroup × TF

for scope in scopes:
    audit = pre_gst_audit(scope)
    if audit.hard_block:
        persist_blocked(scope, audit)
        continue

    dev, wf, holdout_handle = create_isolated_splits(scope.data, config.validation)
    candidates = []

    for offset in range(-5, 6):
        offset_view = offset_resolver.resolve_all(scope.signals, offset)
        causality = causality_validator.evaluate(scope, offset_view)
        persist_offset_causality(scope, offset, causality)

        # Research replay is allowed for all valid scenarios.
        # Production promotion later requires production_eligible=True.
        for sl_pct in sl_candidates(scope, config):
            for rr_ladder in ordered_five_rr_ladders(scope, config):
                result = replay_candidate(
                    offset_view, sl_pct, rr_ladder, dev,
                    causality_status=causality.status,
                    production_eligible=causality.production_eligible,
                )
                candidates.append(result)

    persist_joint_surface(candidates)
    robust = joint_robust_filter(candidates)
    efficient = pareto_filter([c for c in robust if c.production_eligible])
    wf_results = walk_forward(efficient, scope, config)
    locked = select_default_without_holdout(wf_results)
    persist_locked_configuration(locked)

    holdout_result = evaluate_holdout_once(holdout_handle, locked)
    persist_final(scope, locked, holdout_result)
```

## 2. Negative Offset causality

```python
def validate_negative_offset(seed, scenario, provider, market):
    if scenario.offset >= 0:
        return standard_causality_check(...)

    # Historical shift alone is diagnostic.
    status = "NON_CAUSAL_DIAGNOSTIC"

    streaming = provider.replay_streaming(
        end_time=scenario.candidate_entry_time,
        no_future_data=True,
    )
    if not streaming.emits_equivalent_signal:
        return CausalityResult(status="CAUSAL_FAIL", production_eligible=False)

    if not future_mutation_invariant(seed, scenario, provider, market):
        return CausalityResult(status="CAUSAL_FAIL", production_eligible=False)

    if not mtf_cutoff_valid(scenario):
        return CausalityResult(status="CAUSAL_FAIL", production_eligible=False)

    assert scenario.data_cutoff_time <= scenario.candidate_entry_time
    return CausalityResult(status="CAUSAL_PASS", production_eligible=True)
```

## 3. SignalEpisode replay

```python
def replay_episode(seed, entry, sl, tp, policy, ticks):
    orders = create_five_orders(entry, sl, tp, policy.weights)
    highest_tp = 0
    stop_mode = "INITIAL"

    for tick in ticks_after(entry.time):
        px = executable_exit_price(seed.direction, tick)

        if stop_hit(px, active_stop(seed.direction, orders)):
            close_remaining_at_stop(orders, tick)
            outcome = "BAD" if highest_tp == 0 else f"TP{highest_tp}"
            return finalize_episode(outcome, orders)

        crossed = newly_crossed_targets(px, orders, seed.direction)
        for order in crossed_in_price_order(crossed):
            close_at_target(order, tick)
            highest_tp = max(highest_tp, order.tp_level)

            if order.tp_level == 1 and stop_mode == "INITIAL":
                new_stop = be_plus_pct(entry, seed.direction, policy.be_profit_pct)
                modify_remaining_stops(orders, new_stop, tick)
                stop_mode = "MODIFIED"

        if highest_tp == 5:
            return finalize_episode("TP5", orders)

    return finalize_by_timeout_policy(...)
```

## 4. RR and target conversion

```python
R_price = abs(entry - initial_sl)
sl_pct = abs(initial_sl - entry) / entry * 100
for rr in rr_ladder:
    tp_distance_price = rr * R_price
    tp_price = target_from_direction(entry, tp_distance_price, direction)
    tp_pct = tp_distance_price / entry * 100
```

## 5. Six-class invariant

```python
classes = Counter(ep.outcome for ep in episodes)
assert set(classes) <= {"BAD","TP1","TP2","TP3","TP4","TP5"}
assert sum(classes.values()) == len(episodes)
```

## 6. Equal-symbol group aggregation

```python
per_symbol = metrics_by_symbol(episodes)
group_equal_weight = mean(metric[symbol] for symbol in symbols)
group_pooled = metrics(all_episodes)
```


\newpage

# 15 — Expected Module Interfaces

Conceptual contracts; syntax may vary, semantics may not.

## SignalProvider
```python
class SignalProvider(Protocol):
    def export_seeds(self, scope: Scope) -> Iterable[SignalSeed]: ...
    def metadata(self) -> ProviderMetadata: ...
    def replay_streaming(self, end_time, no_future_data=True) -> StreamingSignalState: ...
```

## OffsetResolver
```python
class OffsetResolver(Protocol):
    def resolve(self, seed: SignalSeed, offset: int, market: MarketData) -> OffsetScenario: ...
```
`offset` full-run range is `-5..+5`. Scenario includes entry lineage and data cutoff.

## NegativeOffsetCausalityValidator
```python
class NegativeOffsetCausalityValidator:
    def evaluate(self, scope, scenarios: list[OffsetScenario]) -> CausalityResult: ...
    def future_mutation_test(self, scenario, provider, market) -> TestResult: ...
    def mtf_cutoff_test(self, scenario, market) -> TestResult: ...
```

`CausalityResult` includes status, production_eligible and evidence IDs.

## EpisodeReplayEngine
```python
class EpisodeReplayEngine:
    def replay(
        self,
        seed: SignalSeed,
        scenario: OffsetScenario,
        sl: StopLossSpec,
        ladder: TPLadder,
        policy: ExecutionPolicy,
        market: TickStream,
    ) -> SignalEpisodeResult: ...
```

## JointOptimizer
```python
class JointOptimizer:
    def coarse_candidates(self, scope, offset, config) -> Iterable[JointCandidate]: ...
    def refine(self, neighborhoods, config) -> Iterable[JointCandidate]: ...
    def evaluate(self, candidate: JointCandidate, split) -> CandidateResult: ...
```

`JointCandidate` contains exactly one Offset, one SL and five ordered RR values. No independent SL/TP winner API is canonical.

## Robustness
```python
class RobustnessAnalyzer:
    def joint_zones(self, candidate_table) -> list[JointRobustRegion]: ...
```

## Cross-symbol validator
```python
class CrossSymbolValidator:
    def evaluate(self, candidate, episode_results) -> CrossSymbolResult: ...
```

## Walk-forward / holdout
```python
class WalkForwardValidator:
    def evaluate(self, candidate_set, folds) -> list[FoldResult]: ...

class HoldoutEvaluator:
    def evaluate_locked(self, locked_config, holdout_handle) -> HoldoutResult: ...
```

HoldoutEvaluator must not expose raw holdout rows to optimizers.

## Storage
```python
class ArtifactStore:
    def write_manifest(...): ...
    def write_offset_causality(...): ...
    def write_joint_surface(...): ...
    def write_scope_artifact(...): ...
    def checkpoint(...): ...
```


\newpage

# 16 — Canonical Output Examples

All numeric values below are illustrative only.

## 1. Final scope row

```text
Slot: 1
Asset Group: FOREX
TF: H1

Offset Sweep Tested: -5..+5
Offset Robust Zone: -1..0
Selected Offset: -1
Causality Status: CAUSAL_PASS
Production Eligible: TRUE

SL Robust Zone: 0.36%..0.44%
Selected SL: 0.40%

TP1: 0.18% = 0.45R
TP2: 0.34% = 0.85R
TP3: 0.52% = 1.30R
TP4: 0.88% = 2.20R
TP5: 1.36% = 3.40R

BAD: 12%
TP1: 14%
TP2: 18%
TP3: 23%
TP4: 19%
TP5: 14%
TOTAL: 100%

Episodes: 4,280
Child orders: 21,400
Modified-stop BE+0.1 closes: 8,940
Pool expectancy: +0.XX R / episode
Pool max DD: XX.X R
Cross-symbol: PASS
Walk-forward: PASS
Final holdout: PASS
```

## 2. Signal classified TP1 but four modified-stop closes

```text
Episode E123
Order 1: TARGET TP1
Order 2: MODIFIED_SL_BE_PLUS_0_1
Order 3: MODIFIED_SL_BE_PLUS_0_1
Order 4: MODIFIED_SL_BE_PLUS_0_1
Order 5: MODIFIED_SL_BE_PLUS_0_1

Signal outcome: TP1
```

No FIX class is generated.

## 3. SL-first recovery

```text
Entry
Initial SL hit
Later market reaches TP1..TP5

Signal outcome: BAD
```

Later movement is diagnostic only.

## 4. Legacy comparison

```text
LEGACY
SL 0.35%
TP ladder 0.4/0.7/1.2/2/3R
Outcome distribution: ...
Pool expectancy: ...

NEW VALIDATED
SL 0.40%
TP ladder 0.45/0.85/1.30/2.20/3.40R
Outcome distribution: ...
Pool expectancy: ...
```

The new ladder is not accepted unless robustness/WF/holdout rules pass.


## 5. Negative Offset research-only example

```text
Slot: 1 / FOREX / H1
Offset: -2
Historical diagnostic: STRONG
Streaming causal reconstruction: FAIL
Causality status: CAUSAL_FAIL
Production eligible: NO
Action: keep as signal-lateness research evidence; exclude from production Pareto/WF/holdout selection.
```

## 6. Joint candidate identity

```text
Joint Config ID: sha256(...)
Offset = -1
SL = 0.40%
RR = [0.45, 0.85, 1.30, 2.20, 3.40]
```

This tuple is replayed, ranked and validated as one unit. No field is an independently chosen winner.


\newpage

# 17 — Negative Offset Causality Validation

## 1. Problem

A naive backtest can find excellent results for Offset -1..-5 by taking a signal that is only known at time T and moving the entry backward to T-k. That is historical hindsight, not an executable trading rule.

GST must still test negative Offset because it is valuable diagnostic evidence about signal lateness, but it must keep **research quality** separate from **production eligibility**.

## 2. Required sweep

Every full scope tests:

`-5, -4, -3, -2, -1, 0, +1, +2, +3, +4, +5`.

All eleven scenarios use the same frozen SignalSeed population where semantically applicable. Entry/path/outcomes are rebuilt per Offset.

## 3. Negative Offset states

- `NON_CAUSAL_DIAGNOSTIC`: backward-shift result only; useful for lateness diagnosis.
- `CAUSAL_PASS`: earlier equivalent signal is demonstrably knowable at the earlier time.
- `CAUSAL_FAIL`: one or more causality gates failed.
- `NOT_APPLICABLE`: provider semantics do not permit that negative Offset for the signal.

Only `CAUSAL_PASS` is production-eligible.

## 4. Streaming replay

For candidate entry time T-k:
1. instantiate clean provider state;
2. feed only data whose availability timestamp <= T-k;
3. close/confirm bars exactly as production would have at T-k;
4. ask provider whether the required earlier signal/eligible state exists;
5. capture the first executable tick after the event;
6. persist all input cutoffs and hashes.

The provider cannot be initialized with full-history indicators that silently use future bars.

## 5. Future-mutation invariance

Take the same history through T-k and create several futures after T-k with modified/removed values. The decision at T-k must remain identical. If it changes, future information leaked into the result.

This test should be automated on deterministic fixtures and sampled real events.

## 6. MTF integrity

For H1 candidate time, any H4/D1/W1 dependency must reference only the last fully closed higher-timeframe bar available at the candidate time. No state from a still-open higher-timeframe bar may be used unless the production provider explicitly and causally uses intrabar values and that behavior is reproduced tick-by-tick.

## 7. Production selection

Negative diagnostic candidates can appear in research tables and may trigger a conclusion such as "signal systematically arrives 1-2 bars late". They cannot participate in production Pareto ranking until `CAUSAL_PASS`.

If a negative diagnostic result is strong but cannot be made causal, GST should report it as a signal-design finding rather than a tradable Offset.

## 8. Required artifacts

Per scope:
- `offset_causality.csv`;
- `negative_offset_validation/offset_-1.json` ... `offset_-5.json`;
- streaming replay evidence IDs;
- future-mutation results;
- MTF cutoff evidence;
- final `production_eligible` flag.


\newpage

# 18 — Joint Offset / SL / RR Optimization

## 1. Objective

For every `Slot × AssetGroup × TF`, determine a robust executable tuple:

`Offset + SL + RR1 + RR2 + RR3 + RR4 + RR5`

that produces the strongest validated five-order economics and TP-depth distribution without relying on an isolated historical peak.

## 2. Search is joint

The tester must not select SL in one independent optimization and then separately choose RR targets. Changing SL changes:
- absolute TP distances for every RR;
- absolute BE+0.1% relation in R units;
- stop/target chronology;
- pool P&L and drawdown.

Therefore every ranked candidate is a complete tuple.

## 3. Search procedure per Offset

For each of the eleven Offset values:

1. build the OffsetScenario;
2. run causality classification;
3. enumerate configured SL candidates;
4. for each SL build the configured RR grid;
5. generate legal ordered five-RR ladders;
6. convert each ladder to executable target prices;
7. replay every SignalEpisode with five child orders and BE+0.1% execution policy;
8. store `BAD/TP1/TP2/TP3/TP4/TP5 = 100%`;
9. compute pool economics and drawdown;
10. compute cross-symbol metrics;
11. identify robust/non-dominated neighborhoods;
12. refine locally with smaller SL/RR steps;
13. take only production-eligible complete tuples into walk-forward;
14. lock final candidate before holdout.

## 4. Computational strategy

Exhaustive fine-grid enumeration can be combinatorially large. The approved deterministic method is:

- coarse full-grid exploration;
- dominance pruning;
- retain multiple connected robust neighborhoods;
- dense local refinement;
- optional safe branch-and-bound/pruning only when it cannot remove a potentially non-dominated legal candidate under declared rules.

Raw price-path caching is allowed if it is Offset-specific and contains no outcome leakage from a different candidate.

## 5. Search bounds

Search bounds are explicit configuration, ideally by `AssetGroup × TF`. The sample config is illustrative. GST must refuse a production run whose required SL/RR bounds are unresolved or silently defaulted.

## 6. TP levels

TP1..TP5 are not preassigned to 0.4/0.7/1.2/2/3R. Those values are always evaluated as the legacy comparator when within configured bounds.

A selected ladder is valid only after robust-zone, walk-forward and holdout checks.

## 7. Final output

For every scope show:
- selected Offset and causal status;
- Offset robust zone;
- selected SL % and robust zone;
- selected TP1..TP5 as `%` and `R` plus local RR zones;
- `BAD/TP1..TP5` percentages summing to 100%;
- modified-stop close count and P&L contribution;
- pool net R, expectancy, PF, max DD;
- cross-symbol, walk-forward and holdout status;
- legacy-baseline delta.


\newpage

# Приложение A — Нормативные контракты


## EXECUTION LEDGER CONTRACT

# Execution Ledger Contract

The execution ledger preserves real/reconstructed child-order behavior without polluting the six-class signal taxonomy.

## Required columns
- run_id
- scope_id
- episode_id
- signal_id
- slot_id
- asset_group
- symbol
- timeframe
- offset
- order_index (1..5)
- direction
- entry_time
- entry_price
- order_weight_or_lot
- assigned_tp_level
- assigned_tp_price
- assigned_tp_pct
- assigned_tp_R
- initial_sl_price
- initial_sl_pct
- tp1_trigger_time (nullable)
- stop_modified (bool)
- stop_modify_time (nullable)
- old_stop_price (nullable)
- new_stop_price (nullable)
- new_stop_pct_from_entry (nullable)
- new_stop_R (nullable)
- exit_time
- exit_price
- exit_reason
- gross_pnl
- costs
- net_pnl
- realized_R

## Exit reasons
At minimum:
- TARGET
- INITIAL_SL
- MODIFIED_SL_BE_PLUS_0_1
- TIMEOUT
- FORCED_EXIT
- EXECUTION_ERROR

`MODIFIED_SL_BE_PLUS_0_1` is not a signal class.


## JOINT OFFSET SL RR OPTIMIZATION CONTRACT

# Joint Offset / SL / RR Optimization Contract

## 1. Canonical candidate

The atomic optimization candidate is the full tuple:

`(offset, sl_pct, rr1, rr2, rr3, rr4, rr5)`

subject to:
- `offset ∈ {-5,-4,-3,-2,-1,0,1,2,3,4,5}` for a full run;
- `sl_pct > 0`;
- `0 < rr1 < rr2 < rr3 < rr4 < rr5`;
- configured minimum TP separation;
- symbol tick/price normalization.

## 2. No independent winner selection

SL and TP/RR may be generated in stages for efficiency, but the system must never declare an independently optimal SL and then attach a separately optimized ladder without replaying the combined tuple. Final ranking, robustness, walk-forward and holdout operate on complete tuples.

## 3. Search bounds

Bounds are explicit run configuration, optionally overridden by `AssetGroup × TF`. There are no hidden universal optimal SL or TP values.

The sample config provides illustrative bounds only. Production runs must persist the exact bounds/steps in the immutable run manifest.

## 4. TP determination

For each SL candidate:
1. define `R = entry-to-initial-SL distance`;
2. generate a legal RR grid;
3. generate strictly ordered five-target ladders from that grid;
4. convert each RR to price/% distance using the same selected SL;
5. replay the full five-order episode;
6. compute six-class distribution and pool economics;
7. retain robust, non-dominated regions;
8. refine locally at smaller steps;
9. validate locked tuples out of sample.

Legacy `0.4/0.7/1.2/2/3R` is evaluated as a comparator, never privileged.

## 5. Robustness

Robustness is evaluated in the joint neighborhood, not one dimension in isolation. A selected tuple must not depend on a narrow spike in Offset, SL or any RR component.

Persist local sensitivity for:
- Offset neighbors;
- SL neighbors;
- RR ladder neighbors;
- worst/median expectancy;
- drawdown;
- cross-symbol stability.


## MT5 BRIDGE CONTRACT

# MT5 Bridge Contract

The bridge exports source truth; it does not optimize.

Mandatory outputs:
- frozen signals with source channel/provider version;
- bars;
- ticks Bid/Ask;
- symbol metadata;
- timezone metadata;
- registry snapshot.

No hardcoded slot limit.

Any provider unable to expose canonical source buffers requires a thin, separately versioned adapter. The adapter must preserve provider equivalence and may not invent signal logic.


## NEGATIVE OFFSET CAUSALITY CONTRACT

# Negative Offset Causality Contract

## 1. Mandatory sweep

The canonical automatic Offset sweep is integer values `-5..+5` inclusive. Manual runs may test a subset for debugging, but a full production optimization run must cover all eleven values unless the run manifest explicitly records an approved scope exception.

## 2. Two distinct meanings for negative Offset

A negative value must never be treated as automatically executable.

### A. Diagnostic historical shift
A frozen source signal known at time `T` is hypothetically entered at `T-k`. This is useful to measure whether the source signal appears late, but it is inherently hindsight-based unless causality can be reconstructed. Status: `NON_CAUSAL_DIAGNOSTIC` by default.

### B. Causal reconstructed signal
A provider/slot can prove that an equivalent eligible signal state existed at `T-k` using only information available at or before `T-k`. Status may become `CAUSAL_PASS`.

## 3. Required lineage fields

Every OffsetScenario must persist:
- `source_signal_time`;
- `offset`;
- `candidate_entry_time`;
- `data_cutoff_time`;
- `offset_semantics_id`;
- `causality_mode`;
- `causality_status`;
- `production_eligible`;
- `causality_evidence_id`.

Invariant for a causal candidate:

`data_cutoff_time <= candidate_entry_time`.

## 4. Mandatory causality tests

A negative Offset is production-eligible only if all applicable tests pass:

1. **Streaming Replay Test** — at candidate time the provider is fed only historical data available up to that timestamp and must emit/qualify the earlier signal without future rows.
2. **Future Mutation Test** — mutate or remove all market/provider data after candidate time; the earlier signal decision must remain unchanged.
3. **MTF Cutoff Test** — higher-timeframe inputs may use only bars fully closed and knowable at candidate time.
4. **Provider Semantics Test** — sign meaning and timestamp rule must match the versioned provider contract.
5. **Entry Executability Test** — entry price must use the first executable Bid/Ask tick after the causal event according to provider/adviser rules.

Any failed mandatory test => `CAUSAL_FAIL`, `production_eligible=false`.

## 5. Selection restrictions

`NON_CAUSAL_DIAGNOSTIC` and `CAUSAL_FAIL` candidates:
- may be shown in research surfaces;
- may be compared to Offset 0 to diagnose signal delay;
- may trigger controlled signal-condition research;
- must not enter production Pareto selection;
- must not be promoted by walk-forward/holdout as production configurations.

## 6. Positive/zero Offset

Offset `0..+5` still requires provider-semantic and no-look-ahead checks, but does not require causal reconstruction of an earlier signal. Entry/path must nevertheless be physically rebuilt for each value.


## OFFSET SEMANTICS CONTRACT

# Offset Semantics Contract

Every production provider/slot must bind to a versioned Offset semantics definition.

## Canonical sweep

Full automatic GST optimization tests integer Offset values `-5..+5` inclusive. Each value is a separate scenario with independently rebuilt entry/path/outcomes.

Required provider fields:
- `offset_semantics_id`;
- `zero_definition`;
- `positive_definition`;
- `negative_definition`;
- `entry_timestamp_rule`;
- `entry_price_rule`;
- `signal_knowable_time_rule`;
- `causality_test`;
- `mtf_cutoff_rule`.

GST must persist these fields in the run manifest and result lineage.

Negative Offset is not assumed causal. A historical backward shift is `NON_CAUSAL_DIAGNOSTIC` until the dedicated causality validator proves the earlier decision was knowable in real time. A candidate whose reconstructed entry uses data not available by the candidate entry timestamp is `CAUSAL_FAIL` and cannot be production-validated.

See `NEGATIVE_OFFSET_CAUSALITY_CONTRACT.md`.


## TP SL RR CONTRACT

# TP / SL / RR Contract

## Initial SL

Canonical research unit: percentage distance from entry price.

`R = abs(entry_price - initial_sl_price)` in price units after symbol rounding.

SL bounds/steps are explicit run configuration and may be specified per AssetGroup × TF. No universal optimal SL is hardcoded.

## TP fields

For each i=1..5 store:
- `tp_i_price`;
- `tp_i_pct_from_entry`;
- `tp_i_R`.

Consistency invariant:
`tp_i_R == abs(tp_i_price-entry_price) / R` within numeric tolerance.

Ordering invariant:
`0 < tp1_R < tp2_R < tp3_R < tp4_R < tp5_R`.

## TP discovery

TP1..TP5 are optimization variables. They are generated from an explicit configured RR grid and evaluated only as complete five-level ladders together with the selected Offset and SL candidate.

There are no fixed optimal TP values in the core methodology.

## Legacy ladder

`0.4 / 0.7 / 1.2 / 2.0 / 3.0 R` is baseline only. It must be evaluated for comparison but must not constrain or seed the winner unless it independently survives the same search/validation rules.

## Joint selection

Every final scope must show:
- selected Offset;
- selected SL %;
- TP1..TP5 in both `%` and `R`;
- robust zones/sensitivity;
- six-class result distribution;
- pool economics.

SL and RR ladder cannot be published as independent winners. The selected result is one jointly replayed configuration tuple.


\newpage

# Приложение B — Acceptance Checklist

# GST 2.0 v1.5 Acceptance Checklist

## Domain
- [ ] One source signal maps to exactly one SignalEpisode per candidate.
- [ ] Five child orders are created/replayed.
- [ ] TP1..TP5 are strictly ordered.
- [ ] BAD/TP1..TP5 are the only public signal classes.
- [ ] Six classes reconcile to 100%.
- [ ] SL-first remains BAD after any later recovery.
- [ ] No FIX class exists.
- [ ] BE+0.1% closes are retained in execution ledger.

## Optimization
- [ ] Full Offset sweep `-5..+5` executed per Slot × AssetGroup × TF.
- [ ] Negative Offset -1..-5 has explicit causality status/evidence and noncausal candidates are research-only.
- [ ] SL and RR1..RR5 are optimized as complete joint tuples per Offset.
- [ ] TP1..TP5 optimized, not hardcoded to legacy ladder.
- [ ] Every selected TP shows % and RR.
- [ ] Robust zones persisted.
- [ ] Pareto/efficient set persisted.
- [ ] Cross-symbol equal-weight analysis persisted.

## Validation
- [ ] Pre-GST audit passes or scope blocked.
- [ ] Bid/Ask tick replay used for final execution validation.
- [ ] Walk-forward OOS complete.
- [ ] Candidate locked before holdout.
- [ ] Holdout isolated and evaluated once.
- [ ] Noncausal Offset cannot production-pass.
- [ ] Streaming replay, future-mutation and MTF cutoff tests pass for every selected negative Offset.
- [ ] No independent SL/TP winner selection path exists.

## Engineering
- [ ] No hardcoded slot count.
- [ ] Run manifest/hashes complete.
- [ ] Checkpoint/resume works.
- [ ] API/artifact schemas match implementation.
- [ ] Golden tests and reconciliation tests pass.


\newpage

# Приложение C — Traceability Matrix

# Traceability Matrix

| Requirement | Primary module | Artifact | Acceptance test |
|---|---|---|---|
| Frozen source signal | providers / domain | signals export, manifest | provider equivalence |
| Offset rebuild | OffsetResolver | offset_entry_diagnostics.csv | offset rebuild golden |
| Offset causality | NegativeOffsetCausalityValidator | offset_causality.csv + evidence JSON | streaming/future-mutation/MTF tests |
| Full Offset -5..+5 sweep | OffsetResolver/JointOptimizer | joint_candidate_surface | sweep coverage test |
| Joint Offset/SL/RR optimization | JointOptimizer | joint_candidate_surface.parquet | exhaustive small fixture equivalence |
| Explicit search bounds | config resolver | run_config.resolved.yaml | no-hidden-default test |
| Five TP/RR ordering | JointOptimizer | joint candidate rows | ordered ladder invariant |
| TP % and RR consistency | domain/metrics | FINAL_RESULT.csv | RR recomputation |
| Five child orders | episode engine | execution ledger | five-order replay test |
| TP1 -> BE+0.1% | episode engine | execution ledger | modified-stop golden |
| BAD permanent after SL-first | episode engine | outcome_distribution.csv | SL-first-later-TP5 test |
| Six classes =100% | metrics/reporting | outcome_distribution.csv | taxonomy invariant |
| Pool P&L | metrics/pool | result row | independent arithmetic |
| Pre-GST audit | audit/pre_gst | PRE_GST_AUDIT/* | structural audit fixture |
| Direction inversion diagnostic | audit | direction_inversion_audit.csv | full replay inversion test |
| Cross-symbol stability | validate/cross_symbol | cross_symbol_stability.csv | imbalanced symbol fixture |
| Walk-forward | validate/walk_forward | walk_forward_folds.csv | split boundary test |
| Holdout isolation | validate/holdout | final_holdout_result.json | access isolation test |
| Dynamic slots | registry/MT5 | registry snapshot | >23 slot synthetic test |
| UI six-class display | frontend | results screen | UI contract test |


## SL search bounds по Asset Group × TF (code v1.5)

Для production-поиска используются отдельные стартовые границы SL для всех 30 сочетаний пяти классов активов и шести TF. Эти значения являются **границами поиска**, а не рекомендуемыми SL. Полная машиночитаемая таблица находится в `config/run_config.example.yaml`.

- FOREX: M15 `0.10–0.80%`, M30 `0.10–1.00%`, H1 `0.15–1.25%`, H4 `0.20–2.00%`, D1 `0.30–3.00%`, W1 `0.50–5.00%`.
- COMMODITIES: M15 `0.15–1.00%`, M30 `0.15–1.25%`, H1 `0.20–1.75%`, H4 `0.30–2.50%`, D1 `0.50–4.00%`, W1 `0.75–6.00%`.
- CRYPTO: M15 `0.20–2.00%`, M30 `0.25–2.50%`, H1 `0.30–3.00%`, H4 `0.50–5.00%`, D1 `0.75–8.00%`, W1 `1.00–12.00%`.
- INDICES: M15 `0.15–1.00%`, M30 `0.15–1.25%`, H1 `0.20–1.75%`, H4 `0.30–2.50%`, D1 `0.50–4.00%`, W1 `0.75–6.00%`.
- STOCKS: M15 `0.20–1.50%`, M30 `0.20–1.75%`, H1 `0.25–2.50%`, H4 `0.40–4.00%`, D1 `0.75–6.00%`, W1 `1.00–10.00%`.

### Boundary expansion gate

Если лучший joint-кандидат для конкретного Offset оказывается на `SL_MIN`, `SL_MAX`, `RR_MIN` или `RR_MAX`, тестер не принимает край диапазона за optimum. Он расширяет затронутую границу и повторяет полный `Offset × SL × RR1..RR5` search. По умолчанию разрешено до 3 раундов расширения с коэффициентом 1.5. Если после этого лучший результат всё ещё лежит на границе, выставляется `SEARCH_BOUNDARY_HIT_UNRESOLVED`; такой Offset при `fail_if_unresolved=true` не допускается в production selection.


# AUDIT HARDENING v1.6.0 / code v1.5 — ОБЯЗАТЕЛЬНЫЕ ПРАВИЛА

Эта секция имеет приоритет над более ранними формулировками документа.

1. `sl_pct` задаётся в процентных пунктах: `0.40 == 0.40%`; абсолютное расстояние до raw SL = `Entry × sl_pct / 100`.
2. После tick normalization пересчитываются `effective_sl_pct`, executable TP prices, `effective_tp_pct` и `effective_RR`; nominal и effective поля хранятся раздельно.
3. BUY: entry Ask, exit/SL/TP placement Bid-side. SELL: entry Bid, exit/SL/TP placement Ask-side. Economic R = `|Entry-SL_exec|`; broker placement distance считается отдельно от актуальной exit-side котировки.
4. Stop trigger и fill разделены. Production stop при gap исполняется по первой доступной exit-side котировке с configured adverse slippage.
5. `BAD` означает только фактический initial-SL before TP1. `UNRESOLVED_TIMEOUT`, `INCOMPLETE_DATA`, `EXECUTION_INVALID` не входят в BAD/TP1..TP5.
6. Шестиклассовое распределение считается только по completed valid episodes. Финансовая экономика считается по COMPLETE + UNRESOLVED_TIMEOUT: открытые orders marked-to-market по последней in-window executable quote и не могут исчезнуть из expectancy/DD.
7. `pool_R = sum(weighted child net R) / sum(initial risk weights)`. `pool_order_R_sum` — отдельная единица. Денежный PnL требует instrument/account model и внешнюю broker reconciliation.
8. Portfolio MTM DD обновляется атомарно по timestamp: сначала обновляются все позиции с этой меткой времени, затем считается equity/peak/DD. Close-event DD — отдельная диагностика.
9. Train / selection-OOS / every WF fold / final holdout имеют жёсткие временные барьеры по полной жизни episode. Последний WF fold обязательно ограничен началом final holdout.
10. Offset semantics неизменяемы: negative=earlier, zero=source, positive=later. Любой иной `offset_semantics_id` блокируется. Negative production offset требует provenance-bound causality evidence.
11. Production validation gates нельзя отключить конфигурацией. Missing/disabled validation никогда не является PASS.
12. Selection OOS, каждый WF fold и final holdout обязаны независимо пройти minimum completed sample, eligibility, positive equal-symbol expectancy, cross-symbol threshold, zero replay/execution-invalid errors и excluded/unresolved ceilings. Missing folds входят в denominator как failure.
13. Execution reconciliation fail-closed: claimed `pass` не может перезаписать computed result; проверяются artifact SHA-256, matched count, price/time/account-PnL error limits, exact data fingerprint и execution-model fingerprint.
14. Source accounting обязано сохранять цепочку `source signals -> built/skipped with reason -> replay success/error -> financial -> completed/open`.
15. Lower-SL preference допускается только если полный paired bootstrap CI разности `(best-alt)` находится внутри заранее заданного practical-equivalence margin `±R`. Bootstrap resamples chronological timestamp groups, а не symbols независимо.
16. Selected config lock создаётся и проверяется до final holdout; fingerprint связывает config, market inputs, code, instrument specs, registry и external evidence.
17. Production MT5 evidence должен быть frozen `BOOTSTRAP_ONLY`. Ошибка signals/bars/ticks export или CopyTicksRange блокирует bootstrap completion. Live signal polling не считается полным frozen market-data export.
18. GST не знает внутренних формул scanners/models. Он принимает финальные зарегистрированные signal streams; количество slots/sources архитектурно не ограничено.
19. Search является adaptive/heuristic. Публикуется “best validated candidate found in searched domain”, а не доказанный глобальный optimum.
20. Зелёные unit tests сами по себе не являются production proof; обязательны adversarial regression, end-to-end lineage check и external MT5/broker acceptance.

#property copyright "SMD"
#property version   "1.400"
#property strict

// ============================================================================
// SMD GST 2.0 — MT5 Bridge / Frozen Signal & Market Data Exporter v0.4
// ----------------------------------------------------------------------------
// PURPOSE
//   * Read an UNBOUNDED number of slot/provider mappings from CSV registry.
//   * Freeze source signal events without modifying their formulas.
//   * Export canonical GST signal seeds, OHLC bars and optional tick windows.
//   * Keep source signal logic separate from GST optimization.
//
// CRITICAL ARCHITECTURE RULE
//   There is NO MAX_SLOTS constant and no hard-coded 23-slot loop.
//   The current project may contain 23 slots, but the bridge processes however
//   many registry rows exist. Adding another slot requires only a registry row
//   (and, if needed, a provider adapter), not code modification.
//
// PROVIDER CONTRACT
//   Generic iCustom providers are supported when the source indicator exposes:
//     A) separate BUY/SELL signal buffers, or
//     B) a direction/event buffer with configured BUY/SELL numeric values.
//   The bridge calls iCustom() with the indicator's default input set. If a
//   production slot requires non-default or complex typed inputs, point the
//   registry to a thin canonical adapter indicator that exposes GST buffers.
//
// NON-EXECUTION BOUNDARY
//   This EA does not place, modify or close orders. It does not calculate SL,
//   TP or RR. Those are GST Python analytical responsibilities.
// ============================================================================

#define GST_BRIDGE_VERSION "1.4.0"
#define GST_SCHEMA_VERSION "GST_MT5_BRIDGE_1.4"

// ------------------------------- Modes --------------------------------------
enum ENUM_GST_BRIDGE_MODE
  {
   GST_BOOTSTRAP_ONLY=0,
   GST_BOOTSTRAP_AND_LIVE=1,
   GST_LIVE_ONLY=2
  };

enum ENUM_GST_TICK_EXPORT_MODE
  {
   GST_TICKS_NONE=0,
   GST_TICKS_SIGNAL_RANGE=1
  };

// ------------------------------- Inputs -------------------------------------
input ENUM_GST_BRIDGE_MODE      InpMode                       = GST_BOOTSTRAP_AND_LIVE;
input string                    InpSlotRegistry               = "GST\\slot_registry.csv";
input string                    InpUniverseRegistry           = "GST\\symbol_registry.csv";
input string                    InpTimezoneSchedule           = "GST\\timezone_offsets.csv";
input string                    InpExportDirectory            = "GST\\export";
input int                       InpTimerSeconds                = 2;
input int                       InpProvidersPerTimer           = 32;
input int                       InpMaxProviderBootstrapRetries = 20;
input bool                      InpExportBars                  = true;
input ENUM_GST_TICK_EXPORT_MODE InpTickExportMode             = GST_TICKS_SIGNAL_RANGE;
input int                       InpDefaultHorizonBars          = 48;
input int                       InpOffsetPaddingBeforeBars     = 20;
input int                       InpOffsetPaddingAfterBars      = 20;
input int                       InpFixedServerUtcOffsetMinutes = 0;
input datetime                  InpHistoryStartServer          = 0;   // 0 = first available series date
input datetime                  InpHistoryEndServer            = 0;   // 0 = current server time
input bool                      InpVerboseLog                  = true;

// ------------------------------ Registry models -----------------------------
struct GstSlotMap
  {
   bool              enabled;
   string            slot_id;
   string            slot_name;
   string            provider_type;
   string            indicator_path;
   ENUM_TIMEFRAMES   handle_tf;
   string            signal_tf_text;
   ENUM_TIMEFRAMES   signal_tf;
   int               buy_buffer;
   int               sell_buffer;
   int               direction_buffer;
   double            buy_value;
   double            sell_value;
   bool              emit_on_change;
   string            symbols_filter;
   int               live_buffer_shift;
   string            provider_version;
   string            provider_hash;
   int               horizon_bars;
  };

struct GstSymbolDef
  {
   bool   enabled;
   string symbol;
   string asset_group;
  };

struct GstTimezoneRule
  {
   bool     enabled;
   datetime server_from;
   datetime server_to;
   int      utc_offset_minutes;
  };

struct GstProviderInstance
  {
   int      map_index;
   int      symbol_index;
   int      handle;
   datetime last_live_decision_server;
   int      bootstrap_failures;
  };

struct GstFrozenSignal
  {
   string           signal_id;
   int              map_index;
   int              symbol_index;
   string           direction;
   datetime         decision_server;
   datetime         source_bar_open_server;
   double           source_value;
   string           source_channel;
  };

GstSlotMap          g_maps[];
GstSymbolDef        g_symbols[];
GstTimezoneRule     g_tz_rules[];
GstProviderInstance g_providers[];
GstFrozenSignal     g_signals[];
string              g_seen_signal_ids[];

bool g_bootstrap_started=false;
bool g_bootstrap_complete=false;
bool g_bootstrap_failed=false;
int  g_bootstrap_failed_providers=0;
int  g_provider_construction_failures=0;
int  g_bootstrap_provider_cursor=0;
int  g_live_provider_cursor=0;

// ------------------------------ String helpers ------------------------------
string GstTrim(string s)
  {
   StringTrimLeft(s);
   StringTrimRight(s);
   return s;
  }

string GstUpper(string s)
  {
   StringToUpper(s);
   return s;
  }

bool GstParseBool(string s)
  {
   s=GstUpper(GstTrim(s));
   return(s=="1" || s=="TRUE" || s=="YES" || s=="Y" || s=="ON");
  }

bool GstIsEmptyField(string s)
  {
   s=GstUpper(GstTrim(s));
   return(s=="" || s=="NA" || s=="N/A" || s=="NULL");
  }

ENUM_TIMEFRAMES GstTfFromString(string tf)
  {
   tf=GstUpper(GstTrim(tf));
   if(tf=="M1")  return PERIOD_M1;
   if(tf=="M2")  return PERIOD_M2;
   if(tf=="M3")  return PERIOD_M3;
   if(tf=="M4")  return PERIOD_M4;
   if(tf=="M5")  return PERIOD_M5;
   if(tf=="M6")  return PERIOD_M6;
   if(tf=="M10") return PERIOD_M10;
   if(tf=="M12") return PERIOD_M12;
   if(tf=="M15") return PERIOD_M15;
   if(tf=="M20") return PERIOD_M20;
   if(tf=="M30") return PERIOD_M30;
   if(tf=="H1")  return PERIOD_H1;
   if(tf=="H2")  return PERIOD_H2;
   if(tf=="H3")  return PERIOD_H3;
   if(tf=="H4")  return PERIOD_H4;
   if(tf=="H6")  return PERIOD_H6;
   if(tf=="H8")  return PERIOD_H8;
   if(tf=="H12") return PERIOD_H12;
   if(tf=="D1")  return PERIOD_D1;
   if(tf=="W1")  return PERIOD_W1;
   if(tf=="MN1" || tf=="MN") return PERIOD_MN1;
   return PERIOD_CURRENT;
  }

string GstTfToString(ENUM_TIMEFRAMES tf)
  {
   if(tf==PERIOD_M1) return "M1";
   if(tf==PERIOD_M2) return "M2";
   if(tf==PERIOD_M3) return "M3";
   if(tf==PERIOD_M4) return "M4";
   if(tf==PERIOD_M5) return "M5";
   if(tf==PERIOD_M6) return "M6";
   if(tf==PERIOD_M10) return "M10";
   if(tf==PERIOD_M12) return "M12";
   if(tf==PERIOD_M15) return "M15";
   if(tf==PERIOD_M20) return "M20";
   if(tf==PERIOD_M30) return "M30";
   if(tf==PERIOD_H1) return "H1";
   if(tf==PERIOD_H2) return "H2";
   if(tf==PERIOD_H3) return "H3";
   if(tf==PERIOD_H4) return "H4";
   if(tf==PERIOD_H6) return "H6";
   if(tf==PERIOD_H8) return "H8";
   if(tf==PERIOD_H12) return "H12";
   if(tf==PERIOD_D1) return "D1";
   if(tf==PERIOD_W1) return "W1";
   if(tf==PERIOD_MN1) return "MN1";
   return EnumToString(tf);
  }

string GstSafeId(string s)
  {
   StringReplace(s," ","_");
   StringReplace(s,",","_");
   StringReplace(s,";","_");
   StringReplace(s,"/","_");
   StringReplace(s,"\\","_");
   return s;
  }

// ---------------------------- Timestamp helpers -----------------------------
int GstUtcOffsetMinutesForServerTime(datetime server_time)
  {
   int n=ArraySize(g_tz_rules);
   for(int i=0;i<n;i++)
     {
      if(!g_tz_rules[i].enabled) continue;
      bool ge_from=(g_tz_rules[i].server_from==0 || server_time>=g_tz_rules[i].server_from);
      bool le_to  =(g_tz_rules[i].server_to==0   || server_time<=g_tz_rules[i].server_to);
      if(ge_from && le_to)
         return g_tz_rules[i].utc_offset_minutes;
     }
   return InpFixedServerUtcOffsetMinutes;
  }

datetime GstServerToUtc(datetime server_time)
  {
   int off=GstUtcOffsetMinutesForServerTime(server_time);
   return (datetime)((long)server_time-(long)off*60L);
  }

string GstIsoUtc(datetime utc_time)
  {
   MqlDateTime dt;
   TimeToStruct(utc_time,dt);
   return StringFormat("%04d-%02d-%02dT%02d:%02d:%02dZ",dt.year,dt.mon,dt.day,dt.hour,dt.min,dt.sec);
  }

string GstServerTimeText(datetime t)
  {
   return TimeToString(t,TIME_DATE|TIME_SECONDS);
  }

string GstIsoUtcMsc(long server_msc,datetime server_seconds)
  {
   int off=GstUtcOffsetMinutesForServerTime(server_seconds);
   long utc_msc=server_msc-(long)off*60000L;
   datetime sec=(datetime)(utc_msc/1000L);
   int ms=(int)(utc_msc%1000L);
   if(ms<0) ms+=1000;
   MqlDateTime dt;
   TimeToStruct(sec,dt);
   return StringFormat("%04d-%02d-%02dT%02d:%02d:%02d.%03dZ",dt.year,dt.mon,dt.day,dt.hour,dt.min,dt.sec,ms);
  }

// ------------------------------- CSV helpers --------------------------------
bool GstEnsureExportDirectory()
  {
   // File APIs create relative files under MQL5\Files. FileOpen can create the
   // final file if parent GST exists. Folder creation is explicit for clarity.
   FolderCreate("GST");
   FolderCreate(InpExportDirectory);
   return true;
  }

int GstOpenCsvWrite(string path,bool overwrite)
  {
   uint flags=FILE_WRITE|FILE_CSV|FILE_ANSI|FILE_SHARE_READ;
   if(!overwrite && FileIsExist(path))
     {
      int h=FileOpen(path,FILE_READ|FILE_WRITE|FILE_CSV|FILE_ANSI|FILE_SHARE_READ,',');
      if(h!=INVALID_HANDLE) FileSeek(h,0,SEEK_END);
      return h;
     }
   return FileOpen(path,flags,',');
  }

void GstWriteSignalsHeader(int h)
  {
   FileWrite(h,
             "signal_id","slot_id","slot_name","asset_group","symbol","timeframe","direction",
             "signal_time","server_signal_time","source_bar_open_server","source_value","source_channel",
             "provider_type","indicator_path","provider_version","provider_hash","bridge_version","schema_version",
             "server_utc_offset_minutes");
  }

void GstWriteBarsHeader(int h)
  {
   FileWrite(h,"open_time","symbol","timeframe","open","high","low","close",
             "volume","spread_points","server_open_time","server_utc_offset_minutes");
  }

void GstWriteTicksHeader(int h)
  {
   FileWrite(h,"timestamp","symbol","bid","ask","last","volume","flags",
             "server_timestamp","server_utc_offset_minutes");
  }

// ---------------------------- Registry loaders ------------------------------
bool GstLoadSymbolRegistry()
  {
   ArrayResize(g_symbols,0);
   int h=FileOpen(InpUniverseRegistry,FILE_READ|FILE_CSV|FILE_ANSI|FILE_SHARE_READ,',');
   if(h==INVALID_HANDLE)
     {
      Print("GST Bridge: cannot open symbol registry: ",InpUniverseRegistry," err=",GetLastError());
      return false;
     }

   // header: enabled,symbol,asset_group
   if(!FileIsEnding(h))
     {
      FileReadString(h); FileReadString(h); FileReadString(h);
     }

   while(!FileIsEnding(h))
     {
      string enabled_s=FileReadString(h);
      string symbol=GstTrim(FileReadString(h));
      string asset=GstTrim(FileReadString(h));
      if(symbol=="" && FileIsEnding(h)) break;
      if(!GstParseBool(enabled_s) || symbol=="") continue;
      if(!SymbolSelect(symbol,true))
        {
         Print("GST Bridge: SymbolSelect failed for ",symbol);
         continue;
        }
      int n=ArraySize(g_symbols);
      ArrayResize(g_symbols,n+1);
      g_symbols[n].enabled=true;
      g_symbols[n].symbol=symbol;
      g_symbols[n].asset_group=(asset=="" ? "UNKNOWN" : asset);
     }
   FileClose(h);
   Print("GST Bridge: loaded symbols=",ArraySize(g_symbols));
   return(ArraySize(g_symbols)>0);
  }

bool GstLoadTimezoneSchedule()
  {
   ArrayResize(g_tz_rules,0);
   if(!FileIsExist(InpTimezoneSchedule))
     {
      Print("GST Bridge: timezone schedule not found; fixed offset minutes=",InpFixedServerUtcOffsetMinutes);
      return true;
     }
   int h=FileOpen(InpTimezoneSchedule,FILE_READ|FILE_CSV|FILE_ANSI|FILE_SHARE_READ,',');
   if(h==INVALID_HANDLE)
     {
      Print("GST Bridge: timezone schedule open failed; using fixed offset. err=",GetLastError());
      return true;
     }
   // header: enabled,server_from,server_to,utc_offset_minutes
   if(!FileIsEnding(h))
     {
      FileReadString(h); FileReadString(h); FileReadString(h); FileReadString(h);
     }
   while(!FileIsEnding(h))
     {
      string enabled_s=FileReadString(h);
      string from_s=GstTrim(FileReadString(h));
      string to_s=GstTrim(FileReadString(h));
      string off_s=GstTrim(FileReadString(h));
      if(enabled_s=="" && from_s=="" && to_s=="" && off_s=="" && FileIsEnding(h)) break;
      if(!GstParseBool(enabled_s)) continue;
      int n=ArraySize(g_tz_rules);
      ArrayResize(g_tz_rules,n+1);
      g_tz_rules[n].enabled=true;
      g_tz_rules[n].server_from=(GstIsEmptyField(from_s) ? 0 : StringToTime(from_s));
      g_tz_rules[n].server_to=(GstIsEmptyField(to_s) ? 0 : StringToTime(to_s));
      g_tz_rules[n].utc_offset_minutes=(int)StringToInteger(off_s);
     }
   FileClose(h);
   Print("GST Bridge: loaded timezone rules=",ArraySize(g_tz_rules));
   return true;
  }

bool GstLoadSlotRegistry()
  {
   ArrayResize(g_maps,0);
   int h=FileOpen(InpSlotRegistry,FILE_READ|FILE_CSV|FILE_ANSI|FILE_SHARE_READ,',');
   if(h==INVALID_HANDLE)
     {
      Print("GST Bridge: cannot open slot registry: ",InpSlotRegistry," err=",GetLastError());
      return false;
     }

   // Fixed schema columns; NUMBER OF ROWS IS UNBOUNDED.
   // enabled,slot_id,slot_name,provider_type,indicator_path,handle_timeframe,
   // signal_timeframe,buy_buffer,sell_buffer,direction_buffer,buy_value,sell_value,
   // emit_on_change,symbols,live_buffer_shift,provider_version,provider_hash,horizon_bars
   for(int c=0;c<18;c++) FileReadString(h);

   while(!FileIsEnding(h))
     {
      string enabled_s       =FileReadString(h);
      string slot_id         =GstTrim(FileReadString(h));
      string slot_name       =GstTrim(FileReadString(h));
      string provider_type   =GstUpper(GstTrim(FileReadString(h)));
      string indicator_path  =GstTrim(FileReadString(h));
      string handle_tf_s     =GstTrim(FileReadString(h));
      string signal_tf_s     =GstTrim(FileReadString(h));
      string buy_buffer_s    =GstTrim(FileReadString(h));
      string sell_buffer_s   =GstTrim(FileReadString(h));
      string dir_buffer_s    =GstTrim(FileReadString(h));
      string buy_value_s     =GstTrim(FileReadString(h));
      string sell_value_s    =GstTrim(FileReadString(h));
      string change_s        =GstTrim(FileReadString(h));
      string symbols_filter  =GstTrim(FileReadString(h));
      string live_shift_s    =GstTrim(FileReadString(h));
      string provider_ver    =GstTrim(FileReadString(h));
      string provider_hash   =GstTrim(FileReadString(h));
      string horizon_s       =GstTrim(FileReadString(h));

      if(slot_id=="" && indicator_path=="" && FileIsEnding(h)) break;
      if(!GstParseBool(enabled_s)) continue;
      if(slot_id=="" || indicator_path=="")
        {
         Print("GST Bridge: skipping registry row with empty slot_id/indicator_path");
         continue;
        }
      ENUM_TIMEFRAMES handle_tf=GstTfFromString(handle_tf_s);
      ENUM_TIMEFRAMES signal_tf=GstTfFromString(signal_tf_s);
      if(handle_tf==PERIOD_CURRENT || signal_tf==PERIOD_CURRENT)
        {
         Print("GST Bridge: invalid TF in slot row ",slot_id," handle=",handle_tf_s," signal=",signal_tf_s);
         continue;
        }
      // Exact timestamp rule for the generic bridge. If one lower-TF handle
      // multiplexes higher-TF events, use a thin adapter at the actual signal TF.
      // Guessing source event timestamps is forbidden.
      if(handle_tf!=signal_tf)
        {
         Print("GST Bridge: handle_timeframe must equal signal_timeframe for generic provider; ",
               "use a thin adapter for shared multi-TF buffers. slot=",slot_id,
               " handle=",handle_tf_s," signal=",signal_tf_s);
         continue;
        }
      if(provider_type!="DUAL_BUFFER" && provider_type!="DIRECTION_BUFFER_EVENT" && provider_type!="DIRECTION_BUFFER_STATE")
        {
         Print("GST Bridge: unsupported provider_type=",provider_type," slot=",slot_id);
         continue;
        }
      int buy_buffer=(int)StringToInteger(buy_buffer_s);
      int sell_buffer=(int)StringToInteger(sell_buffer_s);
      int dir_buffer=(int)StringToInteger(dir_buffer_s);
      double buy_value=StringToDouble(buy_value_s);
      double sell_value=StringToDouble(sell_value_s);
      int live_shift=(int)StringToInteger(live_shift_s);
      int hb=(int)StringToInteger(horizon_s);
      if(provider_type=="DUAL_BUFFER" && (buy_buffer<0 || sell_buffer<0))
        {
         Print("GST Bridge: DUAL_BUFFER requires buy_buffer/sell_buffer >= 0 slot=",slot_id);
         continue;
        }
      if(provider_type!="DUAL_BUFFER" && dir_buffer<0)
        {
         Print("GST Bridge: direction provider requires direction_buffer >= 0 slot=",slot_id);
         continue;
        }
      if(provider_type!="DUAL_BUFFER" &&
         MathAbs(buy_value-sell_value)<=1.0e-8*MathMax(1.0,MathMax(MathAbs(buy_value),MathAbs(sell_value))))
        {
         Print("GST Bridge: direction provider requires distinct buy_value/sell_value slot=",slot_id);
         continue;
        }
      if(live_shift<1)
        {
         Print("GST Bridge: live_buffer_shift must be >=1 (closed bar) slot=",slot_id);
         continue;
        }

      int n=ArraySize(g_maps);
      ArrayResize(g_maps,n+1);
      g_maps[n].enabled=true;
      g_maps[n].slot_id=slot_id;
      g_maps[n].slot_name=(slot_name=="" ? slot_id : slot_name);
      g_maps[n].provider_type=provider_type;
      g_maps[n].indicator_path=indicator_path;
      g_maps[n].handle_tf=handle_tf;
      g_maps[n].signal_tf_text=GstTfToString(signal_tf);
      g_maps[n].signal_tf=signal_tf;
      g_maps[n].buy_buffer=buy_buffer;
      g_maps[n].sell_buffer=sell_buffer;
      g_maps[n].direction_buffer=dir_buffer;
      g_maps[n].buy_value=buy_value;
      g_maps[n].sell_value=sell_value;
      g_maps[n].emit_on_change=GstParseBool(change_s);
      g_maps[n].symbols_filter=(symbols_filter=="" ? "*" : symbols_filter);
      g_maps[n].live_buffer_shift=live_shift;
      g_maps[n].provider_version=(provider_ver=="" ? "UNSPECIFIED" : provider_ver);
      g_maps[n].provider_hash=provider_hash;
      g_maps[n].horizon_bars=(hb>0 ? hb : InpDefaultHorizonBars);
     }
   FileClose(h);
   Print("GST Bridge: loaded provider mappings=",ArraySize(g_maps)," (no slot-count limit)");
   return(ArraySize(g_maps)>0);
  }

bool GstSymbolMatchesFilter(string symbol,string filter)
  {
   filter=GstTrim(filter);
   if(filter=="" || filter=="*") return true;
   string items[];
   int n=StringSplit(filter,StringGetCharacter("|",0),items);
   for(int i=0;i<n;i++)
      if(GstUpper(GstTrim(items[i]))==GstUpper(symbol)) return true;
   return false;
  }

// --------------------------- Provider construction --------------------------
bool GstBuildProviderInstances()
  {
   ArrayResize(g_providers,0);
   g_provider_construction_failures=0;
   for(int m=0;m<ArraySize(g_maps);m++)
     {
      for(int s=0;s<ArraySize(g_symbols);s++)
        {
         if(!g_symbols[s].enabled) continue;
         if(!GstSymbolMatchesFilter(g_symbols[s].symbol,g_maps[m].symbols_filter)) continue;

         ResetLastError();
         int handle=iCustom(g_symbols[s].symbol,g_maps[m].handle_tf,g_maps[m].indicator_path);
         if(handle==INVALID_HANDLE)
           {
            Print("GST Bridge: iCustom failed slot=",g_maps[m].slot_id,
                  " symbol=",g_symbols[s].symbol," indicator=",g_maps[m].indicator_path,
                  " err=",GetLastError());
            g_provider_construction_failures++;
            continue;
           }
         int n=ArraySize(g_providers);
         ArrayResize(g_providers,n+1);
         g_providers[n].map_index=m;
         g_providers[n].symbol_index=s;
         g_providers[n].handle=handle;
         g_providers[n].last_live_decision_server=0;
         g_providers[n].bootstrap_failures=0;
        }
     }
   Print("GST Bridge: provider instances=",ArraySize(g_providers),
         " construction_failures=",g_provider_construction_failures," (registry-driven)");
   // Evidence capture is fail-closed. One missing enabled provider/symbol would
   // bias the sample and is therefore a deployment/configuration failure.
   return(ArraySize(g_providers)>0 && g_provider_construction_failures==0);
  }

// ------------------------------ Signal logic --------------------------------
bool GstSeenSignalId(string signal_id)
  {
   for(int i=0;i<ArraySize(g_seen_signal_ids);i++)
      if(g_seen_signal_ids[i]==signal_id) return true;
   return false;
  }

void GstRememberSignalId(string signal_id)
  {
   if(GstSeenSignalId(signal_id)) return;
   int n=ArraySize(g_seen_signal_ids);
   ArrayResize(g_seen_signal_ids,n+1);
   g_seen_signal_ids[n]=signal_id;
  }

bool GstLoadExistingSignalIds()
  {
   ArrayResize(g_seen_signal_ids,0);
   string path=InpExportDirectory+"\\signals.csv";
   if(!FileIsExist(path)) return true;
   int h=FileOpen(path,FILE_READ|FILE_CSV|FILE_ANSI|FILE_SHARE_READ,',');
   if(h==INVALID_HANDLE)
     {
      Print("GST Bridge: cannot read existing signals for dedupe err=",GetLastError());
      return false;
     }
   const int SIGNAL_COLUMNS=19;
   for(int c=0;c<SIGNAL_COLUMNS && !FileIsEnding(h);c++) FileReadString(h);
   while(!FileIsEnding(h))
     {
      string signal_id=GstTrim(FileReadString(h));
      for(int c=1;c<SIGNAL_COLUMNS && !FileIsEnding(h);c++) FileReadString(h);
      if(signal_id!="") GstRememberSignalId(signal_id);
     }
   FileClose(h);
   if(InpVerboseLog) Print("GST Bridge: loaded existing signal ids for dedupe=",ArraySize(g_seen_signal_ids));
   return true;
  }

bool GstValidSignalBufferValue(double v)
  {
   if(!MathIsValidNumber(v)) return false;
   if(v==EMPTY_VALUE) return false;
   if(MathAbs(v)>1.0e100) return false;
   return true;
  }

bool GstNear(double a,double b)
  {
   return(MathAbs(a-b)<=1.0e-8*MathMax(1.0,MathMax(MathAbs(a),MathAbs(b))));
  }

string GstMakeSignalId(int map_index,int symbol_index,datetime decision_server,string direction)
  {
   datetime utc=GstServerToUtc(decision_server);
   return GstSafeId(g_maps[map_index].slot_id)+"|"+
          GstSafeId(g_symbols[symbol_index].symbol)+"|"+
          GstSafeId(g_maps[map_index].signal_tf_text)+"|"+
          GstIsoUtc(utc)+"|"+direction;
  }

void GstStoreSignal(int map_index,int symbol_index,string direction,
                    datetime decision_server,datetime source_bar_open_server,double source_value,
                    string source_channel,bool append_to_file)
  {
   string signal_id=GstMakeSignalId(map_index,symbol_index,decision_server,direction);
   if(GstSeenSignalId(signal_id))
     {
      if(InpVerboseLog) Print("GST Bridge: duplicate signal_id suppressed: ",signal_id);
      return;
     }
   GstRememberSignalId(signal_id);
   int n=ArraySize(g_signals);
   ArrayResize(g_signals,n+1);
   g_signals[n].signal_id=signal_id;
   g_signals[n].map_index=map_index;
   g_signals[n].symbol_index=symbol_index;
   g_signals[n].direction=direction;
   g_signals[n].decision_server=decision_server;
   g_signals[n].source_bar_open_server=source_bar_open_server;
   g_signals[n].source_value=source_value;
   g_signals[n].source_channel=source_channel;

   if(append_to_file)
     {
      string path=InpExportDirectory+"\\signals.csv";
      bool exists=FileIsExist(path);
      int h=GstOpenCsvWrite(path,false);
      if(h==INVALID_HANDLE)
        {
         Print("GST Bridge: cannot append signals.csv err=",GetLastError());
         return;
        }
      if(!exists) GstWriteSignalsHeader(h);
      int off=GstUtcOffsetMinutesForServerTime(decision_server);
      FileWrite(h,
                signal_id,
                g_maps[map_index].slot_id,
                g_maps[map_index].slot_name,
                g_symbols[symbol_index].asset_group,
                g_symbols[symbol_index].symbol,
                g_maps[map_index].signal_tf_text,
                direction,
                GstIsoUtc(GstServerToUtc(decision_server)),
                GstServerTimeText(decision_server),
                GstServerTimeText(source_bar_open_server),
                DoubleToString(source_value,10),
                source_channel,
                g_maps[map_index].provider_type,
                g_maps[map_index].indicator_path,
                g_maps[map_index].provider_version,
                g_maps[map_index].provider_hash,
                GST_BRIDGE_VERSION,
                GST_SCHEMA_VERSION,
                off);
      FileFlush(h);
      FileClose(h);
     }
  }

bool GstWriteAllSignalsCsv()
  {
   string path=InpExportDirectory+"\\signals.csv";
   int h=GstOpenCsvWrite(path,true);
   if(h==INVALID_HANDLE)
     {
      Print("GST Bridge: cannot write signals.csv err=",GetLastError());
      return false;
     }
   GstWriteSignalsHeader(h);
   for(int i=0;i<ArraySize(g_signals);i++)
     {
      int m=g_signals[i].map_index;
      int s=g_signals[i].symbol_index;
      int off=GstUtcOffsetMinutesForServerTime(g_signals[i].decision_server);
      FileWrite(h,
                g_signals[i].signal_id,
                g_maps[m].slot_id,
                g_maps[m].slot_name,
                g_symbols[s].asset_group,
                g_symbols[s].symbol,
                g_maps[m].signal_tf_text,
                g_signals[i].direction,
                GstIsoUtc(GstServerToUtc(g_signals[i].decision_server)),
                GstServerTimeText(g_signals[i].decision_server),
                GstServerTimeText(g_signals[i].source_bar_open_server),
                DoubleToString(g_signals[i].source_value,10),
                g_signals[i].source_channel,
                g_maps[m].provider_type,
                g_maps[m].indicator_path,
                g_maps[m].provider_version,
                g_maps[m].provider_hash,
                GST_BRIDGE_VERSION,
                GST_SCHEMA_VERSION,
                off);
     }
   FileFlush(h);
   FileClose(h);
   return true;
  }

// ------------------------- Historical signal bootstrap ----------------------
bool GstCopyDirectionSeries(int handle,int buffer_num,datetime from,datetime to,double &values[])
  {
   ArrayResize(values,0);
   ResetLastError();
   int n=CopyBuffer(handle,buffer_num,from,to,values);
   if(n<0)
     {
      if(InpVerboseLog) Print("GST Bridge: CopyBuffer error buffer=",buffer_num," err=",GetLastError());
      return false;
     }
   return true;
  }

bool GstBootstrapProvider(int provider_index)
  {
   if(provider_index<0 || provider_index>=ArraySize(g_providers)) return false;
   int m=g_providers[provider_index].map_index;
   int s=g_providers[provider_index].symbol_index;
   string symbol=g_symbols[s].symbol;
   ENUM_TIMEFRAMES htf=g_maps[m].handle_tf;
   datetime to=(InpHistoryEndServer>0 ? InpHistoryEndServer : TimeTradeServer());
   datetime from=InpHistoryStartServer;
   if(from<=0)
     {
      long first=0;
      if(SeriesInfoInteger(symbol,htf,SERIES_FIRSTDATE,first) && first>0)
         from=(datetime)first;
      else
         from=(datetime)(to-(long)PeriodSeconds(htf)*5000L);
     }

   datetime times[];
   ArrayResize(times,0);
   int nt=CopyTime(symbol,htf,from,to,times);
   if(nt<=0)
     {
      Print("GST Bridge: no time series slot=",g_maps[m].slot_id," symbol=",symbol," tf=",GstTfToString(htf));
      return false;
     }

   string pt=g_maps[m].provider_type;
   if(pt=="DUAL_BUFFER")
     {
      double buy[],sell[];
      if(!GstCopyDirectionSeries(g_providers[provider_index].handle,g_maps[m].buy_buffer,from,to,buy)) return false;
      if(!GstCopyDirectionSeries(g_providers[provider_index].handle,g_maps[m].sell_buffer,from,to,sell)) return false;
      if(ArraySize(buy)!=nt || ArraySize(sell)!=nt)
        {
         Print("GST Bridge: CopyTime/CopyBuffer alignment mismatch slot=",g_maps[m].slot_id,
               " symbol=",symbol," times=",nt," buy=",ArraySize(buy)," sell=",ArraySize(sell));
         return false;
        }
      int n=nt;
      for(int i=0;i<n;i++)
        {
         datetime decision=times[i]+PeriodSeconds(htf);
         if(decision>TimeTradeServer()) continue; // never freeze an open bar
         bool b=GstValidSignalBufferValue(buy[i]);
         bool q=GstValidSignalBufferValue(sell[i]);
         if(b && q)
           {
            if(InpVerboseLog) Print("GST Bridge: conflicting BUY/SELL buffers skipped slot=",g_maps[m].slot_id,
                                    " symbol=",symbol," time=",GstServerTimeText(decision));
            continue;
           }
         if(b) GstStoreSignal(m,s,"BUY",decision,times[i],buy[i],"BUY_BUFFER",false);
         if(q) GstStoreSignal(m,s,"SELL",decision,times[i],sell[i],"SELL_BUFFER",false);
        }
     }
   else
     {
      double dir[];
      if(!GstCopyDirectionSeries(g_providers[provider_index].handle,g_maps[m].direction_buffer,from,to,dir)) return false;
      if(ArraySize(dir)!=nt)
        {
         Print("GST Bridge: CopyTime/CopyBuffer alignment mismatch slot=",g_maps[m].slot_id,
               " symbol=",symbol," times=",nt," direction=",ArraySize(dir));
         return false;
        }
      int n=nt;
      double prev=0.0;
      bool prev_valid=false;
      for(int i=0;i<n;i++)
        {
         datetime decision=times[i]+PeriodSeconds(htf);
         if(decision>TimeTradeServer()) continue;
         double v=dir[i];
         bool valid=GstValidSignalBufferValue(v);
         if(!valid)
           {
            prev_valid=false;
            continue;
           }
         bool buy=GstNear(v,g_maps[m].buy_value);
         bool sell=GstNear(v,g_maps[m].sell_value);
         if(buy && sell) continue;

         bool emit_buy=buy;
         bool emit_sell=sell;
         if(pt=="DIRECTION_BUFFER_STATE" || g_maps[m].emit_on_change)
           {
            // Initial valid state establishes baseline only; it is not a transition.
            if(!prev_valid)
              {
               prev=v;
               prev_valid=true;
               continue;
              }
            emit_buy=buy && !GstNear(prev,g_maps[m].buy_value);
            emit_sell=sell && !GstNear(prev,g_maps[m].sell_value);
           }
         if(emit_buy)  GstStoreSignal(m,s,"BUY",decision,times[i],v,"DIRECTION_BUFFER",false);
         if(emit_sell) GstStoreSignal(m,s,"SELL",decision,times[i],v,"DIRECTION_BUFFER",false);
         prev=v;
         prev_valid=true;
        }
     }

   if(InpVerboseLog)
      Print("GST Bridge: bootstrapped provider ",provider_index+1,"/",ArraySize(g_providers),
            " slot=",g_maps[m].slot_id," symbol=",symbol);
   return true;
  }

// ----------------------------- Live polling ---------------------------------
bool GstReadBufferOne(int handle,int buffer_num,int shift,double &out)
  {
   double a[1];
   ResetLastError();
   int n=CopyBuffer(handle,buffer_num,shift,1,a);
   if(n!=1) return false;
   out=a[0];
   return true;
  }

void GstPollProviderLive(int provider_index)
  {
   if(provider_index<0 || provider_index>=ArraySize(g_providers)) return;
   int m=g_providers[provider_index].map_index;
   int s=g_providers[provider_index].symbol_index;
   string symbol=g_symbols[s].symbol;
   int shift=g_maps[m].live_buffer_shift;

   datetime bt[1];
   if(CopyTime(symbol,g_maps[m].handle_tf,shift,1,bt)!=1) return;
   datetime decision=bt[0]+PeriodSeconds(g_maps[m].handle_tf);
   if(decision>TimeTradeServer()) return;
   if(g_providers[provider_index].last_live_decision_server==decision) return;

   string pt=g_maps[m].provider_type;
   if(pt=="DUAL_BUFFER")
     {
      double b=EMPTY_VALUE,q=EMPTY_VALUE;
      bool hb=GstReadBufferOne(g_providers[provider_index].handle,g_maps[m].buy_buffer,shift,b);
      bool hs=GstReadBufferOne(g_providers[provider_index].handle,g_maps[m].sell_buffer,shift,q);
      bool buy=hb && GstValidSignalBufferValue(b);
      bool sell=hs && GstValidSignalBufferValue(q);
      if(buy && sell) return;
      if(buy)  GstStoreSignal(m,s,"BUY",decision,bt[0],b,"BUY_BUFFER",true);
      if(sell) GstStoreSignal(m,s,"SELL",decision,bt[0],q,"SELL_BUFFER",true);
      g_providers[provider_index].last_live_decision_server=decision;
     }
   else
     {
      double cur=EMPTY_VALUE;
      if(!GstReadBufferOne(g_providers[provider_index].handle,g_maps[m].direction_buffer,shift,cur)) return;
      if(!GstValidSignalBufferValue(cur)) return;
      bool buy=GstNear(cur,g_maps[m].buy_value);
      bool sell=GstNear(cur,g_maps[m].sell_value);
      if(buy && sell) return;
      if(pt=="DIRECTION_BUFFER_STATE" || g_maps[m].emit_on_change)
        {
         double prev=EMPTY_VALUE;
         bool hp=GstReadBufferOne(g_providers[provider_index].handle,g_maps[m].direction_buffer,shift+1,prev);
         if(!hp || !GstValidSignalBufferValue(prev)) return;
         if(buy && GstNear(prev,g_maps[m].buy_value)) buy=false;
         if(sell && GstNear(prev,g_maps[m].sell_value)) sell=false;
        }
      if(buy)  GstStoreSignal(m,s,"BUY",decision,bt[0],cur,"DIRECTION_BUFFER",true);
      if(sell) GstStoreSignal(m,s,"SELL",decision,bt[0],cur,"DIRECTION_BUFFER",true);
      g_providers[provider_index].last_live_decision_server=decision;
     }
  }

// ------------------------------- Bar export ---------------------------------
bool GstSeriesAlreadyHandled(int provider_index)
  {
   int s=g_providers[provider_index].symbol_index;
   int m=g_providers[provider_index].map_index;
   for(int i=0;i<provider_index;i++)
     {
      int ps=g_providers[i].symbol_index;
      int pm=g_providers[i].map_index;
      if(g_symbols[ps].symbol==g_symbols[s].symbol && g_maps[pm].signal_tf==g_maps[m].signal_tf)
         return true;
     }
   return false;
  }

bool GstExportBarsCsv()
  {
   if(!InpExportBars)
     {
      Print("GST Bridge: bars export disabled; bootstrap evidence is incomplete");
      return false;
     }
   string path=InpExportDirectory+"\\bars.csv";
   int h=GstOpenCsvWrite(path,true);
   if(h==INVALID_HANDLE)
     {
      Print("GST Bridge: cannot write bars.csv err=",GetLastError());
      return false;
     }
   bool export_ok=true;
   GstWriteBarsHeader(h);
   datetime now=(InpHistoryEndServer>0 ? InpHistoryEndServer : TimeTradeServer());

   for(int p=0;p<ArraySize(g_providers);p++)
     {
      if(GstSeriesAlreadyHandled(p)) continue;
      int m=g_providers[p].map_index;
      int s=g_providers[p].symbol_index;
      string symbol=g_symbols[s].symbol;
      ENUM_TIMEFRAMES tf=g_maps[m].signal_tf;
      datetime from=InpHistoryStartServer;
      if(from<=0)
        {
         long first=0;
         if(SeriesInfoInteger(symbol,tf,SERIES_FIRSTDATE,first) && first>0) from=(datetime)first;
         else from=(datetime)(now-(long)PeriodSeconds(tf)*5000L);
        }
      MqlRates rates[];
      ArrayResize(rates,0);
      int n=CopyRates(symbol,tf,from,now,rates);
      if(n<=0)
        {
         Print("GST Bridge: no bars export symbol=",symbol," tf=",GstTfToString(tf));
         export_ok=false;
         break;
        }
      int digits=(int)SymbolInfoInteger(symbol,SYMBOL_DIGITS);
      for(int i=0;i<n;i++)
        {
         datetime close_time=rates[i].time+PeriodSeconds(tf);
         if(close_time>TimeTradeServer()) continue;
         int off=GstUtcOffsetMinutesForServerTime(rates[i].time);
         FileWrite(h,
                   GstIsoUtc(GstServerToUtc(rates[i].time)),
                   symbol,
                   GstTfToString(tf),
                   DoubleToString(rates[i].open,digits),
                   DoubleToString(rates[i].high,digits),
                   DoubleToString(rates[i].low,digits),
                   DoubleToString(rates[i].close,digits),
                   (long)rates[i].tick_volume,
                   rates[i].spread,
                   GstServerTimeText(rates[i].time),
                   off);
        }
      FileFlush(h);
     }
   FileClose(h);
   if(export_ok) Print("GST Bridge: bars.csv export complete");
   return export_ok;
  }

// ------------------------------- Tick export --------------------------------
bool GstSignalRangeForSymbol(int symbol_index,datetime &from_server,datetime &to_server)
  {
   bool found=false;
   from_server=0;
   to_server=0;
   for(int i=0;i<ArraySize(g_signals);i++)
     {
      if(g_signals[i].symbol_index!=symbol_index) continue;
      int m=g_signals[i].map_index;
      int sec=PeriodSeconds(g_maps[m].signal_tf);
      if(sec<=0) sec=60;
      datetime a=(datetime)((long)g_signals[i].decision_server-(long)InpOffsetPaddingBeforeBars*sec);
      datetime b=(datetime)((long)g_signals[i].decision_server+
                            (long)(InpOffsetPaddingAfterBars+g_maps[m].horizon_bars)*sec);
      if(!found || a<from_server) from_server=a;
      if(!found || b>to_server) to_server=b;
      found=true;
     }
   return found;
  }

bool GstExportTicksCsv()
  {
   if(InpTickExportMode==GST_TICKS_NONE)
     {
      Print("GST Bridge: tick export disabled; bootstrap evidence is incomplete");
      return false;
     }
   string path=InpExportDirectory+"\\ticks.csv";
   int h=GstOpenCsvWrite(path,true);
   if(h==INVALID_HANDLE)
     {
      Print("GST Bridge: cannot write ticks.csv err=",GetLastError());
      return false;
     }
   bool export_ok=true;
   GstWriteTicksHeader(h);

   const long DAY_SECONDS=86400L;
   for(int s=0;s<ArraySize(g_symbols);s++)
     {
      datetime from_server=0,to_server=0;
      if(!GstSignalRangeForSymbol(s,from_server,to_server)) continue;
      string symbol=g_symbols[s].symbol;
      datetime cursor=from_server;
      int digits=(int)SymbolInfoInteger(symbol,SYMBOL_DIGITS);
      while(cursor<=to_server)
        {
         datetime chunk_to=(datetime)MathMin((long)to_server,(long)cursor+DAY_SECONDS-1L);
         MqlTick ticks[];
         ArrayResize(ticks,0);
         ulong from_msc=(ulong)((long)cursor*1000L);
         ulong to_msc=(ulong)((long)chunk_to*1000L+999L);
         ResetLastError();
         int n=CopyTicksRange(symbol,ticks,COPY_TICKS_INFO,from_msc,to_msc);
         if(n<0)
           {
            Print("GST Bridge: CopyTicksRange failed symbol=",symbol," from=",GstServerTimeText(cursor),
                  " err=",GetLastError());
            g_bootstrap_failed=true;
            g_bootstrap_failed_providers++;
            export_ok=false;
            break;
           }
         for(int i=0;i<n;i++)
           {
            int off=GstUtcOffsetMinutesForServerTime(ticks[i].time);
            FileWrite(h,
                      GstIsoUtcMsc((long)ticks[i].time_msc,ticks[i].time),
                      symbol,
                      DoubleToString(ticks[i].bid,digits),
                      DoubleToString(ticks[i].ask,digits),
                      DoubleToString(ticks[i].last,digits),
                      DoubleToString(ticks[i].volume_real,4),
                      (uint)ticks[i].flags,
                      GstServerTimeText(ticks[i].time),
                      off);
           }
         FileFlush(h);
         cursor=(datetime)((long)chunk_to+1L);
        }
      if(!export_ok) break;
      Print("GST Bridge: ticks exported symbol=",symbol," range=",GstServerTimeText(from_server),
            " .. ",GstServerTimeText(to_server));
     }
   FileClose(h);
   if(export_ok) Print("GST Bridge: ticks.csv export complete");
   return export_ok;
  }

// ------------------------------ Manifest ------------------------------------
void GstWriteManifest()
  {
   string path=InpExportDirectory+"\\bridge_manifest.csv";
   int h=GstOpenCsvWrite(path,true);
   if(h==INVALID_HANDLE) return;
   FileWrite(h,"key","value");
   FileWrite(h,"bridge_version",GST_BRIDGE_VERSION);
   FileWrite(h,"schema_version",GST_SCHEMA_VERSION);
   FileWrite(h,"provider_mapping_count",ArraySize(g_maps));
   FileWrite(h,"symbol_count",ArraySize(g_symbols));
   FileWrite(h,"provider_instance_count",ArraySize(g_providers));
   FileWrite(h,"provider_construction_failures",g_provider_construction_failures);
   FileWrite(h,"bootstrap_failed_provider_count",g_bootstrap_failed_providers);
   FileWrite(h,"bootstrap_status",(g_bootstrap_failed ? "FAILED" : (g_bootstrap_complete ? "PASS" : "IN_PROGRESS")));
   FileWrite(h,"frozen_signal_count",ArraySize(g_signals));
   FileWrite(h,"slot_count_limit","NONE");
   FileWrite(h,"registry_driven_slots","true");
   FileWrite(h,"bridge_mode",IntegerToString((int)InpMode));
   FileWrite(h,"live_market_data_refresh","NONE_SIGNAL_POLL_ONLY");
   FileWrite(h,"history_start_server",GstServerTimeText(InpHistoryStartServer));
   FileWrite(h,"history_end_server",GstServerTimeText(InpHistoryEndServer));
   FileWrite(h,"fixed_server_utc_offset_minutes",InpFixedServerUtcOffsetMinutes);
   FileWrite(h,"timezone_rule_count",ArraySize(g_tz_rules));
   FileWrite(h,"offset_padding_before_bars",InpOffsetPaddingBeforeBars);
   FileWrite(h,"offset_padding_after_bars",InpOffsetPaddingAfterBars);
   FileWrite(h,"generated_server_time",GstServerTimeText(TimeTradeServer()));
   FileWrite(h,"generated_utc",GstIsoUtc(GstServerToUtc(TimeTradeServer())));
   FileFlush(h);
   FileClose(h);
  }

// ----------------------------- Bootstrap state ------------------------------
void GstStartBootstrap()
  {
   if(g_bootstrap_started) return;
   g_bootstrap_started=true;
   g_bootstrap_complete=false;
   g_bootstrap_failed=false;
   g_bootstrap_failed_providers=0;
   g_bootstrap_provider_cursor=0;
   ArrayResize(g_signals,0);
   ArrayResize(g_seen_signal_ids,0);
   // Bootstrap always creates a fresh immutable evidence snapshot. Mixing old
   // and new history/provider configurations inside one export is forbidden.
   FileDelete(InpExportDirectory+"\\signals.csv");
   FileDelete(InpExportDirectory+"\\bars.csv");
   FileDelete(InpExportDirectory+"\\ticks.csv");
   FileDelete(InpExportDirectory+"\\bridge_manifest.csv");
   Print("GST Bridge: bootstrap started; providers=",ArraySize(g_providers));
  }

void GstBootstrapStep()
  {
   if(!g_bootstrap_started || g_bootstrap_complete) return;
   int budget=MathMax(1,InpProvidersPerTimer);
   for(int k=0;k<budget && g_bootstrap_provider_cursor<ArraySize(g_providers);k++)
     {
      int idx=g_bootstrap_provider_cursor;
      bool ok=GstBootstrapProvider(idx);
      if(ok)
        {
         g_providers[idx].bootstrap_failures=0;
         g_bootstrap_provider_cursor++;
        }
      else
        {
         g_providers[idx].bootstrap_failures++;
         if(g_providers[idx].bootstrap_failures>=MathMax(1,InpMaxProviderBootstrapRetries))
           {
            int m=g_providers[idx].map_index;
            int si=g_providers[idx].symbol_index;
            Print("GST Bridge: provider bootstrap FAILED after retries; bootstrap aborted. slot=",
                  g_maps[m].slot_id," symbol=",g_symbols[si].symbol," retries=",g_providers[idx].bootstrap_failures);
            g_bootstrap_failed=true;
            g_bootstrap_failed_providers++;
            GstWriteManifest();
            EventKillTimer();
            return;
           }
         else
           {
            // History/indicator calculation may still be loading. Retry this provider
            // on a later timer cycle; do not silently export misaligned evidence.
            break;
           }
        }
     }
   if(g_bootstrap_provider_cursor>=ArraySize(g_providers))
     {
      bool signals_ok=GstWriteAllSignalsCsv();
      bool bars_ok=GstExportBarsCsv();
      bool ticks_ok=GstExportTicksCsv();
      if(!signals_ok || !bars_ok || !ticks_ok || g_bootstrap_failed)
        {
         g_bootstrap_failed=true;
         g_bootstrap_complete=false;
         GstWriteManifest();
         Print("GST Bridge: bootstrap EXPORT FAILED; signals_ok=",signals_ok,
               " bars_ok=",bars_ok," ticks_ok=",ticks_ok);
         EventKillTimer();
         return;
        }
      g_bootstrap_complete=true;
      GstWriteManifest();
      Print("GST Bridge: bootstrap COMPLETE. frozen signals=",ArraySize(g_signals));
      if(InpMode==GST_BOOTSTRAP_ONLY)
         EventKillTimer();
     }
  }

void GstLiveStep()
  {
   if(ArraySize(g_providers)==0) return;
   int budget=MathMax(1,InpProvidersPerTimer);
   for(int k=0;k<budget;k++)
     {
      if(g_live_provider_cursor>=ArraySize(g_providers)) g_live_provider_cursor=0;
      GstPollProviderLive(g_live_provider_cursor);
      g_live_provider_cursor++;
     }
  }

// -------------------------------- Lifecycle ---------------------------------
int OnInit()
  {
   if(InpTimerSeconds<1 || InpProvidersPerTimer<1 || InpDefaultHorizonBars<1 || InpMaxProviderBootstrapRetries<1)
     {
      Print("GST Bridge: invalid input parameters");
      return INIT_PARAMETERS_INCORRECT;
     }
   GstEnsureExportDirectory();
   GstLoadTimezoneSchedule();
   if(!GstLoadSymbolRegistry()) return INIT_FAILED;
   if(!GstLoadSlotRegistry()) return INIT_FAILED;
   if(!GstBuildProviderInstances()) return INIT_FAILED;

   if(InpMode!=GST_LIVE_ONLY) GstStartBootstrap();
   else
     {
      g_bootstrap_complete=true;
      // LIVE_ONLY appends but imports prior IDs first, preventing duplicates
      // after terminal restart.
      if(!GstLoadExistingSignalIds()) return INIT_FAILED;
     }

   EventSetTimer(InpTimerSeconds);
   Print("GST Bridge initialized. current registry mappings=",ArraySize(g_maps),
         ", providers=",ArraySize(g_providers),", slot limit=NONE");
   return INIT_SUCCEEDED;
  }

void OnTimer()
  {
   if(InpMode!=GST_LIVE_ONLY && !g_bootstrap_complete)
     {
      GstBootstrapStep();
      return;
     }
   if(InpMode==GST_BOOTSTRAP_AND_LIVE || InpMode==GST_LIVE_ONLY)
      GstLiveStep();
  }

void OnDeinit(const int reason)
  {
   EventKillTimer();
   for(int i=0;i<ArraySize(g_providers);i++)
     {
      if(g_providers[i].handle!=INVALID_HANDLE)
         IndicatorRelease(g_providers[i].handle);
     }
   Print("GST Bridge deinitialized reason=",reason);
  }

# GST 2.0 MT5 Bridge — installation / evidence capture

1. Copy `Experts/SMD/GST/GST_MT5_Bridge.mq5` to `MQL5/Experts/SMD/GST/`.
2. Copy `Files/GST/` registry files to `MQL5/Files/GST/`.
3. Replace disabled template rows with real slot/source mappings and provider hashes. The current 23-row template is only a convenience; the bridge has no source-count limit.
4. Populate `symbol_registry.csv` and broker timezone/DST rules.
5. Compile the EA in MetaEditor on the target installation.
6. For production GST evidence, run **`GST_BOOTSTRAP_ONLY`** and preserve the resulting frozen `signals.csv`, `bars.csv`, `ticks.csv`, and `bridge_manifest.csv` together.

## Provider contract

Generic providers support separate BUY/SELL buffers or a direction/event buffer. `handle_timeframe` must equal the true `signal_timeframe`; multi-TF multiplexers require thin source-TF adapters so the bridge never guesses timestamps. `live_buffer_shift >= 1` enforces closed-bar polling.

The bridge does not calculate GST SL/TP/RR and does not know source formulas. It freezes final source signals and market-data evidence only.

## Fail-closed bootstrap

A valid bootstrap requires every enabled provider instance plus all three exports:

- `signals.csv`;
- `bars.csv`;
- `ticks.csv`.

Provider construction failure, historical buffer failure, missing bar export, `CopyTicksRange` failure, or file-open failure sets bootstrap FAILED and prevents `bootstrap_complete=true`.

## Live mode

`BOOTSTRAP_AND_LIVE` / `LIVE_ONLY` can freeze later source signals, but the bridge does not continuously refresh the historical bars/ticks archive. Therefore live-mode files are not accepted as a frozen production GST dataset. Create a new `BOOTSTRAP_ONLY` export before production analysis.

## Current 23 slots

There are currently 23 project slots, but no `MAX_SLOTS`/23 loop exists. Slot 24, 100, etc. are registry additions, not core-code changes.

## External acceptance

The included MQL5 source is statically reviewed in this package, but it has not been compiled/run on the user's target MT5/broker from this environment. MetaEditor compilation, provider mapping verification, streaming/repaint tests and actual broker reconciliation remain mandatory.

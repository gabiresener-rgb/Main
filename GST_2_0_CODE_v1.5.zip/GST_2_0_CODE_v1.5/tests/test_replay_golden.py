from gst2.domain.models import CloseReason, Direction, EpisodeStatus, JointCandidate, SignalOutcome
from gst2.replay.five_order import ExecutionPolicy, replay_episode
from helpers import make_episode

C = JointCandidate(0, 0.35, (0.4, 0.7, 1.2, 2.0, 3.0))
P = ExecutionPolicy(modified_stop_profit_pct=0.10)


def test_initial_sl_then_later_tp5_is_bad_forever():
    e = make_episode([0.0, -0.40, 1.20])
    r = replay_episode(e, C, P)
    assert r.outcome is SignalOutcome.BAD
    assert all(o.close_reason is CloseReason.INITIAL_SL for o in r.orders)


def test_tp1_then_be_plus_point_one_is_tp1_and_four_modified_closes():
    e = make_episode([0.0, 0.15, 0.05])
    r = replay_episode(e, C, P)
    assert r.outcome is SignalOutcome.TP1
    assert r.modified_stop_close_count == 4
    assert r.orders[0].close_reason is CloseReason.TARGET
    assert all(o.close_reason is CloseReason.MODIFIED_SL for o in r.orders[1:])


def test_tp2_then_modified_stop_is_tp2():
    e = make_episode([0.0, 0.26, 0.05])
    r = replay_episode(e, C, P)
    assert r.outcome is SignalOutcome.TP2
    assert r.modified_stop_close_count == 3


def test_tp4_then_modified_stop_is_tp4():
    e = make_episode([0.0, 0.71, 0.05])
    r = replay_episode(e, C, P)
    assert r.outcome is SignalOutcome.TP4
    assert r.modified_stop_close_count == 1


def test_tp5_hit():
    e = make_episode([0.0, 1.06])
    r = replay_episode(e, C, P)
    assert r.outcome is SignalOutcome.TP5
    assert r.modified_stop_close_count == 0
    assert all(o.close_reason is CloseReason.TARGET for o in r.orders)


def test_sell_symmetry():
    e = make_episode([0.0, 0.26, 0.05], direction=Direction.SELL)
    r = replay_episode(e, C, P)
    assert r.outcome is SignalOutcome.TP2


def test_bid_ask_side_prevents_false_mid_target():
    # BUY exit evidence uses Bid.  Mid would be at/above TP1 but Bid is not.
    e = make_episode([0.0])
    p = e.path[0]
    # replace one-point path with bid +0.13%, ask +0.15%; mid +0.14%.
    from gst2.domain.models import MarketPoint, RawEpisode
    bid = 100.13
    ask = 100.15
    ep = RawEpisode(e.episode_id, e.seed, e.scenario, e.horizon_end, (MarketPoint(p.ts, bid, ask),))
    r = replay_episode(ep, C, P)
    assert r.outcome is None
    assert r.completion_status is EpisodeStatus.UNRESOLVED_TIMEOUT
    assert not r.orders


def test_gap_crosses_multiple_targets():
    e = make_episode([0.0, 1.20])
    r = replay_episode(e, C, P)
    assert r.outcome is SignalOutcome.TP5


def test_child_weights_change_pool_not_episode_count():
    e = make_episode([0.0, 0.15, 0.05])
    r1 = replay_episode(e, C, ExecutionPolicy(order_weights=(1,1,1,1,1)))
    r2 = replay_episode(e, C, ExecutionPolicy(order_weights=(2,2,2,2,2)))
    assert r2.pool_net_R == r1.pool_net_R
    assert r2.pool_order_R_sum == r1.pool_order_R_sum * 2
    assert len(r1.orders) == len(r2.orders) == 5


def test_candidate_rejects_tp1_below_be_level():
    import pytest
    bad = JointCandidate(0, 0.20, (0.4, 0.7, 1.2, 2.0, 3.0))  # TP1=0.08% < +0.1%
    with pytest.raises(ValueError):
        replay_episode(make_episode([0.0, 0.2]), bad, P)

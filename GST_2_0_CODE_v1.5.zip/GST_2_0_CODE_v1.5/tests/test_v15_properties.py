from __future__ import annotations

import random
from datetime import datetime, timedelta, timezone

import pytest

from gst2.domain.models import CausalityStatus, Direction, InstrumentSpec, JointCandidate, MarketPoint, OffsetScenario, RawEpisode, SignalSeed
from gst2.metrics.core import distribution_sums_to_100, mark_to_market_drawdown, summarize_replayed
from gst2.replay.five_order import ExecutionPolicy, replay_episode


def _episode(direction: Direction, moves: list[float], signal_id: str) -> RawEpisode:
    t0=datetime(2026,1,1,tzinfo=timezone.utc)
    entry=100.0
    seed=SignalSeed(signal_id,'1','FOREX','EURUSD','H1',direction,t0,provider_hash='PH',source_channel='BUY_BUFFER' if direction is Direction.BUY else 'SELL_BUFFER')
    sc=OffsetScenario(signal_id,0,t0,t0,t0,entry,t0,CausalityStatus.STANDARD_CAUSAL,True)
    points=[]
    for i,m in enumerate(moves):
        px=entry*(1+(m/100.0 if direction is Direction.BUY else -m/100.0))
        points.append(MarketPoint(t0+timedelta(minutes=i),px,px))
    return RawEpisode(signal_id+'|0',seed,sc,points[-1].ts,tuple(points))


def test_random_account_pool_r_matches_net_pnl_over_initial_pool_risk():
    rng=random.Random(20260926)
    spec=InstrumentSpec(
        'EURUSD',tick_size=0.01,commission_per_order_account=0.25,
        value_per_price_unit_per_unit=10.0,order_units=2.0,account_currency='USD',spec_id='PROP',
    )
    policy=ExecutionPolicy(instrument_specs={'EURUSD':spec},require_instrument_specs=True,require_account_economics=True)
    candidate=JointCandidate(0,0.60,(0.5,1.0,1.5,2.0,3.0))
    for i in range(100):
        direction=Direction.BUY if i%2==0 else Direction.SELL
        moves=[0.0]
        level=0.0
        for _ in range(8):
            level += rng.uniform(-0.45,0.45)
            moves.append(level)
        result=replay_episode(_episode(direction,moves,f'P{i:03d}'),candidate,policy)
        assert result.pool_net_pnl_account is not None
        base_risk=abs(result.entry_price-result.initial_sl_price)*spec.value_per_price_unit_per_unit*spec.order_units
        total_initial_pool_risk=base_risk*sum(policy.order_weights)
        assert total_initial_pool_risk>0
        assert result.pool_R == pytest.approx(result.pool_net_pnl_account/total_initial_pool_risk,abs=1e-12)


def test_mtm_drawdown_is_invariant_to_episode_input_order():
    candidate=JointCandidate(0,1.0,(2.0,3.0,4.0,5.0,6.0))
    p=ExecutionPolicy(default_tick_size=0.01)
    rows=[]
    for i,(direction,moves) in enumerate([
        (Direction.BUY,[0,.4,.1]),(Direction.SELL,[0,.2,-.1]),(Direction.BUY,[0,-.3,.2])
    ]):
        rows.append(replay_episode(_episode(direction,moves,f'O{i}'),candidate,p))
    a=mark_to_market_drawdown([],rows)
    b=mark_to_market_drawdown([],list(reversed(rows)))
    assert a==pytest.approx(b,abs=1e-12)


def test_completed_distribution_is_conditional_and_still_sums_to_100_with_open_positions_present():
    c=JointCandidate(0,0.35,(0.4,0.7,1.2,2.0,3.0))
    p=ExecutionPolicy(default_tick_size=0.00001)
    complete=replay_episode(_episode(Direction.BUY,[0,1.2],'C'),c,p)
    unresolved=replay_episode(_episode(Direction.BUY,[0,-0.1],'U'),c,p)
    m=summarize_replayed(c,[complete,unresolved],source_signal_count=2,built_episode_count=2)
    assert m.episode_count==1
    assert m.financial_episode_count==2
    assert distribution_sums_to_100(m)
    assert m.distribution_excluded_count==1


def test_open_loss_cannot_improve_expectancy_by_becoming_unresolved():
    c=JointCandidate(0,0.35,(0.4,0.7,1.2,2.0,3.0))
    p=ExecutionPolicy(default_tick_size=0.00001)
    winner=replay_episode(_episode(Direction.BUY,[0,1.2],'W'),c,p)
    flat=replay_episode(_episode(Direction.BUY,[0,0.0],'F'),c,p)
    loser=replay_episode(_episode(Direction.BUY,[0,-0.2],'L'),c,p)
    m_flat=summarize_replayed(c,[winner,flat],source_signal_count=2,built_episode_count=2)
    m_loss=summarize_replayed(c,[winner,loser],source_signal_count=2,built_episode_count=2)
    assert m_loss.pool_expectancy_R_per_episode < m_flat.pool_expectancy_R_per_episode

from gst2.domain.models import JointCandidate
from gst2.metrics.core import distribution_sums_to_100, summarize_replayed
from gst2.replay.five_order import ExecutionPolicy, replay_episode
from helpers import make_episode


def test_six_classes_sum_to_100():
    c = JointCandidate(0, 0.35, (0.4,0.7,1.2,2,3))
    paths = [
        [0,-0.4], [0,0.15,0.05], [0,0.26,0.05], [0,0.43,0.05], [0,0.71,0.05], [0,1.06]
    ]
    rows = [replay_episode(make_episode(p, signal_id=f"S{i}"), c, ExecutionPolicy()) for i,p in enumerate(paths)]
    m = summarize_replayed(c, rows)
    assert distribution_sums_to_100(m)
    assert all(abs(x - 100/6) < 1e-8 for x in [m.bad_pct,m.tp1_pct,m.tp2_pct,m.tp3_pct,m.tp4_pct,m.tp5_pct])


def test_tp_pct_rr_consistency():
    c = JointCandidate(0, 0.40, (0.5,0.9,1.5,2.4,3.7))
    assert c.tp_pct_ladder == (0.2,0.36,0.6,0.96,1.48)

from gst2.config import SearchSettings
from gst2.domain.models import CausalityStatus, JointCandidate
from gst2.optimize.grids import adaptive_rr_grid, legal_ladders
from gst2.optimize.joint import _expand_settings, search_offset
from gst2.replay.five_order import ExecutionPolicy
from helpers import make_episode


def settings():
    return SearchSettings(
        sl_min=0.35, sl_max=0.40, sl_coarse_step=0.05, sl_refine_step=0.05,
        rr_min=0.4, rr_max=1.4, rr_coarse_step=0.2, rr_refine_step=0.1,
        rr_min_separation=0.2, max_coarse_ladders_per_sl=100, refinement_seed_count=4,
        refinement_passes=1, min_episodes=1,
    )


def test_ordered_five_ladders_only():
    g,_=adaptive_rr_grid(0.4,1.4,0.2,max_ladders=100)
    ladders=legal_ladders(g,0.2)
    assert ladders
    assert all(len(x)==5 and all(a<b for a,b in zip(x,x[1:])) for x in ladders)


def test_joint_search_returns_complete_tuple():
    episodes=[]
    for i in range(8):
        episodes.append(make_episode([0.0, 0.7, 0.05], signal_id=f"S{i}"))
    r=search_offset(episodes,settings(),ExecutionPolicy())
    assert r.best_production is not None
    assert len(r.best_production.rr_ladder)==5
    assert r.best_production.sl_pct in {0.35,0.4}


def test_negative_diagnostic_not_production_selected():
    episodes=[make_episode([0,0.7,0.05],offset=-1,signal_id=f"N{i}",status=CausalityStatus.NON_CAUSAL_DIAGNOSTIC,eligible=False) for i in range(5)]
    r=search_offset(episodes,settings(),ExecutionPolicy())
    assert r.best_research is not None
    assert r.best_production is None


def test_boundary_expansion_changes_only_hit_dimensions():
    s = settings()
    expanded, applied = _expand_settings(
        s, ["SL_MAX", "RR_MAX"],
        {"expansion_factor": 1.5, "sl_floor_pct": 0.05, "sl_ceiling_pct": 5.0,
         "rr_floor_R": 0.05, "rr_ceiling_R": 3.0, "expand_rr": True},
    )
    assert applied == ["SL_MAX", "RR_MAX"]
    assert expanded.sl_min == s.sl_min
    assert expanded.sl_max == 0.6
    assert expanded.rr_min == s.rr_min
    assert expanded.rr_max == 2.1


def test_boundary_expansion_respects_hard_ceiling():
    s = settings()
    expanded, applied = _expand_settings(
        s, ["SL_MAX"],
        {"expansion_factor": 2.0, "sl_floor_pct": 0.05, "sl_ceiling_pct": 0.45,
         "rr_floor_R": 0.05, "rr_ceiling_R": 3.0, "expand_rr": True},
    )
    assert expanded.sl_max == 0.45
    assert applied == ["SL_MAX"]


def test_search_offset_auto_expands_when_best_hits_boundary():
    episodes=[make_episode([0.0,0.7,0.05],signal_id=f"B{i}") for i in range(8)]
    r=search_offset(
        episodes, settings(), ExecutionPolicy(),
        boundary_cfg={
            "enabled": True, "max_rounds": 1, "expansion_factor": 1.5,
            "sl_floor_pct": 0.10, "sl_ceiling_pct": 1.0,
            "rr_floor_R": 0.10, "rr_ceiling_R": 3.0, "expand_rr": True,
        },
    )
    assert r.boundary_expansion_rounds == 1
    assert len(r.boundary_history) == 2
    assert r.boundary_history[0]["boundary_hits"]
    assert r.search_bounds["sl_min"] < settings().sl_min or r.search_bounds["rr_max"] > settings().rr_max

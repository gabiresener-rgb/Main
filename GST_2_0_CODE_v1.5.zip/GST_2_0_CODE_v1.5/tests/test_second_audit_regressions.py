from __future__ import annotations

import copy
import hashlib
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest
import yaml

from gst2.config import DEFAULT_CONFIG, load_config
from gst2.domain.models import (
    CausalityStatus,
    Direction,
    InstrumentSpec,
    JointCandidate,
    MarketPoint,
    OffsetScenario,
    RawEpisode,
    SignalSeed,
)
from gst2.metrics.core import mark_to_market_drawdown, summarize_replayed
from gst2.metrics.equivalence import ci_within_practical_equivalence
from gst2.replay.five_order import ExecutionModelError, ExecutionPolicy, replay_episode
from gst2.service import _execution_ledger_rows
from gst2.validate.evidence import load_execution_reconciliation
from gst2.validate.splits import expanding_walk_forward
from helpers import make_episode


def _seed(i: int, hour: int) -> SignalSeed:
    t = datetime(2026, 1, 1, hour, tzinfo=timezone.utc)
    return SignalSeed(
        signal_id=f"S{i:02d}", slot_id="1", asset_group="FOREX", symbol="EURUSD",
        timeframe="H1", direction=Direction.BUY, signal_time=t,
        provider_hash="PH", source_channel="BUY_BUFFER",
    )


def _flat_spreadless_episode(direction: Direction, signal_id: str) -> RawEpisode:
    t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
    seed = SignalSeed(
        signal_id, "1", "FOREX", "EURUSD", "H1", direction, t0,
        provider_hash="PH", source_channel="BUY_BUFFER" if direction is Direction.BUY else "SELL_BUFFER",
    )
    scenario = OffsetScenario(
        signal_id, 0, t0, t0, t0, 100.0, t0,
        CausalityStatus.STANDARD_CAUSAL, True,
    )
    pts = tuple(
        MarketPoint(t0 + timedelta(minutes=i), px, px)
        for i, px in enumerate((100.0, 100.5, 100.0))
    )
    return RawEpisode(f"{signal_id}|0", seed, scenario, pts[-1].ts, pts)


def test_execution_evidence_claimed_pass_cannot_override_computed_failure(tmp_path: Path):
    artifact = tmp_path / "reconciliation.csv"
    artifact.write_text("trade_id,ok\n", encoding="utf-8")
    bad_hash = "0" * 64
    evidence = {
        "evidence_id": "E1",
        "evidence_hash": bad_hash,
        "evidence_path": artifact.name,
        "pass": True,
        "matched_trade_count": 0,
        "max_price_error_ticks": 0,
        "max_time_error_seconds": 0,
        "max_account_pnl_error": 0,
        "data_fingerprint": "a" * 64,
        "execution_model_fingerprint": "b" * 64,
    }
    p = tmp_path / "execution.json"
    p.write_text(json.dumps(evidence), encoding="utf-8")
    result, _ = load_execution_reconciliation(
        str(p),
        expected_data_fingerprint="a" * 64,
        expected_execution_model_fingerprint="b" * 64,
        min_matched_trade_count=1,
        allowed_max_price_error_ticks=0,
        allowed_max_time_error_seconds=0,
        allowed_max_account_pnl_error=0,
    )
    assert result["claimed_pass"] is True
    assert result["artifact_hash_verified"] is False
    assert result["matched_trade_count_verified"] is False
    assert result["pass"] is False


def test_last_walk_forward_fold_is_capped_by_final_holdout_boundary():
    seeds = [_seed(i, i) for i in range(16)]
    final_holdout_boundary = datetime(2026, 1, 1, 16, tzinfo=timezone.utc)
    folds = expanding_walk_forward(seeds, folds=4, min_train_fraction=0.40, outer_end_exclusive=final_holdout_boundary)
    assert folds
    assert folds[-1].test_end_exclusive == final_holdout_boundary
    assert all(f.test_end_exclusive <= final_holdout_boundary for f in folds)


def test_unresolved_open_loss_remains_in_financial_expectancy():
    candidate = JointCandidate(0, 0.35, (0.4, 0.7, 1.2, 2.0, 3.0))
    policy = ExecutionPolicy(default_tick_size=0.00001)
    winner = replay_episode(make_episode([0.0, 1.2], signal_id="WIN"), candidate, policy)
    loser = replay_episode(make_episode([0.0, -0.20], signal_id="OPEN_LOSS"), candidate, policy)
    assert winner.valid_for_distribution
    assert loser.valid_for_economics and not loser.valid_for_distribution
    assert loser.pool_R < 0 and loser.pool_unrealized_R < 0

    metrics = summarize_replayed(
        candidate, [winner, loser], episodes=[], source_signal_count=2, built_episode_count=2
    )
    assert metrics.episode_count == 1  # six-class quality denominator only
    assert metrics.financial_episode_count == 2
    assert metrics.unresolved_timeout_count == 1
    assert metrics.pool_net_R == pytest.approx(winner.pool_R + loser.pool_R)
    assert metrics.unrealized_pool_R == pytest.approx(loser.pool_unrealized_R)


def test_mtm_drawdown_updates_all_positions_atomically_at_same_timestamp():
    candidate = JointCandidate(0, 1.0, (2.0, 3.0, 4.0, 5.0, 6.0))
    policy = ExecutionPolicy(default_tick_size=0.01)
    buy = replay_episode(_flat_spreadless_episode(Direction.BUY, "BUY"), candidate, policy)
    sell = replay_episode(_flat_spreadless_episode(Direction.SELL, "SELL"), candidate, policy)
    assert buy.valid_for_economics and sell.valid_for_economics
    # Every synchronized quote produces equal/opposite pool-R, so portfolio equity is identically zero.
    for bp, sp in zip(buy.equity_path, sell.equity_path):
        assert bp.ts == sp.ts
        assert bp.pool_R + sp.pool_R == pytest.approx(0.0, abs=1e-12)
    assert mark_to_market_drawdown([], [buy, sell]) == pytest.approx(0.0, abs=1e-12)


def test_initial_buy_stop_distance_is_measured_from_bid_not_entry_ask():
    t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
    seed = SignalSeed("S", "1", "FOREX", "EURUSD", "H1", Direction.BUY, t0, provider_hash="PH", source_channel="BUY_BUFFER")
    scenario = OffsetScenario("S", 0, t0, t0, t0, 100.0, t0, CausalityStatus.STANDARD_CAUSAL, True)
    # Entry Ask=100; current Bid=99.8. Nominal SL 0.30% -> executable SL 99.7.
    # Entry-to-SL distance=.3, but broker-side Bid-to-SL distance=.1 < stops_level=.2.
    episode = RawEpisode("S|0", seed, scenario, t0, (MarketPoint(t0, 99.8, 100.0),))
    candidate = JointCandidate(0, 0.30, (1.0, 1.5, 2.0, 2.5, 3.0))
    spec = InstrumentSpec("EURUSD", tick_size=0.1, stops_level_price=0.2, spec_id="TEST")
    with pytest.raises(ExecutionModelError, match="current Bid/Ask side"):
        replay_episode(episode, candidate, ExecutionPolicy(instrument_specs={"EURUSD": spec}, require_instrument_specs=True))


def test_production_config_cannot_disable_mandatory_validation_gate(tmp_path: Path):
    cfg = copy.deepcopy(DEFAULT_CONFIG)
    cfg["run_mode"] = "PRODUCTION"
    cfg["execution_policy"]["require_instrument_specs"] = True
    cfg["execution_policy"]["require_account_economics"] = True
    cfg["execution_policy"]["instrument_specs_csv"] = "instrument_specs.csv"
    cfg["execution_policy"]["observation_horizon_bars"] = {tf: 48 for tf in ("M15", "M30", "H1", "H4", "D1", "W1")}
    cfg["input_validation"]["slot_registry_csv"] = "slot_registry.csv"
    ext = cfg["validation"]["external_evidence"]
    ext["provider_equivalence_csv"] = "provider.csv"
    ext["execution_reconciliation_json"] = "exec.json"
    ext["max_account_pnl_error"] = 0.01
    cfg["validation"]["production_gates"]["require_holdout"] = False
    p = tmp_path / "prod.yaml"
    p.write_text(yaml.safe_dump(cfg, sort_keys=False), encoding="utf-8")
    with pytest.raises(ValueError, match="cannot disable mandatory gate"):
        load_config(str(p))


def test_execution_ledger_separates_nominal_and_effective_targets():
    episode = make_episode([0.0, 1.5], signal_id="ROUND")
    candidate = JointCandidate(0, 0.37, (0.4, 0.8, 1.2, 2.0, 3.0))
    spec = InstrumentSpec("EURUSD", tick_size=0.1, spec_id="ROUNDING")
    result = replay_episode(
        episode, candidate,
        ExecutionPolicy(instrument_specs={"EURUSD": spec}, require_instrument_specs=True),
    )
    rows = _execution_ledger_rows([result], "TEST")
    assert rows
    first = rows[0]
    assert first["nominal_target_R"] == pytest.approx(0.4)
    assert first["effective_target_R"] != pytest.approx(first["nominal_target_R"])
    assert first["nominal_target_pct"] != pytest.approx(first["effective_target_pct"])
    assert first["nominal_sl_pct"] != pytest.approx(first["effective_sl_pct"])
    assert first["instrument_tick_size"] == pytest.approx(0.1)
    assert first["instrument_spec_fingerprint"]


def test_reconciliation_denominator_tracks_source_builder_and_replay_losses():
    candidate = JointCandidate(0, 0.35, (0.4, 0.7, 1.2, 2.0, 3.0))
    result = replay_episode(make_episode([0.0, 1.2], signal_id="ONE"), candidate, ExecutionPolicy())
    metrics = summarize_replayed(
        candidate, [result], source_signal_count=4, built_episode_count=2, replay_error_count=1,
        builder_incomplete_data_count=2,
    )
    assert metrics.source_signal_count == 4
    assert metrics.built_episode_count == 2
    assert metrics.replay_result_count == 1
    assert metrics.replay_error_count == 1
    assert metrics.builder_excluded_count == 2
    assert metrics.excluded_episode_count == 3
    assert metrics.total_episode_count == 4
    assert metrics.incomplete_data_count >= 2
    assert not metrics.production_eligible


def test_practical_equivalence_requires_entire_ci_inside_predeclared_margin():
    assert ci_within_practical_equivalence((-0.01, 0.01), 0.02)
    assert not ci_within_practical_equivalence((-0.03, 0.01), 0.02)
    assert not ci_within_practical_equivalence((-0.01, 0.03), 0.02)
    assert not ci_within_practical_equivalence((-0.01, 0.01), 0.0)

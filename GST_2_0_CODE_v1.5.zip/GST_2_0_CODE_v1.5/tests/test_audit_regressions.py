from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd
import pytest

from gst2.audit.pre_gst import run_pre_gst_audit
from gst2.config import DEFAULT_CONFIG, deep_merge, load_config
from gst2.domain.models import CausalityStatus, Direction, EpisodeStatus, JointCandidate, MarketPoint, OffsetScenario, RawEpisode, SignalSeed, InstrumentSpec
from gst2.optimize.grids import float_grid
from gst2.providers.offset_provider import build_offset_episodes
from gst2.causality.validator import NegativeOffsetCausalityValidator
from gst2.replay.five_order import ExecutionPolicy, replay_episode
from helpers import make_episode


def test_float_grid_always_includes_configured_endpoint():
    assert float_grid(0.10, 1.25, 0.20)[-1] == 1.25


def test_gap_stop_uses_first_executable_quote_not_stop_level():
    e=make_episode([0.0,-1.0])
    c=JointCandidate(0,0.35,(0.4,0.7,1.2,2.0,3.0))
    r=replay_episode(e,c,ExecutionPolicy(default_tick_size=0.01,fill_model="FIRST_EXECUTABLE_QUOTE"))
    assert r.outcome.value=="BAD"
    assert r.orders[0].close_price < r.initial_sl_price
    assert r.orders[0].gross_R < -1.0


def test_timeout_without_sl_or_tp_is_excluded_not_bad():
    e=make_episode([0.0,0.05])
    c=JointCandidate(0,0.35,(0.4,0.7,1.2,2.0,3.0))
    r=replay_episode(e,c,ExecutionPolicy(default_tick_size=0.01))
    assert r.completion_status is EpisodeStatus.UNRESOLVED_TIMEOUT
    assert r.outcome is None
    assert not r.valid_for_distribution


def test_tick_rounding_recomputes_effective_rr():
    e=make_episode([0,1.0])
    c=JointCandidate(0,0.37,(0.4,0.8,1.2,2.0,3.0))
    p=ExecutionPolicy(instrument_specs={"EURUSD":InstrumentSpec("EURUSD",tick_size=0.1)},require_instrument_specs=True)
    r=replay_episode(e,c,p)
    assert r.effective_sl_pct != c.sl_pct
    assert r.effective_rr_ladder != c.rr_ladder
    assert all(a<b for a,b in zip(r.effective_rr_ladder,r.effective_rr_ladder[1:]))


def test_split_window_rejects_episode_whose_horizon_crosses_boundary():
    t0=pd.Timestamp("2026-01-01T00:00:00Z")
    bars=pd.DataFrame({"symbol":"EURUSD","timeframe":"H1","open_time":pd.date_range(t0,periods=10,freq="h"),"open":1.0,"high":1.1,"low":0.9,"close":1.0})
    ticks=pd.DataFrame({"symbol":"EURUSD","timestamp":pd.date_range(t0,periods=11,freq="h"),"bid":1.0,"ask":1.0001})
    seed=SignalSeed("S","1","FOREX","EURUSD","H1",Direction.BUY,(t0+pd.Timedelta(hours=2)).to_pydatetime(),provider_hash="H",source_channel="BUY_BUFFER")
    b=build_offset_episodes([seed],bars,ticks,0,{"default":4},NegativeOffsetCausalityValidator(),window_end_exclusive=(t0+pd.Timedelta(hours=5)).to_pydatetime())
    assert not b.episodes
    assert any("crosses split boundary" in d.reason for d in b.diagnostics)


def test_pre_gst_rejects_source_direction_mismatch_in_production():
    t=datetime(2026,1,1,tzinfo=timezone.utc)
    seed=SignalSeed("S","1","FOREX","EURUSD","H1",Direction.SELL,t,provider_hash="H",source_channel="BUY_BUFFER")
    bars=pd.DataFrame([{"symbol":"EURUSD","timeframe":"H1","open_time":pd.Timestamp(t),"open":1,"high":1.1,"low":0.9,"close":1}])
    ticks=pd.DataFrame([{"symbol":"EURUSD","timestamp":pd.Timestamp(t),"bid":1,"ask":1.01}])
    a=run_pre_gst_audit([seed],bars,ticks,production_mode=True)
    assert not a.pass_gate
    assert any(i.code=="SOURCE_CHANNEL_DIRECTION_MISMATCH" for i in a.issues)


def test_empty_yaml_cannot_become_production_by_defaults(tmp_path):
    p=tmp_path/"c.yaml"; p.write_text("run_mode: PRODUCTION\n",encoding="utf-8")
    with pytest.raises(ValueError,match="explicitly set"):
        load_config(str(p))


def test_mt5_source_has_18_column_dedupe_and_tick_failure_marks_bootstrap_failed():
    root=Path(__file__).resolve().parents[1]
    text=(root/"mt5/Experts/SMD/GST/GST_MT5_Bridge.mq5").read_text(encoding="utf-8")
    assert "const int SIGNAL_COLUMNS=19;" in text
    assert "g_bootstrap_failed=true;" in text[text.find("CopyTicksRange failed"):text.find("CopyTicksRange failed")+500]


def test_statistical_equivalence_can_prefer_lower_sl():
    from gst2.metrics.equivalence import paired_equal_symbol_difference_ci
    episodes=[make_episode([0.0,1.5],signal_id=f"EQ{i:02d}") for i in range(20)]
    wide=JointCandidate(0,0.50,(0.4,0.8,1.2,1.6,2.0))
    narrow=JointCandidate(0,0.40,(0.4,0.8,1.2,1.6,2.0))
    p=ExecutionPolicy(default_tick_size=0.00001)
    wr=[replay_episode(e,wide,p) for e in episodes]
    nr=[replay_episode(e,narrow,p) for e in episodes]
    ci=paired_equal_symbol_difference_ci(wr,nr,samples=200,alpha=0.05)
    assert ci is not None
    # Both configurations realize the same five RR exits, so wider SL has no
    # statistically established R advantage and lower SL is eligible for preference.
    assert ci[0] <= 0 and ci[1] <= 1e-5


def test_production_refuses_reusing_consumed_holdout_directory(tmp_path):
    import copy, yaml
    from gst2.config import DEFAULT_CONFIG
    from gst2.service import run_from_files
    cfg=copy.deepcopy(DEFAULT_CONFIG)
    cfg['run_mode']='PRODUCTION'
    cfg['execution_policy']['require_instrument_specs']=True
    cfg['execution_policy']['require_account_economics']=True
    cfg['execution_policy']['instrument_specs_csv']='instrument_specs.csv'
    cfg['execution_policy']['observation_horizon_bars']={tf:48 for tf in ('M15','M30','H1','H4','D1','W1')}
    cfg['input_validation']['slot_registry_csv']='slot_registry.csv'
    cfg['input_validation']['allow_non_mt5_input']=False
    cfg['validation']['external_evidence']['provider_equivalence_csv']='provider_eq.csv'
    cfg['validation']['external_evidence']['execution_reconciliation_json']='exec_recon.json'
    cfg['validation']['external_evidence']['max_account_pnl_error']=0.01
    cp=tmp_path/'production.yaml'; cp.write_text(yaml.safe_dump(cfg,sort_keys=False),encoding='utf-8')
    out=tmp_path/'out'; out.mkdir(); (out/'HOLDOUT_CONSUMED.json').write_text('{}',encoding='utf-8')
    with pytest.raises(ValueError,match='already been consumed'):
        run_from_files(signals='missing.csv',bars='missing.csv',ticks='missing.csv',config=str(cp),out=str(out))


def test_research_run_can_never_be_labelled_production_validated():
    from gst2.service import _production_gate
    from gst2.domain.models import CandidateMetrics, CausalityStatus
    from gst2.optimize.joint import JointSearchResult
    cm=CandidateMetrics(joint_config_id='X',offset=0,sl_pct=0.4,rr_ladder=(0.4,0.7,1.2,2,3),production_eligible=True,causality_status=CausalityStatus.STANDARD_CAUSAL,episode_count=100,bad_pct=10,tp1_pct=10,tp2_pct=10,tp3_pct=20,tp4_pct=20,tp5_pct=30,pool_net_R=10,pool_expectancy_R_per_episode=0.1,profit_factor=2.0,pool_max_drawdown_R=0.2,max_losing_streak=0,modified_stop_close_count=0,modified_stop_net_R=0,equal_symbol_expectancy_R=0.1,positive_symbol_share=1.0,high_tp_share_pct=50,robust=True,pareto_efficient=True,total_episode_count=100)
    sr=JointSearchResult(0,0.1,[cm],cm,cm,boundary_status='SEARCH_BOUNDS_OK')
    cfg={'run_mode':'RESEARCH','joint_search':{'min_episodes':30},'validation':{'robustness':{'min_positive_symbol_share':0.6},'production_gates':{'require_walk_forward':True,'require_holdout':True,'require_robust':True,'require_cross_symbol':True,'require_boundary_resolved':True,'require_zero_execution_invalid':True,'max_excluded_episode_share':0.2}}}
    status,reasons=_production_gate(cm,sr,{'status':'PASS'},'PASS',cfg)
    assert status=='RESEARCH_ONLY' and 'RUN_MODE_NOT_PRODUCTION' in reasons


def test_causality_loader_requires_real_hashed_evidence_artifact(tmp_path):
    from gst2.causality.validator import load_causality_evidence
    artifact=tmp_path/'evidence.json'; artifact.write_text('{"ok":true}',encoding='utf-8')
    import hashlib, pandas as pd
    good=hashlib.sha256(artifact.read_bytes()).hexdigest()
    row=dict(slot_id='1',asset_group='FOREX',symbol='EURUSD',timeframe='H1',offset=-1,provider_hash='PH',evidence_id='E',evidence_hash=good,evidence_path='evidence.json',window_start='2025-01-01T00:00:00Z',window_end='2027-01-01T00:00:00Z',latest_data_time='2026-01-01T00:00:00Z',streaming_replay_pass=True,future_mutation_pass=True,mtf_cutoff_pass=True,provider_semantics_pass=True,entry_executability_pass=True,data_cutoff_lte_entry=True)
    csv=tmp_path/'causal.csv'; pd.DataFrame([row]).to_csv(csv,index=False)
    rows,_=load_causality_evidence(str(csv)); assert rows[0].artifact_hash_verified and rows[0].passed
    row['evidence_hash']='0'*64; pd.DataFrame([row]).to_csv(csv,index=False)
    rows,_=load_causality_evidence(str(csv)); assert not rows[0].artifact_hash_verified and not rows[0].passed


def test_production_requires_explicit_horizon_for_every_canonical_tf(tmp_path):
    import copy, yaml
    from gst2.config import DEFAULT_CONFIG, load_config
    cfg=copy.deepcopy(DEFAULT_CONFIG)
    cfg['run_mode']='PRODUCTION'
    cfg['execution_policy']['require_instrument_specs']=True
    cfg['execution_policy']['require_account_economics']=True
    cfg['execution_policy']['instrument_specs_csv']='instrument_specs.csv'
    cfg['input_validation']['slot_registry_csv']='slot_registry.csv'
    cfg['validation']['external_evidence']['provider_equivalence_csv']='provider.csv'
    cfg['validation']['external_evidence']['execution_reconciliation_json']='exec.json'
    # Explicitly preserve mandatory blocks in raw config, but omit TF-specific horizons.
    cfg['execution_policy']['observation_horizon_bars']={'default':48}
    p=tmp_path/'prod.yaml'; p.write_text(yaml.safe_dump(cfg,sort_keys=False),encoding='utf-8')
    with pytest.raises(ValueError, match='explicit observation_horizon_bars|must not use observation_horizon_bars.default'):
        load_config(str(p))


def test_trade_event_ledger_persists_full_event_sequence():
    from gst2.service import _trade_event_ledger_rows
    e=make_episode([0.0,0.2,0.05])
    c=JointCandidate(0,0.35,(0.4,0.7,1.2,2.0,3.0))
    r=replay_episode(e,c,ExecutionPolicy(default_tick_size=0.00001))
    rows=_trade_event_ledger_rows([r],'TEST')
    assert rows
    assert rows[0]['event_type']=='ENTRY'
    assert any(x['event_type']=='TP_HIT' for x in rows)
    assert any(x['event_type']=='ORDER_CLOSE' for x in rows)
    assert all('event_time' in x and 'event_price' in x for x in rows)

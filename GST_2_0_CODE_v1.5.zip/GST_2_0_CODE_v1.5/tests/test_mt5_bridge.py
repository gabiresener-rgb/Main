from pathlib import Path
import pandas as pd

from gst2.providers.mt5_bridge import (
    generate_matched_control_signals,
    load_slot_registry,
    validate_mt5_export,
)


def _registry_rows(n: int):
    rows=[]
    for i in range(n):
        rows.append({
            "enabled": 1,
            "slot_id": f"SLOT_{i+1}",
            "slot_name": f"Slot {i+1}",
            "provider_type": "DUAL_BUFFER",
            "indicator_path": "SMD\\Dummy",
            "handle_timeframe": "H1",
            "signal_timeframe": "H1",
            "buy_buffer": 0,
            "sell_buffer": 1,
            "direction_buffer": -1,
            "buy_value": 1,
            "sell_value": -1,
            "emit_on_change": 0,
            "symbols": "*",
            "live_buffer_shift": 1,
            "provider_version": "1.0",
            "provider_hash": f"HASH_{i+1}",
            "horizon_bars": 48,
        })
    return rows


def test_slot_registry_has_no_23_slot_ceiling(tmp_path):
    path=tmp_path/"slot_registry.csv"
    pd.DataFrame(_registry_rows(57)).to_csv(path,index=False)
    reg=load_slot_registry(path)
    assert len(reg)==57
    assert reg["slot_id"].nunique()==57


def test_validate_mt5_export_contract(tmp_path):
    pd.DataFrame([{
        "signal_id":"S1","slot_id":"SLOT_ALPHA","asset_group":"FOREX","symbol":"EURUSD",
        "timeframe":"H1","direction":"BUY","signal_time":"2026-01-01T01:00:00Z",
    }]).to_csv(tmp_path/"signals.csv",index=False)
    pd.DataFrame([
        {"open_time":"2026-01-01T00:00:00Z","symbol":"EURUSD","timeframe":"H1","open":1.1,"high":1.11,"low":1.09,"close":1.105},
        {"open_time":"2026-01-01T01:00:00Z","symbol":"EURUSD","timeframe":"H1","open":1.105,"high":1.12,"low":1.10,"close":1.115},
    ]).to_csv(tmp_path/"bars.csv",index=False)
    pd.DataFrame([
        {"timestamp":"2026-01-01T01:00:00.000Z","symbol":"EURUSD","bid":1.1049,"ask":1.1051},
        {"timestamp":"2026-01-01T01:01:00.000Z","symbol":"EURUSD","bid":1.1055,"ask":1.1057},
    ]).to_csv(tmp_path/"ticks.csv",index=False)
    reg=tmp_path/"slot_registry.csv"
    rows=_registry_rows(31)
    rows[0]["slot_id"]="SLOT_ALPHA"
    pd.DataFrame(rows).to_csv(reg,index=False)
    v=validate_mt5_export(tmp_path,reg)
    assert v.signal_rows==1
    assert v.distinct_slots==1
    assert v.registry_distinct_slots==31
    assert v.slot_count_limit=="NONE"


def test_generate_matched_controls_preserves_scope(tmp_path):
    sig=tmp_path/"signals.csv"
    bars=tmp_path/"bars.csv"
    out=tmp_path/"controls.csv"
    pd.DataFrame([
        {"signal_id":"S1","slot_id":"SLOT_A","asset_group":"FOREX","symbol":"EURUSD","timeframe":"H1","direction":"BUY","signal_time":"2026-01-01T10:00:00Z"},
        {"signal_id":"S2","slot_id":"SLOT_B","asset_group":"FOREX","symbol":"EURUSD","timeframe":"H1","direction":"SELL","signal_time":"2026-01-02T10:00:00Z"},
    ]).to_csv(sig,index=False)
    times=pd.date_range("2026-01-01",periods=100,freq="h",tz="UTC")
    pd.DataFrame({
        "open_time":times,"symbol":"EURUSD","timeframe":"H1",
        "open":1.1,"high":1.11,"low":1.09,"close":1.105,
    }).to_csv(bars,index=False)
    generate_matched_control_signals(
        signals_csv=sig,bars_csv=bars,output_csv=out,
        random_seed=7,controls_per_signal=2,min_separation_bars=3,
    )
    c=pd.read_csv(out)
    assert len(c)==4
    assert set(c["slot_id"])=={"SLOT_A","SLOT_B"}
    assert set(c["direction"])=={"BUY","SELL"}
    assert set(c["asset_group"])=={"FOREX"}
    assert c["signal_id"].str.startswith("CTRL|").all()


def test_mt5_bridge_source_has_no_fixed_slot_constant():
    root=Path(__file__).resolve().parents[1]
    text=(root/"mt5/Experts/SMD/GST/GST_MT5_Bridge.mq5").read_text(encoding="utf-8")
    assert "#define MAX_SLOTS" not in text
    assert "slot<=23" not in text.replace(" ","")
    assert "slot<23" not in text.replace(" ","")


def test_slot_registry_rejects_ambiguous_shared_tf_mapping(tmp_path):
    path=tmp_path/"slot_registry.csv"
    rows=_registry_rows(1)
    rows[0]["handle_timeframe"]="H1"
    rows[0]["signal_timeframe"]="H4"
    pd.DataFrame(rows).to_csv(path,index=False)
    import pytest
    with pytest.raises(ValueError,match="handle_timeframe == signal_timeframe"):
        load_slot_registry(path)


def test_validate_mt5_export_rejects_failed_bridge_manifest(tmp_path):
    # Manifest failure is a release/evidence blocker even if CSV remnants exist.
    pd.DataFrame([
        {"key":"bootstrap_status","value":"FAILED"},
        {"key":"slot_count_limit","value":"NONE"},
        {"key":"provider_construction_failures","value":"0"},
        {"key":"bootstrap_failed_provider_count","value":"1"},
    ]).to_csv(tmp_path/"bridge_manifest.csv",index=False)
    import pytest
    with pytest.raises(ValueError,match="bootstrap failed"):
        validate_mt5_export(tmp_path)


def test_validate_mt5_export_rejects_source_channel_direction_mismatch(tmp_path):
    pd.DataFrame([{
        "signal_id":"S1","slot_id":"SLOT_ALPHA","asset_group":"FOREX","symbol":"EURUSD",
        "timeframe":"H1","direction":"SELL","signal_time":"2026-01-01T01:00:00Z",
        "source_channel":"BUY_BUFFER",
    }]).to_csv(tmp_path/"signals.csv",index=False)
    pd.DataFrame([{
        "open_time":"2026-01-01T01:00:00Z","symbol":"EURUSD","timeframe":"H1",
        "open":1.1,"high":1.11,"low":1.09,"close":1.105,
    }]).to_csv(tmp_path/"bars.csv",index=False)
    pd.DataFrame([{
        "timestamp":"2026-01-01T01:00:01Z","symbol":"EURUSD","bid":1.1,"ask":1.1001,
    }]).to_csv(tmp_path/"ticks.csv",index=False)
    import pytest
    with pytest.raises(ValueError,match="source_channel/direction mapping mismatch"):
        validate_mt5_export(tmp_path)

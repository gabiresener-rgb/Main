from datetime import datetime, timedelta, timezone
from gst2.causality.validator import NegativeOffsetCausalityValidator
from gst2.domain.models import CausalityEvidence, CausalityStatus, Direction, SignalSeed

T=datetime(2026,1,2,tzinfo=timezone.utc)
SEED=SignalSeed("S","1","FOREX","EURUSD","H1",Direction.BUY,T,provider_hash="PH",source_channel="BUY_BUFFER")

def ev(**kw):
    d=dict(slot_id="1",asset_group="FOREX",symbol="EURUSD",timeframe="H1",offset=-1,provider_hash="PH",evidence_id="E",evidence_hash="EH",window_start=T-timedelta(days=10),window_end=T+timedelta(days=1),latest_data_time=T-timedelta(hours=1),streaming_replay_pass=True,future_mutation_pass=True,mtf_cutoff_pass=True,provider_semantics_pass=True,entry_executability_pass=True,data_cutoff_lte_entry=True,evidence_path="x",artifact_hash_verified=True)
    d.update(kw); return CausalityEvidence(**d)

def test_negative_without_evidence_is_diagnostic_only():
    d=NegativeOffsetCausalityValidator().classify(SEED,-1,T-timedelta(hours=1))
    assert d.status is CausalityStatus.NON_CAUSAL_DIAGNOSTIC and not d.production_eligible

def test_negative_all_evidence_passes():
    d=NegativeOffsetCausalityValidator([ev()]).classify(SEED,-1,T-timedelta(hours=1))
    assert d.status is CausalityStatus.CAUSAL_PASS and d.production_eligible

def test_negative_failed_evidence_blocks_production():
    d=NegativeOffsetCausalityValidator([ev(future_mutation_pass=False)]).classify(SEED,-1,T-timedelta(hours=1))
    assert d.status is CausalityStatus.CAUSAL_FAIL and not d.production_eligible

def test_nonnegative_offsets_require_physical_later_semantics():
    v=NegativeOffsetCausalityValidator()
    assert v.classify(SEED,0,T).production_eligible
    assert v.classify(SEED,1,T+timedelta(hours=1)).production_eligible
    assert not v.classify(SEED,1,T-timedelta(hours=1)).production_eligible

def test_evidence_wrong_symbol_or_provider_is_rejected():
    e=ev(symbol="GBPUSD")
    assert not NegativeOffsetCausalityValidator([e]).classify(SEED,-1,T-timedelta(hours=1)).production_eligible

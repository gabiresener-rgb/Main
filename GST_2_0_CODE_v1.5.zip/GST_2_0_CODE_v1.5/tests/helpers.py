from __future__ import annotations

from datetime import datetime, timedelta, timezone

from gst2.domain.models import (
    CausalityStatus, Direction, MarketPoint, OffsetScenario, RawEpisode, SignalSeed,
)


def make_episode(
    moves_pct,
    *,
    direction=Direction.BUY,
    offset=0,
    symbol="EURUSD",
    signal_id="S1",
    status=CausalityStatus.STANDARD_CAUSAL,
    eligible=True,
):
    t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
    entry = 100.0
    seed = SignalSeed(signal_id, "1", "FOREX", symbol, "H1", direction, t0, provider_hash="PROVHASH", source_channel="BUY_BUFFER" if direction is Direction.BUY else "SELL_BUFFER")
    scenario = OffsetScenario(
        signal_id, offset, t0, t0, t0, entry, t0, status, eligible, "E1" if offset < 0 else ""
    )
    pts = []
    for i, move in enumerate(moves_pct):
        if direction is Direction.BUY:
            bid = entry * (1 + move / 100)
            ask = bid + 0.01
        else:
            ask = entry * (1 - move / 100)
            bid = ask - 0.01
        pts.append(MarketPoint(t0 + timedelta(minutes=i), bid, ask))
    return RawEpisode(f"{signal_id}|{offset}", seed, scenario, pts[-1].ts, tuple(pts))

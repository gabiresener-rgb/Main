import pytest
from gst2.config import CANONICAL_ASSET_GROUPS, CANONICAL_TIMEFRAMES, DEFAULT_CONFIG, validate_config, deep_merge, scope_search_settings


def test_full_offset_range_required():
    validate_config(DEFAULT_CONFIG)
    bad=deep_merge(DEFAULT_CONFIG,{"offset_search":{"full_sweep_min":-3}})
    with pytest.raises(ValueError):
        validate_config(bad)


def test_canonical_timeframes_are_fixed():
    assert tuple(DEFAULT_CONFIG["scope"]["timeframes"]) == CANONICAL_TIMEFRAMES
    assert CANONICAL_TIMEFRAMES == ("M15", "M30", "H1", "H4", "D1", "W1")


def test_unsupported_timeframe_rejected():
    bad = deep_merge(DEFAULT_CONFIG, {"scope": {"timeframes": ["M15", "MN1"]}})
    with pytest.raises(ValueError):
        validate_config(bad)


def test_all_30_asset_group_timeframe_sl_bounds_present():
    overrides = DEFAULT_CONFIG["joint_search"]["scope_overrides"]
    expected = {f"{g}:{tf}" for g in CANONICAL_ASSET_GROUPS for tf in CANONICAL_TIMEFRAMES}
    assert set(overrides) == expected
    assert len(overrides) == 30


def test_scope_specific_sl_bounds_are_used():
    fx = scope_search_settings(DEFAULT_CONFIG, "FOREX", "H1")
    crypto = scope_search_settings(DEFAULT_CONFIG, "CRYPTO", "W1")
    stocks = scope_search_settings(DEFAULT_CONFIG, "STOCKS", "D1")
    assert (fx.sl_min, fx.sl_max, fx.sl_coarse_step, fx.sl_refine_step) == (0.15, 1.25, 0.05, 0.01)
    assert (crypto.sl_min, crypto.sl_max, crypto.sl_coarse_step, crypto.sl_refine_step) == (1.0, 12.0, 0.5, 0.1)
    assert (stocks.sl_min, stocks.sl_max) == (0.75, 6.0)


def test_missing_scope_override_rejected_after_merge_shape():
    bad = deep_merge(DEFAULT_CONFIG, {})
    bad["joint_search"]["scope_overrides"].pop("FOREX:H1")
    with pytest.raises(ValueError):
        validate_config(bad)

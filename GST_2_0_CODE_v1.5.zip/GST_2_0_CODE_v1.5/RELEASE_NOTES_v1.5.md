# GST 2.0 Code v1.5 release notes

Second independent-audit remediation release.

Major changes: fail-closed execution evidence; final-holdout barrier in all WF folds; unresolved open-position MTM economics; atomic same-timestamp portfolio DD; broker-side stop-placement checks; immutable production gates; nominal/effective output contract; complete source/build/replay denominators; practical-equivalence CI; time-cluster bootstrap; expanded lineage fingerprints; strict production spec loading; fail-closed MT5 bootstrap exports; frozen production MT5 export rule; permanent second-audit and property regressions.

No claim is made that the MQL5 bridge was compiled or broker-runtime validated in this environment.

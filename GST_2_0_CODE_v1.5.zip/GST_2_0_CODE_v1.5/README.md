# GST 2.0 Code v1.5 — audited engine

GST 2.0 v1.5 is the second-audit remediation build of the canonical five-order tester. It is independent of scanners/models: GST consumes registered final signal streams through the canonical signal interface. The current project can have 23 active slots, but GST has **no hardcoded slot/source ceiling**.

## Canonical unit and search

For every `Slot/Source × AssetGroup × Timeframe`, GST evaluates integer Offset `-5..+5` and jointly searches:

`Offset × SL × RR1 × RR2 × RR3 × RR4 × RR5`, with `0 < RR1 < ... < RR5`.

Canonical TFs: `M15, M30, H1, H4, D1, W1`. Asset groups: `FOREX, COMMODITIES, CRYPTO, INDICES, STOCKS`.

One source signal = one `SignalEpisode` with five child orders and a common initial SL. TP1 closes order 1 and attempts to move orders 2–5 to the configured profitable stop (default Entry ±0.10%).

## Outcomes vs economics

The public quality distribution is only:

`BAD / TP1 / TP2 / TP3 / TP4 / TP5 = 100%` among **completed valid episodes**.

`BAD` means the initial SL actually executed before TP1. `UNRESOLVED_TIMEOUT`, `INCOMPLETE_DATA`, and `EXECUTION_INVALID` are not forced into BAD.

Financial metrics are different: `COMPLETE` and `UNRESOLVED_TIMEOUT` episodes are both economically accounted. Open orders are marked to the last in-window executable Bid/Ask quote, so an open loss cannot disappear merely because the observation horizon ended.

## Execution model

Production uses `FIRST_EXECUTABLE_QUOTE`:

- BUY entry = Ask; BUY exits/stop placement are evaluated on Bid.
- SELL entry = Bid; SELL exits/stop placement are evaluated on Ask.
- stop trigger and stop fill are separate; gaps fill at the first available exit-side quote plus configured adverse slippage.
- SL/TP/modified stop are normalized to tick size; effective SL%, TP% and RR are recomputed after normalization.
- stop/freeze distances are checked from the current broker-relevant quote side, not from entry price.
- nominal and effective parameters are exported separately.

`pool_R` is normalized to total initial five-order pool risk. `pool_order_R_sum` is a different unit. Account-currency PnL is produced only when explicit instrument/account inputs exist; production additionally requires external execution reconciliation because generic linear money conversion is not a substitute for the target broker's own calculation.

## Validation isolation

The full episode lifetime must stay inside its sample. Crossing episodes are excluded rather than truncated. Pipeline order:

1. optimization development;
2. frozen robust/Pareto candidate set;
3. selection OOS;
4. walk-forward validation, with every fold capped by the external final-holdout boundary;
5. immutable selected-config lock/fingerprint;
6. one-use final holdout.

Selection OOS, every WF fold, and final holdout share the same fail-closed checks: minimum completed sample, execution/causality eligibility, positive equal-symbol expectancy, cross-symbol positive-share threshold, zero replay/execution-invalid errors, and exclusion/unresolved ceilings.

## Drawdown

`mark_to_market_drawdown_R` uses replay-generated episode equity paths. All updates with the same timestamp are applied atomically to the portfolio before peak/DD is measured; episode ordering cannot create a fictitious intermediate drawdown. `event_chronology_drawdown_R` is retained separately as realized-close diagnostic.

## Offset causality

Semantics are fixed and non-configurable:

- negative = earlier;
- zero = source-time;
- positive = later.

Any non-canonical `offset_semantics_id` is a Pre-GST blocker. Negative production offsets require provenance-bound causality evidence with verified artifact SHA-256.

## Production gates

In `PRODUCTION`, mandatory gates cannot be disabled by configuration. Missing/disabled validation is never treated as PASS. Production requires real provider registry/hash lineage, frozen data coverage, provider-equivalence evidence, execution-reconciliation evidence, account/instrument specs, robust/cross-symbol checks, WF, holdout and resolved search boundaries.

Execution reconciliation is fail-closed: raw JSON `pass:true` cannot overwrite GST's computed status. It verifies artifact hash, matched count, price/time/account-PnL error limits, data fingerprint and execution-model fingerprint.

## Output audit trail

Each selected scope persists separate DEVELOPMENT / SELECTION_OOS / HOLDOUT artifacts including:

- closed-order execution ledger;
- open-order mark ledger;
- full TradeEvent ledger;
- build diagnostics;
- replay errors;
- sample metrics and denominators;
- selected-config lock with config/input/code/spec/registry/evidence hashes.

Nominal and effective SL/TP/RR fields are never intentionally conflated.

## Search and statistics

The optimizer reports the **best validated configuration found in the evaluated/adaptively refined search domain**, not a proof of a global continuous optimum.

A smaller SL may replace the economically strongest candidate only when the complete paired bootstrap CI of `(best - alternative)` lies inside the predeclared practical-equivalence margin `±R`. Bootstrap resampling is by chronological timestamp groups so contemporaneous cross-symbol dependence is preserved.

## MT5 bridge

The registry-driven bridge has no slot-count ceiling. Bootstrap export is fail-closed: failure to write signals/bars/ticks or `CopyTicksRange` failure prevents `bootstrap_complete=true`.

For production analysis use a frozen `GST_BOOTSTRAP_ONLY` export. Live polling appends source signals but does not continuously refresh the historical bars/ticks archive, so live-mode exports are not accepted as production-frozen evidence.

## Verification status

Bundled checks include unit/regression/adversarial/property tests, independent counterexamples from both audits, and a synthetic end-to-end production pipeline run. See `TEST_REPORT.txt` and `SELF_AUDIT_RESULTS_v1.5.json`.

The MQL5 bridge cannot be claimed compiled or broker-runtime validated in this environment. Real provider mappings, MetaEditor compilation, streaming/repaint evidence, broker execution reconciliation, validated observation horizons, and a genuinely untouched forward period remain external acceptance requirements.

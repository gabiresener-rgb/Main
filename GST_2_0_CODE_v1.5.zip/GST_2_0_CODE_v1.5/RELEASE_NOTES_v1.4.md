# GST 2.0 Code v1.4 — final audit hardening follow-up

Changes after v1.3 audit remediation:

- PRODUCTION no longer accepts a silent/default 48-bar observation horizon. `M15/M30/H1/H4/D1/W1` must each be explicitly configured from the validated EA/analysis rule; the production template intentionally contains unresolved placeholders until the real rule is supplied.
- Added persisted full `TradeEvent` ledgers for development, selection OOS and final holdout, in addition to child-order execution ledgers.
- Added an immutable `execution_fingerprint` equal to the selected-config lock hash, binding the tuple to config, market-data inputs and external evidence hashes before holdout access.
- Spec/schema version bumped to 1.5.2; package code version bumped to 1.4.0.

No claim is made that real provider mappings, MT5 compilation, broker fills or forward validation are complete. Those remain mandatory external acceptance gates.

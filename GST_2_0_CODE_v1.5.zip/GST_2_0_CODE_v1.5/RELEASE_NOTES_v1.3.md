# GST 2.0 Code v1.3 — audit remediation release

This release remediates the independent review dated 2026-09-25. It supersedes v1.2 for all further testing.

Major changes: hard split isolation for full episode lifetime; strict production gates; executable gap-stop fills; tick/broker constraint normalization; stronger causality provenance; timeout/incomplete separation from BAD; pool-R/account-PnL clarification; mark-to-market DD; equal-symbol/robust/Pareto/OOS selection hardening; exact endpoint/boundary search; stronger Pre-GST checks; MT5 bridge field/retry/bootstrap fixes; immutable pre-holdout lock; one-use holdout; hashed external evidence artifacts; account-economics requirement; paired block-bootstrap lower-SL equivalence.

See `AUDIT_REMEDIATION.md` for item-by-item mapping.

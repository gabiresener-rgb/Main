# GST 2.0 v1.5 — explicit limitations

1. Joint search is adaptive/heuristic. Output means “best validated candidate found in the searched domain”, not mathematical proof of a global continuous optimum.
2. `pool_R` is an equal-risk normalized episode metric. Without an explicit portfolio sizing/capital policy, sums of pool-R are not account-return percentages.
3. Internal account-currency PnL uses the supplied instrument money model. Instruments whose account conversion/contract value varies dynamically require external broker reconciliation; production evidence is mandatory.
4. An unresolved position is valued at the last in-window executable quote. After its configured observation horizon GST does not invent future prices; aggregate MTM therefore carries that terminal mark when other overlapping episodes continue.
5. The MQL5 bridge has static checks here but no MetaEditor/target-terminal compilation proof in this environment.
6. Live bridge polling does not maintain a continuously refreshed bars/ticks archive. Production must use a fresh frozen `BOOTSTRAP_ONLY` export.
7. Production observation horizons are not guessed. They must be explicitly supplied from the validated real strategy/analysis rule for each canonical TF.
8. Real negative-offset causality cannot be proven from historical buffers alone; external streaming/future-mutation/MTF evidence remains mandatory.

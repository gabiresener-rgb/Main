# GST 2.0 v1.5 — remediation of independent audits

## Second audit (v1.4) remediation

| Finding | v1.5 remediation |
|---|---|
| Input JSON could overwrite computed execution-evidence PASS | Computed validation fields are written last; artifact hash, counts/errors and data/model fingerprints are fail-closed |
| Last WF fold could consume final holdout prices | `outer_end_exclusive` is mandatory for the last fold and propagated into episode construction |
| Open/unresolved losses disappeared from economics | unresolved orders are marked at last in-window executable quote and included in financial expectancy/equity |
| Same-timestamp MTM depended on episode ordering | all position updates for one timestamp are applied atomically before peak/DD calculation |
| Initial stop distance measured from entry | placement validity is checked from current exit-side Bid/Ask; economic R still uses Entry→SL |
| Production gates could be disabled | PRODUCTION config rejects disabling mandatory gates; runtime gate is hard fail-closed |
| Nominal/effective parameters mixed in outputs | ledgers export nominal/effective target R%, SL%, executable prices and spec fingerprint explicitly |
| Incomplete denominator/reasons | source/built/replay/financial/completed counts plus build/replay diagnostic ledgers are persisted |
| Simplified money model | daily directional swap support added; broker execution reconciliation remains mandatory and limitations are explicit |
| Fingerprint incomplete | lock includes config/input/code/instrument-spec/registry/causality/provider/execution-evidence hashes |
| “equivalence” not statistically justified | lower SL requires full paired bootstrap CI inside predefined ±R practical-equivalence margin |
| independent symbol bootstrap lost cross-symbol dependence | bootstrap resamples chronological timestamp groups, preserving contemporaneous cross-symbol observations |
| schemas stricter than loaders | production instrument-spec loader is strict; required production evidence fields are runtime-validated |
| MT5 bootstrap could complete after export failure | signals/bars/ticks export returns success/fail; failed tick/bar/signal export prevents bootstrap completion |
| live signal export could outgrow market-data archive | production accepts frozen `BOOTSTRAP_ONLY` input; live mode is explicitly non-production for frozen analysis |

Every reproduced audit defect is covered by permanent regression/adversarial tests or the independent self-audit script.

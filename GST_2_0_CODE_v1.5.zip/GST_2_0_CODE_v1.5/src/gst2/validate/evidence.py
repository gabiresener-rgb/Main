from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import pandas as pd

from gst2.domain.models import SignalSeed


def _utc(v):
    t = pd.Timestamp(v)
    if t.tzinfo is None:
        t = t.tz_localize("UTC")
    else:
        t = t.tz_convert("UTC")
    return t.to_pydatetime()


@dataclass(frozen=True, slots=True)
class ProviderEquivalenceEvidence:
    slot_id: str
    symbol: str
    timeframe: str
    provider_hash: str
    window_start: datetime
    window_end: datetime
    streaming_equivalence_pass: bool
    closed_bar_pass: bool
    repaint_test_pass: bool
    mtf_availability_pass: bool
    evidence_id: str
    evidence_hash: str
    evidence_path: str
    artifact_hash_verified: bool

    @property
    def passed(self):
        return bool(
            self.evidence_id
            and self.evidence_hash
            and self.provider_hash
            and self.artifact_hash_verified
            and self.streaming_equivalence_pass
            and self.closed_bar_pass
            and self.repaint_test_pass
            and self.mtf_availability_pass
        )


def _bool(v):
    return v if isinstance(v, bool) else str(v).strip().lower() in {"1", "true", "yes", "pass", "passed"}


def load_provider_equivalence(path: str | None):
    if not path:
        return [], ""
    p = Path(path)
    fh = hashlib.sha256(p.read_bytes()).hexdigest()
    df = pd.read_csv(p)
    req = {
        "slot_id", "symbol", "timeframe", "provider_hash", "window_start", "window_end",
        "streaming_equivalence_pass", "closed_bar_pass", "repaint_test_pass", "mtf_availability_pass",
        "evidence_id", "evidence_hash", "evidence_path",
    }
    miss = req - set(df.columns)
    if miss:
        raise ValueError(f"provider equivalence evidence missing columns: {sorted(miss)}")
    out = []
    for r in df.to_dict(orient="records"):
        ep = Path(str(r["evidence_path"]))
        ep = ep if ep.is_absolute() else (p.parent / ep).resolve()
        claimed_hash = str(r["evidence_hash"]).strip().lower()
        verified = (
            len(claimed_hash) == 64
            and ep.exists()
            and hashlib.sha256(ep.read_bytes()).hexdigest().lower() == claimed_hash
        )
        out.append(ProviderEquivalenceEvidence(
            str(r["slot_id"]), str(r["symbol"]), str(r["timeframe"]).upper(), str(r["provider_hash"]),
            _utc(r["window_start"]), _utc(r["window_end"]), _bool(r["streaming_equivalence_pass"]),
            _bool(r["closed_bar_pass"]), _bool(r["repaint_test_pass"]), _bool(r["mtf_availability_pass"]),
            str(r["evidence_id"]).strip(), claimed_hash, str(ep), verified,
        ))
    return out, fh


def validate_provider_equivalence(seeds: list[SignalSeed], evidence: list[ProviderEquivalenceEvidence]) -> list[str]:
    failures = []
    for s in seeds:
        rows = [
            e for e in evidence
            if e.slot_id == s.slot_id
            and e.symbol == s.symbol
            and e.timeframe == s.timeframe
            and e.provider_hash == s.provider_hash
            and e.window_start <= s.signal_time <= e.window_end
            and e.passed
        ]
        if not rows:
            failures.append(s.signal_id)
    return failures


def _finite_nonnegative(value, field: str) -> float:
    try:
        x = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"execution reconciliation {field} must be numeric") from exc
    if not math.isfinite(x) or x < 0:
        raise ValueError(f"execution reconciliation {field} must be finite and >= 0")
    return x


def load_execution_reconciliation(
    path: str | None,
    *,
    expected_data_fingerprint: str = "",
    expected_execution_model_fingerprint: str = "",
    min_matched_trade_count: int = 1,
    allowed_max_price_error_ticks: float = 0.0,
    allowed_max_time_error_seconds: float = 0.0,
    allowed_max_account_pnl_error: float | None = None,
):
    """Load fail-closed independent execution reconciliation evidence.

    The input's claimed ``pass`` can never overwrite the computed pass.  In
    PRODUCTION the caller binds the evidence to both the exact data fingerprint
    and exact execution-model fingerprint.
    """
    if not path:
        return None, ""
    p = Path(path)
    if not p.exists():
        raise ValueError(f"execution reconciliation JSON not found: {p}")
    raw = p.read_bytes()
    file_hash = hashlib.sha256(raw).hexdigest()
    data = json.loads(raw.decode("utf-8"))
    required = {
        "evidence_id", "evidence_hash", "evidence_path", "pass", "matched_trade_count",
        "max_price_error_ticks", "max_time_error_seconds", "data_fingerprint",
        "execution_model_fingerprint",
    }
    miss = required - set(data)
    if miss:
        raise ValueError(f"execution reconciliation evidence missing fields: {sorted(miss)}")
    if not isinstance(data["pass"], bool):
        raise ValueError("execution reconciliation pass must be a JSON boolean")

    evidence_id = str(data["evidence_id"]).strip()
    evidence_hash = str(data["evidence_hash"]).strip().lower()
    if len(evidence_hash) != 64 or any(c not in "0123456789abcdef" for c in evidence_hash):
        raise ValueError("execution reconciliation evidence_hash must be a 64-char SHA-256 hex string")
    ep = Path(str(data["evidence_path"]))
    ep = ep if ep.is_absolute() else (p.parent / ep).resolve()
    artifact_ok = ep.exists() and hashlib.sha256(ep.read_bytes()).hexdigest().lower() == evidence_hash

    try:
        matched = int(data["matched_trade_count"])
    except (TypeError, ValueError) as exc:
        raise ValueError("execution reconciliation matched_trade_count must be integer") from exc
    if matched < 0:
        raise ValueError("execution reconciliation matched_trade_count must be >= 0")
    price_err = _finite_nonnegative(data["max_price_error_ticks"], "max_price_error_ticks")
    time_err = _finite_nonnegative(data["max_time_error_seconds"], "max_time_error_seconds")
    pnl_err = None
    if "max_account_pnl_error" in data and data["max_account_pnl_error"] is not None:
        pnl_err = _finite_nonnegative(data["max_account_pnl_error"], "max_account_pnl_error")

    data_fp = str(data["data_fingerprint"]).strip().lower()
    model_fp = str(data["execution_model_fingerprint"]).strip().lower()
    data_fp_ok = bool(expected_data_fingerprint) and data_fp == expected_data_fingerprint.lower()
    model_fp_ok = bool(expected_execution_model_fingerprint) and model_fp == expected_execution_model_fingerprint.lower()
    count_ok = matched >= max(1, int(min_matched_trade_count))
    price_ok = price_err <= float(allowed_max_price_error_ticks) + 1e-12
    time_ok = time_err <= float(allowed_max_time_error_seconds) + 1e-12
    pnl_ok = True
    if allowed_max_account_pnl_error is not None:
        pnl_ok = pnl_err is not None and pnl_err <= float(allowed_max_account_pnl_error) + 1e-12

    claimed_pass = data["pass"]
    computed_pass = bool(
        claimed_pass and evidence_id and evidence_hash and artifact_ok and count_ok
        and price_ok and time_ok and pnl_ok and data_fp_ok and model_fp_ok
    )

    # Put computed values LAST so raw JSON can never overwrite validation state.
    result = dict(data)
    result.update({
        "claimed_pass": claimed_pass,
        "pass": computed_pass,
        "artifact_hash_verified": artifact_ok,
        "resolved_evidence_path": str(ep),
        "matched_trade_count_verified": count_ok,
        "price_error_verified": price_ok,
        "time_error_verified": time_ok,
        "account_pnl_error_verified": pnl_ok,
        "data_fingerprint_verified": data_fp_ok,
        "execution_model_fingerprint_verified": model_fp_ok,
        "policy_min_matched_trade_count": int(min_matched_trade_count),
        "policy_max_price_error_ticks": float(allowed_max_price_error_ticks),
        "policy_max_time_error_seconds": float(allowed_max_time_error_seconds),
        "policy_max_account_pnl_error": allowed_max_account_pnl_error,
    })
    return result, file_hash

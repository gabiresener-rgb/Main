from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from gst2.domain.models import SignalSeed


@dataclass(frozen=True, slots=True)
class HoldoutSplit:
    development: list[SignalSeed]
    holdout: list[SignalSeed]
    boundary_time: datetime | None


def chronological_holdout(seeds: list[SignalSeed], fraction: float) -> HoldoutSplit:
    if not 0 <= fraction < 1:
        raise ValueError("holdout fraction must be in [0,1)")
    ordered = sorted(seeds, key=lambda s: (s.signal_time, s.signal_id))
    if not ordered or fraction == 0:
        return HoldoutSplit(ordered, [], None)
    target_n = max(1, int(round(len(ordered) * fraction)))
    if target_n >= len(ordered):
        target_n = len(ordered) - 1
    tentative = len(ordered) - target_n
    boundary = ordered[tentative].signal_time
    # Never split signals sharing one timestamp across development and holdout.
    while tentative > 0 and ordered[tentative - 1].signal_time == boundary:
        tentative -= 1
    if tentative <= 0:
        raise ValueError("cannot create leakage-safe holdout without splitting identical timestamps")
    return HoldoutSplit(ordered[:tentative], ordered[tentative:], boundary)


@dataclass(frozen=True, slots=True)
class WalkForwardFold:
    fold: int
    train: list[SignalSeed]
    test: list[SignalSeed]
    train_end_exclusive: datetime
    test_start: datetime
    test_end_exclusive: datetime


def expanding_walk_forward(
    seeds: list[SignalSeed],
    folds: int,
    min_train_fraction: float = 0.40,
    *,
    outer_end_exclusive: datetime | None = None,
) -> list[WalkForwardFold]:
    """Expanding WF split on timestamp groups with a mandatory test end.

    ``outer_end_exclusive`` is the final-holdout boundary.  The last WF test
    fold is explicitly capped by it so its price trajectory can never consume
    the untouched final holdout.
    """
    ordered = sorted(seeds, key=lambda s: (s.signal_time, s.signal_id))
    n = len(ordered)
    if folds < 1 or n < 3:
        return []
    groups: list[list[SignalSeed]] = []
    for s in ordered:
        if not groups or groups[-1][0].signal_time != s.signal_time:
            groups.append([s])
        else:
            groups[-1].append(s)
    if len(groups) < 3:
        return []
    initial_groups = max(1, int(len(groups) * min_train_fraction))
    remaining = len(groups) - initial_groups
    folds = min(folds, remaining)
    if folds <= 0:
        return []
    base = remaining // folds
    extra = remaining % folds
    out: list[WalkForwardFold] = []
    cursor = initial_groups
    for i in range(folds):
        size = base + (1 if i < extra else 0)
        if size <= 0:
            continue
        end = cursor + size
        train_groups = groups[:cursor]
        test_groups = groups[cursor:end]
        train = [x for g in train_groups for x in g]
        test = [x for g in test_groups for x in g]
        test_start = test_groups[0][0].signal_time
        natural_test_end = groups[end][0].signal_time if end < len(groups) else outer_end_exclusive
        if natural_test_end is None:
            raise ValueError("walk-forward last fold requires an explicit outer_end_exclusive boundary")
        if outer_end_exclusive is not None and natural_test_end > outer_end_exclusive:
            natural_test_end = outer_end_exclusive
        if natural_test_end <= test_start:
            continue
        out.append(WalkForwardFold(i + 1, train, test, test_start, test_start, natural_test_end))
        cursor = end
    return out

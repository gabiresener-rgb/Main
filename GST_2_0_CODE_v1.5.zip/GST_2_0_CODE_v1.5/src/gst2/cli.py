from __future__ import annotations

import argparse
import json
import sys

from gst2.config import load_config
from gst2.service import run_from_files
from gst2.providers.mt5_bridge import validate_mt5_export, write_validation_json


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="gst2", description="GST 2.0 canonical joint Offset/SL/RR tester")
    sub = p.add_subparsers(dest="cmd", required=True)
    v = sub.add_parser("validate-config")
    v.add_argument("config")
    m = sub.add_parser("validate-mt5-export")
    m.add_argument("export_dir")
    m.add_argument("--slot-registry")
    m.add_argument("--json-out")
    r = sub.add_parser("run")
    r.add_argument("--signals", required=True)
    r.add_argument("--bars", required=True)
    r.add_argument("--ticks", required=True)
    r.add_argument("--config", required=True)
    r.add_argument("--out", required=True)
    r.add_argument("--causality-evidence")
    args = p.parse_args(argv)
    if args.cmd == "validate-config":
        load_config(args.config)
        print("CONFIG OK")
        return 0
    if args.cmd == "validate-mt5-export":
        v = validate_mt5_export(args.export_dir, args.slot_registry)
        if args.json_out:
            write_validation_json(v, args.json_out)
        print(json.dumps(v.__dict__ if hasattr(v, "__dict__") else {k: getattr(v, k) for k in v.__slots__}, ensure_ascii=False, indent=2))
        return 0
    result = run_from_files(
        signals=args.signals, bars=args.bars, ticks=args.ticks, config=args.config,
        out=args.out, causality_evidence=args.causality_evidence,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

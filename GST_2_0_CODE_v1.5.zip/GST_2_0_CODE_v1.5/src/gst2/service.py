from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from statistics import mean

from gst2 import SPEC_VERSION, __version__
from gst2.audit.pre_gst import run_pre_gst_audit
from gst2.causality.validator import NegativeOffsetCausalityValidator, load_causality_evidence
from gst2.config import CANONICAL_TIMEFRAMES, config_hash, load_config, scope_search_settings
from gst2.domain.models import CandidateMetrics, JointCandidate, RawEpisode, SignalSeed
from gst2.metrics.core import summarize_replayed
from gst2.metrics.equivalence import paired_equal_symbol_difference_ci, ci_within_practical_equivalence
from gst2.optimize.joint import JointSearchResult, search_offset
from gst2.providers.csv_provider import load_bars, load_instrument_specs, load_signal_seeds, load_ticks
from gst2.providers.mt5_bridge import validate_mt5_export
from gst2.providers.offset_provider import build_offset_episodes
from gst2.replay.five_order import ExecutionPolicy, replay_episode
from gst2.reporting.serialize import to_jsonable
from gst2.storage.artifacts import ArtifactWriter
from gst2.validate.splits import HoldoutSplit, chronological_holdout, expanding_walk_forward
from gst2.validate.evidence import load_provider_equivalence, validate_provider_equivalence, load_execution_reconciliation


def _sha256_file(path: str | Path) -> str:
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for block in iter(lambda:f.read(1024*1024),b""): h.update(block)
    return h.hexdigest()


def _sha256_json(obj) -> str:
    return hashlib.sha256(json.dumps(to_jsonable(obj),sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()).hexdigest()


def _code_fingerprint() -> str:
    root=Path(__file__).resolve().parent
    rows=[]
    for f in sorted(root.rglob("*.py")):
        rows.append((f.relative_to(root).as_posix(),_sha256_file(f)))
    return _sha256_json(rows)


def _resolve_cfg_path(value, config_path: str):
    if not value:
        return None
    q=Path(value)
    return str(q if q.is_absolute() else (Path(config_path).resolve().parent/q).resolve())


def _replay_with_errors(episodes, candidate, policy):
    rows=[]; errors=[]
    for e in episodes:
        try:
            rows.append(replay_episode(e,candidate,policy))
        except Exception as exc:
            errors.append({"episode_id":e.episode_id,"signal_id":e.seed.signal_id,"error_type":type(exc).__name__,"message":str(exc)})
    return rows,errors


def _scope_key(s:SignalSeed): return (str(s.slot_id),str(s.asset_group),str(s.timeframe))
def _scope_name(key): return f"slot_{key[0]}__{key[1]}__{key[2]}".replace("/","_")

def _group_scopes(seeds):
    out={}
    for s in seeds: out.setdefault(_scope_key(s),[]).append(s)
    return out


def _filter_scope(seeds:list[SignalSeed],cfg:dict)->list[SignalSeed]:
    sc=cfg.get("scope",{}); slots={str(x) for x in sc.get("slots",[])}; groups={str(x).upper() for x in sc.get("asset_groups",[])}; tfs={str(x).upper() for x in(sc.get("timeframes") or CANONICAL_TIMEFRAMES)}; syms={str(x) for x in sc.get("symbols",[])}
    return [s for s in seeds if (not slots or s.slot_id in slots) and (not groups or s.asset_group in groups) and (not tfs or s.timeframe in tfs) and (not syms or s.symbol in syms)]


def _candidate_key(m:CandidateMetrics):
    return (m.equal_symbol_expectancy_R,m.positive_symbol_share,m.pool_expectancy_R_per_episode,-m.pool_max_drawdown_R,m.high_tp_share_pct,-m.sl_pct)


def _policy(cfg:dict,config_path:str)->ExecutionPolicy:
    ep=cfg["execution_policy"]
    spec_path=ep.get("instrument_specs_csv")
    if spec_path and not Path(spec_path).is_absolute(): spec_path=str((Path(config_path).resolve().parent/spec_path).resolve())
    specs=load_instrument_specs(spec_path, strict=cfg.get("run_mode")=="PRODUCTION")
    return ExecutionPolicy(
        order_weights=tuple(float(x) for x in ep.get("order_weights",[1,1,1,1,1])),
        modified_stop_profit_pct=float(ep.get("modified_stop_profit_pct",0.10)),
        cost_R_per_weight=float(ep.get("cost_R_per_weight",0.0)), fill_model=str(ep.get("fill_model","FIRST_EXECUTABLE_QUOTE")),
        require_instrument_specs=bool(ep.get("require_instrument_specs",False)), require_account_economics=bool(ep.get("require_account_economics",False)), default_tick_size=float(ep.get("default_tick_size",0.00001)),
        instrument_specs=specs,
    )


def _legacy_ladder(cfg): return tuple(float(x) for x in cfg["joint_search"]["rr_ladder"].get("legacy_ladder_R",[0.4,0.7,1.2,2,3]))


def _build_all_offsets(seeds,bars,ticks,cfg,causality,*,window_start=None,window_end_exclusive=None):
    horizon=cfg["execution_policy"]["observation_horizon_bars"]; all_eps={}; diagnostics=[]
    for offset in range(-5,6):
        built=build_offset_episodes(seeds,bars,ticks,offset,horizon,causality,window_start=window_start,window_end_exclusive=window_end_exclusive,require_complete_horizon=True)
        all_eps[offset]=built.episodes; diagnostics.extend(built.diagnostics)
    return all_eps,diagnostics


def _search_scope_offsets(eps_by_offset,cfg,asset_group,timeframe,policy,source_signal_count=None):
    settings=scope_search_settings(cfg,asset_group,timeframe); legacy=_legacy_ladder(cfg); rob=cfg["validation"].get("robustness",{}); searches={}; exact_best={}; exact_rows={}
    for off in range(-5,6):
        eps=eps_by_offset.get(off,[])
        if not eps: continue
        sr=search_offset(eps,settings,policy,legacy_ladder=legacy,robustness_cfg=rob,boundary_cfg=cfg["joint_search"].get("boundary_expansion",{}),source_signal_count=source_signal_count or len(eps),built_episode_count=len(eps)); searches[off]=sr
        unresolved=sr.boundary_status=="SEARCH_BOUNDARY_HIT_UNRESOLVED"
        if sr.best_production is not None and not (unresolved and bool(cfg["joint_search"].get("boundary_expansion",{}).get("fail_if_unresolved",True))):
            c=JointCandidate(sr.best_production.offset,sr.best_production.sl_pct,sr.best_production.rr_ladder)
            rows,replay_errors=_replay_with_errors(eps,c,policy)
            try: m=summarize_replayed(c,rows,"OFFSET_FINAL_EXACT",episodes=eps,source_signal_count=source_signal_count or len(eps),built_episode_count=len(eps),replay_error_count=len(replay_errors))
            except ValueError: continue
            m.robust=sr.best_production.robust; m.robust_region_id=sr.best_production.robust_region_id; m.pareto_efficient=sr.best_production.pareto_efficient
            exact_best[off]=m; exact_rows[off]=rows
    return searches,exact_best,exact_rows


def _fixed_offset_robust_zone(eps_by_offset:dict[int,list[RawEpisode]],selected:CandidateMetrics,policy:ExecutionPolicy,cfg:dict,source_signal_count:int|None=None):
    rob=cfg["validation"]["robustness"]; ratio=float(rob.get("min_neighbor_expectancy_ratio",0.70)); dd_ratio=float(rob.get("max_neighbor_dd_ratio",1.50)); min_pos=float(rob.get("min_positive_symbol_share",0.60)); good=set()
    for off,eps in eps_by_offset.items():
        if not eps: continue
        c=JointCandidate(off,selected.sl_pct,selected.rr_ladder)
        rows,errs=_replay_with_errors(eps,c,policy)
        try: m=summarize_replayed(c,rows,"FIXED_OFFSET_ROBUSTNESS",episodes=eps,source_signal_count=source_signal_count or len(eps),built_episode_count=len(eps),replay_error_count=len(errs))
        except ValueError: continue
        if not m.production_eligible or m.equal_symbol_expectancy_R<=0 or m.positive_symbol_share<min_pos: continue
        if m.equal_symbol_expectancy_R+1e-12<selected.equal_symbol_expectancy_R*ratio: continue
        if m.pool_max_drawdown_R>max(selected.pool_max_drawdown_R,1e-9)*dd_ratio: continue
        good.add(off)
    lo=hi=selected.offset
    while lo-1 in good: lo-=1
    while hi+1 in good: hi+=1
    return lo,hi




def _validation_sample_check(m: CandidateMetrics, cfg: dict, *, min_completed: int | None = None) -> tuple[bool, list[str]]:
    """Fail-closed OOS/validation sample gate shared by selection, WF and holdout."""
    reasons: list[str] = []
    if min_completed is None:
        min_completed = max(5, int(int(cfg["joint_search"].get("min_episodes", 30)) * 0.25))
    if m.episode_count < int(min_completed):
        reasons.append("INSUFFICIENT_COMPLETED_EPISODES")
    if not m.production_eligible:
        reasons.append("CAUSALITY_OR_EXECUTION_NOT_ELIGIBLE")
    if m.equal_symbol_expectancy_R <= 0:
        reasons.append("NON_POSITIVE_EQUAL_SYMBOL_EXPECTANCY")
    min_pos = float(cfg["validation"].get("robustness", {}).get("min_positive_symbol_share", 0.60))
    if m.positive_symbol_share < min_pos:
        reasons.append("CROSS_SYMBOL_FAIL")
    if m.execution_invalid_count > 0:
        reasons.append("EXECUTION_INVALID_EPISODES")
    if m.replay_error_count > 0:
        reasons.append("REPLAY_ERRORS")
    source = max(m.source_signal_count, 1)
    gates = cfg["validation"].get("production_gates", {})
    if m.excluded_episode_count / source > float(gates.get("max_excluded_episode_share", 0.20)):
        reasons.append("TOO_MANY_EXCLUDED_EPISODES")
    if m.unresolved_timeout_count / source > float(gates.get("max_unresolved_episode_share", 0.20)):
        reasons.append("TOO_MANY_UNRESOLVED_EPISODES")
    return not reasons, reasons

def _walk_forward_scope(dev_seeds,bars,ticks,cfg,causality,asset_group,timeframe,policy,outer_end_exclusive):
    wf_cfg=cfg["validation"]["walk_forward"]
    if not bool(wf_cfg.get("enabled",True)): return {"status":"DISABLED","folds":[]}
    folds=expanding_walk_forward(dev_seeds,int(wf_cfg.get("folds",4)),float(wf_cfg.get("min_train_fraction",0.40)),outer_end_exclusive=outer_end_exclusive); out=[]; aggregate=0.0
    for fold in folds:
        train_eps,_=_build_all_offsets(fold.train,bars,ticks,cfg,causality,window_end_exclusive=fold.train_end_exclusive)
        _,best,_=_search_scope_offsets(train_eps,cfg,asset_group,timeframe,policy,source_signal_count=len(fold.train))
        if not best: out.append({"fold":fold.fold,"status":"NO_PRODUCTION_CANDIDATE"}); continue
        selected=max(best.values(),key=_candidate_key); c=JointCandidate(selected.offset,selected.sl_pct,selected.rr_ladder)
        tb=build_offset_episodes(fold.test,bars,ticks,selected.offset,cfg["execution_policy"]["observation_horizon_bars"],causality,window_start=fold.test_start,window_end_exclusive=fold.test_end_exclusive,require_complete_horizon=True)
        if not tb.episodes: out.append({"fold":fold.fold,"status":"NO_TEST_EPISODES","selected":to_jsonable(selected)}); continue
        rows,replay_errors=_replay_with_errors(tb.episodes,c,policy)
        try: tm=summarize_replayed(c,rows,"WALK_FORWARD_TEST",episodes=tb.episodes,source_signal_count=len(fold.test),built_episode_count=len(tb.episodes),replay_error_count=len(replay_errors))
        except ValueError: out.append({"fold":fold.fold,"status":"NO_COMPLETED_TEST_EPISODES"}); continue
        aggregate+=tm.pool_net_R
        fold_ok, fold_reasons = _validation_sample_check(tm, cfg)
        status="PASS" if fold_ok else "FAIL"
        out.append({"fold":fold.fold,"status":status,"validation_fail_reasons":fold_reasons,"selected":to_jsonable(selected),"test_metrics":to_jsonable(tm),"train_signal_count":len(fold.train),"test_signal_count":len(fold.test)})
    valid=[x for x in out if x.get("status") in {"PASS","FAIL"}]
    positive=sum(x.get("status")=="PASS" for x in out)
    total_folds=len(folds)
    share=positive/total_folds if total_folds else 0.0
    required_share=float(wf_cfg.get("min_positive_fold_share",0.75)); require_agg=bool(wf_cfg.get("require_positive_aggregate_oos",True))
    missing_or_invalid=total_folds-len(valid)
    status="PASS" if total_folds and missing_or_invalid==0 and share>=required_share and (aggregate>0 or not require_agg) else "FAIL" if total_folds else "NO_VALID_FOLDS"
    return {"status":status,"positive_fold_share":share,"aggregate_oos_pool_R":aggregate,"fold_count":total_folds,"invalid_or_missing_fold_count":missing_or_invalid,"folds":out}


def _trade_event_ledger_rows(results:list,sample:str):
    out=[]
    for r in results:
        for seq,e in enumerate(r.events, start=1):
            out.append({
                "sample":sample,"episode_id":r.episode_id,"signal_id":r.signal_id,"slot_id":r.slot_id,
                "asset_group":r.asset_group,"symbol":r.symbol,"timeframe":r.timeframe,"direction":r.direction.value,
                "offset":r.offset,"source_signal_time":r.source_signal_time.isoformat(),
                "candidate_entry_time":r.candidate_entry_time.isoformat(),"event_seq":seq,"event_type":e.event_type,
                "event_time":e.ts.isoformat(),"event_price":e.price,"order_index":e.order_index,"level":e.level,
                "pnl_order_R":e.pnl_order_R,"pnl_pool_R":e.pnl_pool_R,"details_json":json.dumps(to_jsonable(e.details),ensure_ascii=False,sort_keys=True),
            })
    return out


def _execution_ledger_rows(results:list,sample:str):
    out=[]
    for r in results:
        for o in r.orders:
            out.append({
                "sample":sample,"episode_id":r.episode_id,"signal_id":r.signal_id,"slot_id":r.slot_id,"asset_group":r.asset_group,"symbol":r.symbol,"timeframe":r.timeframe,"direction":r.direction.value,"offset":r.offset,
                "source_signal_time":r.source_signal_time.isoformat(),"entry_time":o.entry_time.isoformat(),"entry_price":o.entry_price,"signal_outcome":r.outcome.value if r.outcome else "","completion_status":r.completion_status.value,
                "order_index":o.order_index,"weight":o.weight,"target_level":o.target_level,
                "nominal_target_R":o.target_R,"effective_target_R":o.effective_target_R,
                "nominal_target_pct":o.target_pct,"effective_target_pct":o.effective_target_pct,"target_price":o.target_price,
                "nominal_sl_pct":r.sl_pct,"effective_sl_pct":r.effective_sl_pct,"instrument_tick_size":r.instrument_tick_size,"instrument_spec_fingerprint":r.instrument_spec_fingerprint,
                "close_time":o.close_time.isoformat(),"close_price":o.close_price,"close_reason":o.close_reason.value,"gross_R":o.gross_R,"cost_R":o.cost_R,"net_R":o.net_R,
                "initial_risk_account":o.initial_risk_account,"net_pnl_account":o.net_pnl_account,"initial_sl_price":o.initial_sl_price,"active_sl_price_at_close":o.active_sl_price_at_close,
                "stop_modified":o.stop_modified,"stop_modified_time":o.stop_modified_time.isoformat() if o.stop_modified_time else "","modified_stop_price":o.modified_stop_price,
                "episode_realized_pool_R":r.pool_realized_R,"episode_unrealized_pool_R":r.pool_unrealized_R,"episode_pool_R":r.pool_R,
                "episode_pool_order_R_sum":r.pool_order_R_sum,"episode_account_pnl":r.pool_net_pnl_account,
                "residual_open_weight":r.residual_open_weight,"residual_risk_R":r.residual_risk_R,
            })
    return out




def _open_order_ledger_rows(results:list,sample:str):
    out=[]
    for r in results:
        for o in r.open_orders:
            out.append({
                "sample":sample,"episode_id":r.episode_id,"signal_id":r.signal_id,"slot_id":r.slot_id,
                "asset_group":r.asset_group,"symbol":r.symbol,"timeframe":r.timeframe,"direction":r.direction.value,"offset":r.offset,
                "source_signal_time":r.source_signal_time.isoformat(),"candidate_entry_time":r.candidate_entry_time.isoformat(),
                "completion_status":r.completion_status.value,"order_index":o.order_index,"weight":o.weight,"target_level":o.target_level,
                "nominal_target_R":o.target_R,"effective_target_R":o.effective_target_R,
                "nominal_target_pct":o.target_pct,"effective_target_pct":o.effective_target_pct,"target_price":o.target_price,
                "mark_time":o.mark_time.isoformat(),"mark_price":o.mark_price,"gross_R":o.gross_R,
                "estimated_cost_R":o.estimated_cost_R,"net_R_if_closed":o.net_R_if_closed,
                "initial_risk_account":o.initial_risk_account,"net_pnl_account_if_closed":o.net_pnl_account_if_closed,
                "active_sl_price":o.active_sl_price,"stop_modified":o.stop_modified,"modified_stop_price":o.modified_stop_price,
                "episode_realized_pool_R":r.pool_realized_R,"episode_unrealized_pool_R":r.pool_unrealized_R,"episode_pool_R":r.pool_R,
                "residual_open_weight":r.residual_open_weight,"residual_risk_R":r.residual_risk_R,
                "instrument_tick_size":r.instrument_tick_size,"instrument_spec_fingerprint":r.instrument_spec_fingerprint,
            })
    return out


def _build_diagnostic_rows(diagnostics,sample:str):
    out=[]
    for d in diagnostics:
        out.append({
            "sample":sample,"signal_id":d.signal_id,"slot_id":d.slot_id,"asset_group":d.asset_group,
            "symbol":d.symbol,"timeframe":d.timeframe,"offset":d.offset,"status":d.status,"reason":d.reason,
            "entry_bar_time":d.entry_bar_time.isoformat() if d.entry_bar_time else "",
            "candidate_entry_time":d.candidate_entry_time.isoformat() if d.candidate_entry_time else "",
            "causality_status":d.causality_status,"production_eligible":d.production_eligible,
        })
    return out


def _replay_error_rows(errors:list,sample:str):
    return [{"sample":sample,**e} for e in errors]

def _production_gate(selected:CandidateMetrics,selected_search:JointSearchResult,wf:dict,holdout_status:str,cfg:dict)->tuple[str,list[str]]:
    g=cfg["validation"].get("production_gates",{}); reasons=[]; min_eps=int(cfg["joint_search"].get("min_episodes",30))
    if cfg.get("run_mode") != "PRODUCTION":
        reasons.append("RUN_MODE_NOT_PRODUCTION")
    if selected.episode_count < min_eps: reasons.append("INSUFFICIENT_COMPLETED_EPISODES")
    if not selected.production_eligible: reasons.append("CAUSALITY_OR_EXECUTION_NOT_ELIGIBLE")
    if not selected.robust: reasons.append("NOT_ROBUST")
    if selected.equal_symbol_expectancy_R<=0: reasons.append("NON_POSITIVE_EQUAL_SYMBOL_EXPECTANCY")
    if selected.positive_symbol_share<float(cfg["validation"]["robustness"].get("min_positive_symbol_share",0.60)): reasons.append("CROSS_SYMBOL_FAIL")
    if wf.get("status")!="PASS": reasons.append("WALK_FORWARD_NOT_PASSED")
    if holdout_status!="PASS": reasons.append("HOLDOUT_NOT_PASSED")
    if selected_search.boundary_status=="SEARCH_BOUNDARY_HIT_UNRESOLVED": reasons.append("SEARCH_BOUNDARY_UNRESOLVED")
    if selected.execution_invalid_count>0: reasons.append("EXECUTION_INVALID_EPISODES")
    if selected.replay_error_count>0: reasons.append("REPLAY_ERRORS")
    source=max(selected.source_signal_count,1)
    excluded_share=selected.excluded_episode_count/source
    unresolved_share=selected.unresolved_timeout_count/source
    if excluded_share>float(g.get("max_excluded_episode_share",0.20)): reasons.append("TOO_MANY_EXCLUDED_EPISODES")
    if unresolved_share>float(g.get("max_unresolved_episode_share",0.20)): reasons.append("TOO_MANY_UNRESOLVED_EPISODES")
    if cfg.get("run_mode") != "PRODUCTION":
        return ("RESEARCH_ONLY", reasons)
    return ("PRODUCTION_VALIDATED" if not reasons else "NOT_VALIDATED",reasons)


def _validate_bridge_if_applicable(signals,bars,ticks,cfg,config_path):
    sp,bp,tp=Path(signals).resolve(),Path(bars).resolve(),Path(ticks).resolve()
    if sp.parent==bp.parent==tp.parent and sp.name=="signals.csv" and bp.name=="bars.csv" and tp.name=="ticks.csv":
        slot_reg=cfg.get("input_validation",{}).get("slot_registry_csv")
        if slot_reg and not Path(slot_reg).is_absolute(): slot_reg=str((Path(config_path).resolve().parent/slot_reg).resolve())
        return validate_mt5_export(sp.parent,slot_reg,production_mode=cfg.get("run_mode")=="PRODUCTION")
    if cfg.get("run_mode")=="PRODUCTION" and not bool(cfg.get("input_validation",{}).get("allow_non_mt5_input",False)):
        raise ValueError("PRODUCTION requires standard MT5 bridge export filenames in one directory or allow_non_mt5_input=true with equivalent external validation")
    return None


def run_from_files(*,signals:str,bars:str,ticks:str,config:str,out:str,causality_evidence:str|None=None)->dict:
    cfg=load_config(config); writer=ArtifactWriter(out)
    if cfg.get("run_mode")=="PRODUCTION" and any(Path(out).rglob("HOLDOUT_CONSUMED.json")):
        raise ValueError("holdout in this output directory has already been consumed; start a new immutable run")
    bridge_validation=_validate_bridge_if_applicable(signals,bars,ticks,cfg,config)
    if bridge_validation: writer.json("mt5_export_validation.json",bridge_validation)
    seeds=_filter_scope(load_signal_seeds(signals),cfg)
    if not seeds: raise ValueError("no signals remain after scope filters")
    bar_df=load_bars(bars); tick_df=load_ticks(ticks)
    audit=run_pre_gst_audit(seeds,bar_df,tick_df,production_mode=cfg.get("run_mode")=="PRODUCTION"); writer.json("pre_gst_audit.json",audit)
    if not audit.pass_gate: writer.manifest_sha256(); raise ValueError("Pre-GST audit contains P0 blockers")
    policy=_policy(cfg,config)
    input_hashes={"signals":_sha256_file(signals),"bars":_sha256_file(bars),"ticks":_sha256_file(ticks)}
    spec_path=_resolve_cfg_path(cfg.get("execution_policy",{}).get("instrument_specs_csv"),config)
    slot_registry_path=_resolve_cfg_path(cfg.get("input_validation",{}).get("slot_registry_csv"),config)
    instrument_specs_hash=_sha256_file(spec_path) if spec_path and Path(spec_path).exists() else ""
    slot_registry_hash=_sha256_file(slot_registry_path) if slot_registry_path and Path(slot_registry_path).exists() else ""
    code_fingerprint=_code_fingerprint()
    data_fingerprint=_sha256_json(input_hashes)
    execution_model_fingerprint=_sha256_json({"execution_policy":cfg.get("execution_policy",{}),"instrument_specs_hash":instrument_specs_hash,"code_fingerprint":code_fingerprint})

    ev_path=causality_evidence or cfg["offset_search"].get("causality_evidence")
    ev_path=_resolve_cfg_path(ev_path,config) if ev_path else None
    evidence,evidence_file_hash=load_causality_evidence(ev_path); causality=NegativeOffsetCausalityValidator(evidence,evidence_file_hash)
    ext_cfg=cfg.get("validation",{}).get("external_evidence",{})
    pe_path=_resolve_cfg_path(ext_cfg.get("provider_equivalence_csv"),config); er_path=_resolve_cfg_path(ext_cfg.get("execution_reconciliation_json"),config)
    pe,pe_hash=load_provider_equivalence(pe_path); pe_fail=validate_provider_equivalence(seeds,pe) if pe_path else list(s.signal_id for s in seeds)
    er,er_hash=load_execution_reconciliation(
        er_path,expected_data_fingerprint=data_fingerprint,expected_execution_model_fingerprint=execution_model_fingerprint,
        min_matched_trade_count=int(ext_cfg.get("min_matched_trade_count",1)),
        allowed_max_price_error_ticks=float(ext_cfg.get("max_price_error_ticks",0.0)),
        allowed_max_time_error_seconds=float(ext_cfg.get("max_time_error_seconds",0.0)),
        allowed_max_account_pnl_error=ext_cfg.get("max_account_pnl_error"),
    )
    external_evidence_status={"provider_equivalence_pass":not pe_fail,"provider_equivalence_missing_signal_ids":pe_fail[:100],"provider_equivalence_file_hash":pe_hash,"execution_reconciliation":er,"execution_reconciliation_file_hash":er_hash}
    writer.json("external_evidence_validation.json",external_evidence_status)
    if cfg.get("run_mode")=="PRODUCTION" and (pe_fail or not er or not er.get("pass")):
        writer.manifest_sha256(); raise ValueError("PRODUCTION external evidence gates failed; see external_evidence_validation.json")
    manifest={"gst_code_version":__version__,"spec_version":SPEC_VERSION,"started_at_utc":datetime.now(timezone.utc).isoformat(),"config_hash":config_hash(cfg),"input_hashes":input_hashes,"data_fingerprint":data_fingerprint,"code_fingerprint":code_fingerprint,"execution_model_fingerprint":execution_model_fingerprint,"instrument_specs_hash":instrument_specs_hash,"slot_registry_hash":slot_registry_hash,"causality_evidence_path":ev_path,"causality_evidence_hash":evidence_file_hash,"provider_equivalence_hash":pe_hash,"execution_reconciliation_hash":er_hash,"holdout_access_policy":"full episode interval isolation + immutable selected-config lock"}; writer.json("run_manifest.json",manifest)
    all_scope_results=[]
    for scope,scope_seeds in sorted(_group_scopes(seeds).items()):
        slot_id,asset_group,timeframe=scope; scope_dir=f"scopes/{_scope_name(scope)}"
        split=chronological_holdout(scope_seeds,float(cfg["validation"].get("final_holdout_fraction",0.20)))
        selection_split=chronological_holdout(split.development,float(cfg["validation"].get("selection_oos_fraction",0.15)))

        # Candidate generation sees only the optimization interval.
        opt_eps,diagnostics=_build_all_offsets(selection_split.development,bar_df,tick_df,cfg,causality,window_end_exclusive=selection_split.boundary_time)
        writer.csv(f"{scope_dir}/offset_diagnostics.csv",diagnostics)
        searches,best,best_rows=_search_scope_offsets(opt_eps,cfg,asset_group,timeframe,policy,source_signal_count=len(selection_split.development))
        if cfg.get("storage",{}).get("persist_full_surface",True):
            for off,sr in searches.items(): writer.csv(f"{scope_dir}/surfaces/offset_{off:+d}.csv",sr.rows)
        writer.json(f"{scope_dir}/offset_summary.json",[{"offset":off,"sample_status":sr.sample_status,"search_boundary_status":sr.boundary_status,"boundary_history":sr.boundary_history,"best_research":to_jsonable(sr.best_research),"best_production":to_jsonable(sr.best_production)} for off,sr in sorted(searches.items())])
        if not best:
            result={"slot_id":slot_id,"asset_group":asset_group,"timeframe":timeframe,"final_validation_status":"NOT_VALIDATED","validation_fail_reasons":["NO_PRODUCTION_ELIGIBLE_CONFIG"]}; writer.json(f"{scope_dir}/result_row.json",result); all_scope_results.append(result); continue

        # Freeze a small robust/Pareto candidate set BEFORE the OOS selection interval.
        per_offset=int(cfg["validation"].get("selection_candidates_per_offset",5)); frozen=[]
        for off,sr in searches.items():
            cand=[r for r in sr.rows if r.production_eligible and r.robust and r.pareto_efficient]
            cand=sorted(cand,key=_candidate_key,reverse=True)[:per_offset]
            frozen.extend(cand)
        if not frozen:
            frozen=list(best.values())
        selection_results=[]
        for cm in frozen:
            sb=build_offset_episodes(selection_split.holdout,bar_df,tick_df,cm.offset,cfg["execution_policy"]["observation_horizon_bars"],causality,window_start=selection_split.boundary_time,window_end_exclusive=split.boundary_time,require_complete_horizon=True)
            if not sb.episodes: continue
            cc=JointCandidate(cm.offset,cm.sl_pct,cm.rr_ladder)
            rr,replay_errors=_replay_with_errors(sb.episodes,cc,policy)
            try: mm=summarize_replayed(cc,rr,"SELECTION_OOS",episodes=sb.episodes,source_signal_count=len(selection_split.holdout),built_episode_count=len(sb.episodes),replay_error_count=len(replay_errors))
            except ValueError: continue
            mm.robust=cm.robust; mm.pareto_efficient=cm.pareto_efficient; mm.robust_region_id=cm.robust_region_id
            selection_ok, selection_reasons = _validation_sample_check(mm, cfg)
            if selection_ok:
                selection_results.append((mm,cm,rr,sb,replay_errors))
        if not selection_results:
            result={"slot_id":slot_id,"asset_group":asset_group,"timeframe":timeframe,"final_validation_status":"NOT_VALIDATED","validation_fail_reasons":["NO_POSITIVE_SELECTION_OOS_CANDIDATE"]}; writer.json(f"{scope_dir}/result_row.json",result); all_scope_results.append(result); continue
        selection_results.sort(key=lambda x:_candidate_key(x[0]),reverse=True)
        chosen_idx=0
        top_metrics,_,top_rows,_,_=selection_results[0]
        robcfg=cfg["validation"].get("robustness",{})
        prefilter=float(robcfg.get("expectancy_equivalence_abs_R",0.0))
        bs_samples=int(robcfg.get("equivalence_bootstrap_samples",500)); bs_alpha=float(robcfg.get("equivalence_alpha",0.05))
        lower=[]
        for idx,(mm,orig,rows_,_,_) in enumerate(selection_results[1:],start=1):
            if orig.sl_pct >= selection_results[0][1].sl_pct-1e-12:
                continue
            if top_metrics.equal_symbol_expectancy_R-mm.equal_symbol_expectancy_R > prefilter+1e-12:
                continue
            ci=paired_equal_symbol_difference_ci(top_rows,rows_,samples=bs_samples,alpha=bs_alpha,require_identical_signal_sets=True)
            if ci is not None and ci_within_practical_equivalence(ci,prefilter):
                mm.equivalence_vs_best_ci_low_R,mm.equivalence_vs_best_ci_high_R=ci
                mm.practically_equivalent_to_best=True
                mm.statistically_indistinguishable_from_best=True
                lower.append((orig.sl_pct,-mm.equal_symbol_expectancy_R,mm.pool_max_drawdown_R,idx))
        if lower:
            chosen_idx=min(lower)[-1]
        selected_oos,selected_origin,selection_rows,selection_built,selection_errors=selection_results[chosen_idx]
        selected=selected_origin; c=JointCandidate(selected.offset,selected.sl_pct,selected.rr_ladder)

        # Replay the locked tuple over the entire pre-holdout development interval for reporting only.
        full_dev_built=build_offset_episodes(split.development,bar_df,tick_df,selected.offset,cfg["execution_policy"]["observation_horizon_bars"],causality,window_end_exclusive=split.boundary_time,require_complete_horizon=True)
        selected_dev_rows,selected_dev_errors=_replay_with_errors(full_dev_built.episodes,c,policy)
        try: selected_report=summarize_replayed(c,selected_dev_rows,"FULL_DEVELOPMENT_REPORT",episodes=full_dev_built.episodes,source_signal_count=len(split.development),built_episode_count=len(full_dev_built.episodes),replay_error_count=len(selected_dev_errors))
        except ValueError: selected_report=selected_oos
        selected_report.robust=selected.robust; selected_report.pareto_efficient=selected.pareto_efficient; selected_report.robust_region_id=selected.robust_region_id
        zone_min,zone_max=_fixed_offset_robust_zone(opt_eps,selected,policy,cfg,source_signal_count=len(selection_split.development))
        wf=_walk_forward_scope(split.development,bar_df,tick_df,cfg,causality,asset_group,timeframe,policy,split.boundary_time); writer.json(f"{scope_dir}/walk_forward.json",wf)

        lock_payload={
            "joint_config_id":selected.joint_config_id,"offset":selected.offset,"sl_pct":selected.sl_pct,"rr_ladder":list(selected.rr_ladder),
            "config_hash":config_hash(cfg),"input_hashes":manifest["input_hashes"],"data_fingerprint":data_fingerprint,
            "code_fingerprint":code_fingerprint,"execution_model_fingerprint":execution_model_fingerprint,
            "instrument_specs_hash":instrument_specs_hash,"slot_registry_hash":slot_registry_hash,
            "causality_evidence_hash":evidence_file_hash,"provider_equivalence_hash":pe_hash,"execution_reconciliation_hash":er_hash,
            "selection_oos_metrics":to_jsonable(selected_oos),
        }
        lock_hash=_sha256_json(lock_payload); lock_payload["lock_hash"]=lock_hash; lock_payload["execution_fingerprint"]=lock_hash
        lock_path=writer.json(f"{scope_dir}/selected_config.lock.json",lock_payload)
        if _sha256_json({k:v for k,v in json.loads(lock_path.read_text(encoding="utf-8")).items() if k not in {"lock_hash","execution_fingerprint"}}) != lock_hash:
            raise RuntimeError("selected-config lock verification failed before holdout")

        holdout_status="NOT_RUN"; holdout_metrics=None; holdout_rows=[]; holdout_errors=[]; holdout_built=None
        if split.holdout:
            hb=build_offset_episodes(split.holdout,bar_df,tick_df,selected.offset,cfg["execution_policy"]["observation_horizon_bars"],causality,window_start=split.boundary_time,require_complete_horizon=True)
            holdout_built=hb
            if hb.episodes:
                holdout_rows,holdout_errors=_replay_with_errors(hb.episodes,c,policy)
                try:
                    holdout_metrics=summarize_replayed(c,holdout_rows,"FINAL_HOLDOUT",episodes=hb.episodes,source_signal_count=len(split.holdout),built_episode_count=len(hb.episodes),replay_error_count=len(holdout_errors))
                    min_holdout=max(5,int(scope_search_settings(cfg,asset_group,timeframe).min_episodes*0.25))
                    holdout_ok, holdout_reasons = _validation_sample_check(holdout_metrics, cfg, min_completed=min_holdout)
                    holdout_status="PASS" if holdout_ok else "FAIL"
                except ValueError: holdout_status="INSUFFICIENT_EVIDENCE"
            else: holdout_status="INSUFFICIENT_EVIDENCE"
            consumed={"scope":_scope_name(scope),"selected_config_lock_hash":lock_hash,"consumed_at_utc":datetime.now(timezone.utc).isoformat()}
            writer.json(f"{scope_dir}/HOLDOUT_CONSUMED.json",consumed)
            writer.json("HOLDOUT_CONSUMED.json",consumed)
        writer.json(f"{scope_dir}/selection_oos.json",{"selected":to_jsonable(selected_oos),"candidate_count":len(selection_results)})
        writer.json(f"{scope_dir}/holdout.json",{"status":holdout_status,"metrics":holdout_metrics,"selected_config_lock_hash":lock_hash})
        writer.csv(f"{scope_dir}/execution_ledger_development.csv",_execution_ledger_rows(selected_dev_rows,"DEVELOPMENT")); writer.csv(f"{scope_dir}/execution_ledger_selection_oos.csv",_execution_ledger_rows(selection_rows,"SELECTION_OOS")); writer.csv(f"{scope_dir}/execution_ledger_holdout.csv",_execution_ledger_rows(holdout_rows,"HOLDOUT"))
        writer.csv(f"{scope_dir}/open_order_ledger_development.csv",_open_order_ledger_rows(selected_dev_rows,"DEVELOPMENT")); writer.csv(f"{scope_dir}/open_order_ledger_selection_oos.csv",_open_order_ledger_rows(selection_rows,"SELECTION_OOS")); writer.csv(f"{scope_dir}/open_order_ledger_holdout.csv",_open_order_ledger_rows(holdout_rows,"HOLDOUT"))
        writer.csv(f"{scope_dir}/trade_event_ledger_development.csv",_trade_event_ledger_rows(selected_dev_rows,"DEVELOPMENT")); writer.csv(f"{scope_dir}/trade_event_ledger_selection_oos.csv",_trade_event_ledger_rows(selection_rows,"SELECTION_OOS")); writer.csv(f"{scope_dir}/trade_event_ledger_holdout.csv",_trade_event_ledger_rows(holdout_rows,"HOLDOUT"))
        writer.csv(f"{scope_dir}/build_diagnostics_development.csv",_build_diagnostic_rows(full_dev_built.diagnostics,"DEVELOPMENT"))
        writer.csv(f"{scope_dir}/build_diagnostics_selection_oos.csv",_build_diagnostic_rows(selection_built.diagnostics,"SELECTION_OOS"))
        writer.csv(f"{scope_dir}/build_diagnostics_holdout.csv",_build_diagnostic_rows(holdout_built.diagnostics if holdout_built else [],"HOLDOUT"))
        writer.csv(f"{scope_dir}/replay_errors_development.csv",_replay_error_rows(selected_dev_errors,"DEVELOPMENT"))
        writer.csv(f"{scope_dir}/replay_errors_selection_oos.csv",_replay_error_rows(selection_errors,"SELECTION_OOS"))
        writer.csv(f"{scope_dir}/replay_errors_holdout.csv",_replay_error_rows(holdout_errors,"HOLDOUT"))
        selected_search=searches[selected.offset]; final_status,reasons=_production_gate(selected_report,selected_search,wf,holdout_status,cfg)
        if selected_oos.equal_symbol_expectancy_R<=0: reasons.append("SELECTION_OOS_NOT_POSITIVE"); final_status="NOT_VALIDATED"
        tp_pct=[selected.sl_pct*x for x in selected.rr_ladder]
        result={"slot_id":slot_id,"asset_group":asset_group,"timeframe":timeframe,"joint_config_id":selected.joint_config_id,"selected_offset":selected.offset,"offset_robust_zone_min":zone_min,"offset_robust_zone_max":zone_max,"selected_sl_pct":selected.sl_pct,
                **{f"tp{i+1}_pct":tp_pct[i] for i in range(5)},**{f"tp{i+1}_R":selected.rr_ladder[i] for i in range(5)},
                "selected_parameters_are_nominal":True,"effective_parameters_are_episode_specific":True,
                "development_source_signal_count":selected_report.source_signal_count,"development_built_episode_count":selected_report.built_episode_count,"development_financial_episode_count":selected_report.financial_episode_count,"development_unresolved_timeout_count":selected_report.unresolved_timeout_count,"development_replay_error_count":selected_report.replay_error_count,
                "development_bad_pct":selected_report.bad_pct,"development_tp1_pct":selected_report.tp1_pct,"development_tp2_pct":selected_report.tp2_pct,"development_tp3_pct":selected_report.tp3_pct,"development_tp4_pct":selected_report.tp4_pct,"development_tp5_pct":selected_report.tp5_pct,"development_episode_count":selected_report.episode_count,"development_excluded_episode_count":selected_report.excluded_episode_count,
                "development_pool_expectancy_R":selected_report.pool_expectancy_R_per_episode,"development_equal_symbol_expectancy_R":selected_report.equal_symbol_expectancy_R,"development_positive_symbol_share":selected_report.positive_symbol_share,"development_mark_to_market_max_dd_R":selected_report.mark_to_market_drawdown_R,"development_event_chronology_max_dd_R":selected_report.event_chronology_drawdown_R,"development_modified_stop_close_count":selected_report.modified_stop_close_count,"development_account_currency_pnl":selected_report.account_currency_pnl,
                "selection_oos_equal_symbol_expectancy_R":selected_oos.equal_symbol_expectancy_R,"selection_oos_pool_expectancy_R":selected_oos.pool_expectancy_R_per_episode,"selection_oos_modified_stop_close_count":selected_oos.modified_stop_close_count,"selection_oos_mark_to_market_max_dd_R":selected_oos.mark_to_market_drawdown_R,"selection_oos_account_currency_pnl":selected_oos.account_currency_pnl,
                "holdout_modified_stop_close_count":holdout_metrics.modified_stop_close_count if holdout_metrics else None,"holdout_mark_to_market_max_dd_R":holdout_metrics.mark_to_market_drawdown_R if holdout_metrics else None,"holdout_account_currency_pnl":holdout_metrics.account_currency_pnl if holdout_metrics else None,
                "walk_forward_status":wf.get("status"),"holdout_status":holdout_status,"holdout_metrics":to_jsonable(holdout_metrics),"search_boundary_status":selected_search.boundary_status,"final_validation_status":final_status,"validation_fail_reasons":sorted(set(reasons)),"selected_config_lock_hash":lock_hash,"execution_fingerprint":lock_hash}
        writer.json(f"{scope_dir}/result_row.json",result); all_scope_results.append(result)
    writer.csv("final_results.csv",all_scope_results); manifest["completed_at_utc"]=datetime.now(timezone.utc).isoformat(); manifest["scope_count"]=len(all_scope_results); writer.json("run_manifest.json",manifest); writer.manifest_sha256(); return {"out":str(Path(out).resolve()),"scopes":all_scope_results,"audit":to_jsonable(audit)}

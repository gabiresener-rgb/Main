from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
import json
import random
import re

import pandas as pd

from gst2.config import CANONICAL_TIMEFRAMES
from gst2.providers.csv_provider import load_bars, load_signal_seeds


SLOT_REGISTRY_COLUMNS = {
    "enabled", "slot_id", "slot_name", "provider_type", "indicator_path",
    "handle_timeframe", "signal_timeframe", "buy_buffer", "sell_buffer",
    "direction_buffer", "buy_value", "sell_value", "emit_on_change",
    "symbols", "live_buffer_shift", "provider_version", "provider_hash", "horizon_bars",
}
SIGNAL_COLUMNS = {
    "signal_id", "slot_id", "asset_group", "symbol", "timeframe",
    "direction", "signal_time",
}
BAR_COLUMNS = {"open_time", "symbol", "timeframe", "open", "high", "low", "close"}
TICK_COLUMNS = {"timestamp", "symbol", "bid", "ask"}


@dataclass(slots=True)
class Mt5ExportValidation:
    export_dir: str
    signal_rows: int
    distinct_slots: int
    distinct_symbols: int
    distinct_timeframes: int
    bar_rows: int
    tick_rows: int
    registry_rows: int | None
    registry_distinct_slots: int | None
    slot_count_limit: str
    warnings: list[str]


def _require_columns(df: pd.DataFrame, required: set[str], label: str) -> None:
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"{label} missing columns: {sorted(missing)}")


def load_slot_registry(path: str | Path) -> pd.DataFrame:
    """Load the MT5 provider registry without imposing any slot-count ceiling."""
    df = pd.read_csv(path)
    _require_columns(df, SLOT_REGISTRY_COLUMNS, "slot registry")
    out = df.copy()
    enabled = out["enabled"].astype(str).str.strip().str.upper().isin({"1", "TRUE", "YES", "Y", "ON"})
    out = out.loc[enabled].reset_index(drop=True)
    if out.empty:
        return out
    if out["slot_id"].astype(str).str.strip().eq("").any():
        raise ValueError("enabled slot registry rows require non-empty slot_id")
    if out["provider_hash"].astype(str).str.strip().isin({"", "REPLACE_PROVIDER_HASH", "nan", "NaN"}).any():
        raise ValueError("enabled slot registry rows require a real provider_hash")
    out["provider_type"] = out["provider_type"].astype(str).str.upper().str.strip()
    supported = {"DUAL_BUFFER", "DIRECTION_BUFFER_EVENT", "DIRECTION_BUFFER_STATE"}
    bad = sorted(set(out["provider_type"]) - supported)
    if bad:
        raise ValueError(f"unsupported MT5 provider_type values: {bad}")
    # The generic bridge can freeze timestamps only when the indicator handle is
    # instantiated at the actual source signal TF. Multiplexed multi-TF sources
    # require a thin adapter per source TF; guessing timestamps is forbidden.
    htf = out["handle_timeframe"].astype(str).str.upper().str.strip()
    stf = out["signal_timeframe"].astype(str).str.upper().str.strip()
    bad_tf = sorted((set(htf) | set(stf)) - set(CANONICAL_TIMEFRAMES))
    if bad_tf:
        raise ValueError(f"unsupported MT5 timeframe(s): {bad_tf}; allowed: {list(CANONICAL_TIMEFRAMES)}")
    mismatch = out.loc[htf != stf, ["slot_id", "handle_timeframe", "signal_timeframe"]]
    if not mismatch.empty:
        raise ValueError(
            "generic MT5 provider requires handle_timeframe == signal_timeframe; "
            f"use a thin source-TF adapter for rows: {mismatch.to_dict(orient='records')[:10]}"
        )
    numeric_cols = ["buy_buffer", "sell_buffer", "direction_buffer", "buy_value", "sell_value", "live_buffer_shift", "horizon_bars"]
    for col in numeric_cols:
        out[col] = pd.to_numeric(out[col], errors="raise")
    dual = out["provider_type"].eq("DUAL_BUFFER")
    if ((out.loc[dual, "buy_buffer"] < 0) | (out.loc[dual, "sell_buffer"] < 0)).any():
        raise ValueError("DUAL_BUFFER rows require buy_buffer >= 0 and sell_buffer >= 0")
    direction = ~dual
    if (out.loc[direction, "direction_buffer"] < 0).any():
        raise ValueError("direction-buffer rows require direction_buffer >= 0")
    if (out.loc[direction, "buy_value"] == out.loc[direction, "sell_value"]).any():
        raise ValueError("direction-buffer rows require distinct buy_value and sell_value")
    if (out["live_buffer_shift"] < 1).any():
        raise ValueError("live_buffer_shift must be >= 1 (closed-bar only)")
    if (out["horizon_bars"] < 1).any():
        raise ValueError("horizon_bars must be >= 1")
    # Repeated slot_id is legal: one logical slot can expose multiple timeframe mappings.
    return out


def _read_bridge_manifest(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    if set(df.columns) != {"key", "value"}:
        raise ValueError("bridge_manifest.csv must contain exactly key,value columns")
    return {str(r.key): str(r.value) for r in df.itertuples(index=False)}


def validate_mt5_export(export_dir: str | Path, slot_registry: str | Path | None = None, *, production_mode: bool = False) -> Mt5ExportValidation:
    root = Path(export_dir)
    manifest = _read_bridge_manifest(root / "bridge_manifest.csv")
    if manifest:
        if manifest.get("slot_count_limit") not in {None, "", "NONE"}:
            raise ValueError(f"MT5 bridge manifest declares a slot-count limit: {manifest.get('slot_count_limit')}")
        if manifest.get("bootstrap_status") == "FAILED":
            raise ValueError("MT5 bridge bootstrap failed; export is not admissible GST evidence")
        if int(manifest.get("provider_construction_failures", "0") or 0) > 0:
            raise ValueError("MT5 bridge had provider construction failures")
        if int(manifest.get("bootstrap_failed_provider_count", "0") or 0) > 0:
            raise ValueError("MT5 bridge had provider bootstrap failures")
        bridge_mode = str(manifest.get("bridge_mode", "")).strip()
        live_refresh = str(manifest.get("live_market_data_refresh", "")).strip()
        if production_mode and bridge_mode != "0":
            raise ValueError("PRODUCTION requires a frozen GST_BOOTSTRAP_ONLY MT5 export; live signal polling does not refresh bars/ticks")
        if production_mode and live_refresh not in {"", "NONE_SIGNAL_POLL_ONLY"}:
            raise ValueError(f"unsupported MT5 live market-data manifest state: {live_refresh}")
    sig_path = root / "signals.csv"
    bars_path = root / "bars.csv"
    ticks_path = root / "ticks.csv"
    for p in (sig_path, bars_path, ticks_path):
        if not p.exists():
            raise FileNotFoundError(f"required MT5 bridge export is missing: {p}")

    sig = pd.read_csv(sig_path)
    bars = pd.read_csv(bars_path)
    ticks = pd.read_csv(ticks_path)
    _require_columns(sig, SIGNAL_COLUMNS, "signals.csv")
    _require_columns(bars, BAR_COLUMNS, "bars.csv")
    _require_columns(ticks, TICK_COLUMNS, "ticks.csv")

    signal_tfs = {str(x).upper() for x in sig["timeframe"]}
    bad_tfs = sorted(signal_tfs - set(CANONICAL_TIMEFRAMES))
    if bad_tfs:
        raise ValueError(f"signals.csv contains unsupported timeframe(s): {bad_tfs}; allowed: {list(CANONICAL_TIMEFRAMES)}")

    warnings: list[str] = []
    if manifest and str(manifest.get("bridge_mode", "")).strip() in {"1", "2"}:
        warnings.append("live bridge modes append signals without refreshing historical bars/ticks; freeze a fresh BOOTSTRAP_ONLY export before production analysis")
    if "source_channel" not in sig.columns:
        warnings.append(
            "signals.csv has no source_channel; direction/buffer reconciliation is UNVERIFIED. "
            "Use GST_MT5_Bridge v0.4+ for mandatory buffer-level mapping audit."
        )
    else:
        allowed_channels={"BUY_BUFFER","SELL_BUFFER","DIRECTION_BUFFER"}
        bad=sorted(set(sig["source_channel"].astype(str).str.upper())-allowed_channels)
        if bad:
            raise ValueError(f"signals.csv contains invalid source_channel values: {bad[:10]}")
        direction=sig["direction"].astype(str).str.upper()
        channel=sig["source_channel"].astype(str).str.upper()
        if ((channel.eq("BUY_BUFFER") & ~direction.eq("BUY")) | (channel.eq("SELL_BUFFER") & ~direction.eq("SELL"))).any():
            raise ValueError("signals.csv source_channel/direction mapping mismatch")
    if "provider_hash" not in sig.columns:
        warnings.append("signals.csv has no provider_hash; negative-offset production causality cannot be proven")
    elif sig["provider_hash"].astype(str).str.strip().eq("").any():
        raise ValueError("signals.csv contains empty provider_hash")
    if sig.empty:
        warnings.append("signals.csv contains zero frozen source events")
    if sig["signal_id"].astype(str).duplicated().any():
        dup = sig.loc[sig["signal_id"].astype(str).duplicated(), "signal_id"].astype(str).head(5).tolist()
        raise ValueError(f"signals.csv contains duplicate signal_id values, examples={dup}")

    for label, df, col in (("signals.csv", sig, "signal_time"), ("bars.csv", bars, "open_time"), ("ticks.csv", ticks, "timestamp")):
        parsed = pd.to_datetime(df[col], utc=True, errors="coerce")
        if parsed.isna().any():
            raise ValueError(f"{label} contains invalid/non-UTC-parsable {col} values")

    signal_symbols = set(sig["symbol"].astype(str))
    missing_bar_symbols = signal_symbols - set(bars["symbol"].astype(str))
    missing_tick_symbols = signal_symbols - set(ticks["symbol"].astype(str))
    if missing_bar_symbols:
        raise ValueError(f"bars.csv missing symbols required by signals: {sorted(missing_bar_symbols)}")
    if missing_tick_symbols:
        raise ValueError(f"ticks.csv missing symbols required by signals: {sorted(missing_tick_symbols)}")

    signal_pairs = set(zip(sig["symbol"].astype(str), sig["timeframe"].astype(str)))
    bar_pairs = set(zip(bars["symbol"].astype(str), bars["timeframe"].astype(str)))
    missing_pairs = signal_pairs - bar_pairs
    if missing_pairs:
        raise ValueError(f"bars.csv missing symbol/timeframe series required by signals: {sorted(missing_pairs)}")

    registry_rows: int | None = None
    registry_slots: int | None = None
    if slot_registry is not None:
        reg = load_slot_registry(slot_registry)
        registry_rows = len(reg)
        registry_slots = int(reg["slot_id"].astype(str).nunique()) if len(reg) else 0
        exported_slots = set(sig["slot_id"].astype(str))
        registered_slots = set(reg["slot_id"].astype(str))
        unregistered = sorted(exported_slots - registered_slots)
        if unregistered:
            raise ValueError(
                "export contains slot ids not enabled in supplied registry: "
                f"{unregistered[:20]}"
            )
        registered_without_signal = sorted(registered_slots - exported_slots)
        if registered_without_signal:
            warnings.append(
                "enabled registry slot ids with no frozen events in this export: "
                f"{registered_without_signal[:20]}"
            )
        if "provider_hash" in sig.columns and not sig.empty:
            reg_keys={(str(r.slot_id),str(r.signal_timeframe).upper()):str(r.provider_hash) for r in reg.itertuples(index=False)}
            bad_hash=[]
            for r in sig.itertuples(index=False):
                key=(str(r.slot_id),str(r.timeframe).upper())
                expected=reg_keys.get(key)
                if expected is not None and str(getattr(r,"provider_hash",'')) != expected:
                    bad_hash.append((key,str(getattr(r,"provider_hash",'')),expected))
            if bad_hash:
                raise ValueError(f"signals.csv provider_hash mismatch vs registry, examples={bad_hash[:5]}")

    return Mt5ExportValidation(
        export_dir=str(root),
        signal_rows=int(len(sig)),
        distinct_slots=int(sig["slot_id"].astype(str).nunique()),
        distinct_symbols=int(sig["symbol"].astype(str).nunique()),
        distinct_timeframes=int(sig["timeframe"].astype(str).nunique()),
        bar_rows=int(len(bars)),
        tick_rows=int(len(ticks)),
        registry_rows=registry_rows,
        registry_distinct_slots=registry_slots,
        slot_count_limit="NONE",
        warnings=warnings,
    )


def write_validation_json(validation: Mt5ExportValidation, path: str | Path) -> None:
    Path(path).write_text(json.dumps(asdict(validation), ensure_ascii=False, indent=2), encoding="utf-8")


def _safe_id(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.|:+-]+", "_", value)


def generate_matched_control_signals(
    *,
    signals_csv: str | Path,
    bars_csv: str | Path,
    output_csv: str | Path,
    random_seed: int = 12345,
    controls_per_signal: int = 1,
    min_separation_bars: int = 8,
) -> str:
    """Generate deterministic matched market/noise controls from exported bars.

    Controls preserve Slot × AssetGroup × Symbol × Timeframe × Direction. They only
    replace the source signal timestamp with a market timestamp sufficiently far
    from a real source event in the same symbol/timeframe series.

    This is a control constructor, not a signal generator. It must never be mixed
    into the production source-signal ledger.
    """
    if controls_per_signal < 1:
        raise ValueError("controls_per_signal must be >= 1")
    if min_separation_bars < 0:
        raise ValueError("min_separation_bars must be >= 0")

    seeds = load_signal_seeds(str(signals_csv))
    bars = load_bars(str(bars_csv))
    rng = random.Random(int(random_seed))
    groups = {
        key: g.sort_values("open_time").reset_index(drop=True)
        for key, g in bars.groupby(["symbol", "timeframe"], sort=False)
    }
    source_times: dict[tuple[str, str], list[pd.Timestamp]] = {}
    for s in seeds:
        source_times.setdefault((s.symbol, s.timeframe), []).append(pd.Timestamp(s.signal_time))

    rows: list[dict] = []
    for ordinal, s in enumerate(seeds):
        key = (s.symbol, s.timeframe)
        g = groups.get(key)
        if g is None or len(g) < 4:
            continue
        opens = pd.to_datetime(g["open_time"], utc=True)
        if len(opens) > 1:
            diffs = opens.diff().dropna().dt.total_seconds()
            bar_seconds = float(diffs.median()) if not diffs.empty else 3600.0
        else:
            bar_seconds = 3600.0
        separation_seconds = max(0.0, float(min_separation_bars) * bar_seconds)
        real_times = source_times.get(key, [])

        # Last bar has no known next-open/decision boundary; keep one-bar margin.
        candidates = list(range(1, len(g) - 1))
        rng.shuffle(candidates)
        used: set[int] = set()
        made = 0
        for idx in candidates:
            if idx in used:
                continue
            # Decision at this bar open gives offset provider a baseline entry at/after it.
            decision = opens.iloc[idx]
            if any(abs((decision - rt).total_seconds()) < separation_seconds for rt in real_times):
                continue
            used.add(idx)
            rows.append({
                "signal_id": _safe_id(f"CTRL|{s.signal_id}|{made+1}"),
                "slot_id": s.slot_id,
                "asset_group": s.asset_group,
                "symbol": s.symbol,
                "timeframe": s.timeframe,
                "direction": s.direction.value,
                "signal_time": decision.isoformat().replace("+00:00", "Z"),
                "control_source_signal_id": s.signal_id,
                "control_method": "MATCHED_RANDOM_BAR",
                "control_ordinal": made + 1,
            })
            made += 1
            if made >= controls_per_signal:
                break
        if made < controls_per_signal:
            raise ValueError(
                f"insufficient independent control timestamps for {s.signal_id}: "
                f"needed={controls_per_signal}, built={made}"
            )

    out = Path(output_csv)
    out.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out, index=False)
    return str(out)

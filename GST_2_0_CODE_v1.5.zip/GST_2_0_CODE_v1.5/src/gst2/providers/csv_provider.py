from __future__ import annotations

import math
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from gst2.domain.models import Direction, SignalSeed


def _utc(v) -> datetime:
    ts = pd.Timestamp(v)
    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")
    else:
        ts = ts.tz_convert("UTC")
    return ts.to_pydatetime()


def load_signal_seeds(path: str) -> list[SignalSeed]:
    df = pd.read_csv(path)
    required = {"slot_id", "asset_group", "symbol", "timeframe", "direction", "signal_time"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"signals CSV missing columns: {sorted(missing)}")
    id_col = "signal_id" if "signal_id" in df.columns else "episode_id" if "episode_id" in df.columns else None
    if not id_col:
        raise ValueError("signals CSV requires signal_id or episode_id")
    seen: set[str] = set()
    out = []
    for row in df.to_dict(orient="records"):
        sid = str(row[id_col])
        if sid in seen:
            raise ValueError(f"duplicate signal_id: {sid}")
        seen.add(sid)
        known = required | {id_col, "provider_version", "provider_hash", "source_channel", "offset_semantics_id"}
        md = {k: v for k, v in row.items() if k not in known and not (isinstance(v, float) and math.isnan(v))}
        out.append(SignalSeed(
            signal_id=sid,
            slot_id=str(row["slot_id"]),
            asset_group=str(row["asset_group"]).upper(),
            symbol=str(row["symbol"]),
            timeframe=str(row["timeframe"]).upper(),
            direction=Direction(str(row["direction"]).upper()),
            signal_time=_utc(row["signal_time"]),
            provider_version=str(row.get("provider_version", "")),
            provider_hash=str(row.get("provider_hash", "")),
            source_channel=str(row.get("source_channel", "")),
            offset_semantics_id=str(row.get("offset_semantics_id", "canonical_earlier_negative_later_positive_v1")),
            metadata=md,
        ))
    return out


def load_ticks(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {"symbol", "timestamp", "bid", "ask"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"ticks CSV missing columns: {sorted(missing)}")
    df = df.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    df["bid"] = pd.to_numeric(df["bid"], errors="raise")
    df["ask"] = pd.to_numeric(df["ask"], errors="raise")
    bad = df["ask"] < df["bid"]
    if bad.any():
        raise ValueError("ticks contain ask < bid")
    return df.sort_values(["symbol", "timestamp"]).reset_index(drop=True)


def load_bars(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {"symbol", "timeframe", "open_time", "open", "high", "low", "close"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"bars CSV missing columns: {sorted(missing)}")
    df = df.copy()
    df["open_time"] = pd.to_datetime(df["open_time"], utc=True)
    for c in ["open", "high", "low", "close"]:
        df[c] = pd.to_numeric(df[c], errors="raise")
    return df.sort_values(["symbol", "timeframe", "open_time"]).reset_index(drop=True)


def load_instrument_specs(path: str | None, *, strict: bool = False):
    from gst2.domain.models import InstrumentSpec
    if not path:
        return {}
    df = pd.read_csv(path)
    base_required = {"symbol", "tick_size"}
    production_required = {
        "symbol", "tick_size", "stops_level_price", "freeze_level_price", "slippage_price",
        "commission_per_order_account", "swap_per_order_account",
        "swap_long_per_day_account", "swap_short_per_day_account", "rollover_hour_utc", "triple_swap_weekday",
        "value_per_price_unit_per_unit", "order_units", "account_currency", "spec_id",
    }
    required = production_required if strict else base_required
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"instrument specs CSV missing columns: {sorted(missing)}")
    if df["symbol"].astype(str).duplicated().any():
        dup=sorted(df.loc[df["symbol"].astype(str).duplicated(keep=False),"symbol"].astype(str).unique())
        raise ValueError(f"instrument specs contain duplicate symbols: {dup}")
    out = {}
    for r in df.to_dict(orient="records"):
        def f(name, default=0.0):
            v=r.get(name, default)
            if pd.isna(v):
                if strict and name in production_required:
                    raise ValueError(f"instrument spec {r.get('symbol')}: {name} is missing")
                return default
            x=float(v)
            if not math.isfinite(x):
                raise ValueError(f"instrument spec {r.get('symbol')}: {name} must be finite")
            return x
        valpp = r.get("value_per_price_unit_per_unit")
        units = r.get("order_units")
        if strict and (pd.isna(valpp) or pd.isna(units)):
            raise ValueError(f"instrument spec {r.get('symbol')}: account-economics values are required in PRODUCTION")
        account_currency=str(r.get("account_currency", "") or "").strip()
        spec_id=str(r.get("spec_id", "") or "").strip()
        if strict and (not account_currency or not spec_id):
            raise ValueError(f"instrument spec {r.get('symbol')}: account_currency and spec_id are required in PRODUCTION")
        out[str(r["symbol"])] = InstrumentSpec(
            symbol=str(r["symbol"]), tick_size=f("tick_size"), stops_level_price=f("stops_level_price"),
            freeze_level_price=f("freeze_level_price"), slippage_price=f("slippage_price"),
            commission_per_order_account=f("commission_per_order_account"),
            swap_per_order_account=f("swap_per_order_account"),
            swap_long_per_day_account=f("swap_long_per_day_account"),
            swap_short_per_day_account=f("swap_short_per_day_account"),
            rollover_hour_utc=int(f("rollover_hour_utc",0)),
            triple_swap_weekday=int(f("triple_swap_weekday",2)),
            value_per_price_unit_per_unit=None if pd.isna(valpp) else float(valpp),
            order_units=None if pd.isna(units) else float(units),
            account_currency=account_currency, spec_id=spec_id,
        )
    return out

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

import pandas as pd

from gst2.causality.validator import NegativeOffsetCausalityValidator
from gst2.domain.models import MarketPoint, OffsetScenario, RawEpisode, SignalSeed
from gst2.replay.pricing import entry_price


@dataclass(slots=True)
class OffsetBuildDiagnostic:
    signal_id: str
    slot_id: str
    asset_group: str
    symbol: str
    timeframe: str
    offset: int
    status: str
    reason: str
    entry_bar_time: datetime | None = None
    candidate_entry_time: datetime | None = None
    causality_status: str = ""
    production_eligible: bool = False


@dataclass(slots=True)
class OffsetBuildResult:
    episodes: list[RawEpisode]
    diagnostics: list[OffsetBuildDiagnostic]


def _utc(v) -> datetime:
    ts = pd.Timestamp(v)
    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")
    else:
        ts = ts.tz_convert("UTC")
    return ts.to_pydatetime()


def build_offset_episodes(
    seeds: list[SignalSeed], bars: pd.DataFrame, ticks: pd.DataFrame, offset: int,
    horizon_bars: int | dict[str, int], causality: NegativeOffsetCausalityValidator,
    *, window_start: datetime | None = None, window_end_exclusive: datetime | None = None,
    require_complete_horizon: bool = True,
) -> OffsetBuildResult:
    """Build frozen episodes with canonical offset semantics.

    offset < 0 is earlier, offset 0 is source-time entry, offset > 0 is later.
    Temporal windows are hard information barriers. Episodes whose entry or full
    observation horizon crosses a train/test/holdout boundary are excluded.
    """
    if offset < -5 or offset > 5:
        raise ValueError("canonical offset range is -5..+5")
    bar_groups = {(s, tf): g.reset_index(drop=True) for (s, tf), g in bars.groupby(["symbol", "timeframe"], sort=False)}
    tick_groups = {s: g.reset_index(drop=True) for s, g in ticks.groupby("symbol", sort=False)}
    episodes: list[RawEpisode] = []
    diagnostics: list[OffsetBuildDiagnostic] = []

    for seed in seeds:
        g = bar_groups.get((seed.symbol, seed.timeframe)); tg = tick_groups.get(seed.symbol)
        if g is None or g.empty or tg is None or tg.empty:
            diagnostics.append(OffsetBuildDiagnostic(seed.signal_id, seed.slot_id, seed.asset_group, seed.symbol, seed.timeframe, offset, "SKIPPED", "missing bars/ticks")); continue
        sig = pd.Timestamp(seed.signal_time)
        candidates = g.index[g["open_time"] >= sig]
        if len(candidates) == 0:
            diagnostics.append(OffsetBuildDiagnostic(seed.signal_id, seed.slot_id, seed.asset_group, seed.symbol, seed.timeframe, offset, "SKIPPED", "signal after bar history")); continue
        base_idx = int(candidates[0]); idx = base_idx + offset
        if idx < 0 or idx >= len(g):
            diagnostics.append(OffsetBuildDiagnostic(seed.signal_id, seed.slot_id, seed.asset_group, seed.symbol, seed.timeframe, offset, "SKIPPED", "offset outside history")); continue
        entry_bar_time = _utc(g.loc[idx, "open_time"])
        if window_start is not None and entry_bar_time < window_start:
            diagnostics.append(OffsetBuildDiagnostic(seed.signal_id, seed.slot_id, seed.asset_group, seed.symbol, seed.timeframe, offset, "SKIPPED", "entry before split window", entry_bar_time)); continue
        if window_end_exclusive is not None and entry_bar_time >= window_end_exclusive:
            diagnostics.append(OffsetBuildDiagnostic(seed.signal_id, seed.slot_id, seed.asset_group, seed.symbol, seed.timeframe, offset, "SKIPPED", "entry at/after split boundary", entry_bar_time)); continue

        hb = int(horizon_bars.get(seed.timeframe, horizon_bars.get("default", 0))) if isinstance(horizon_bars, dict) else int(horizon_bars)
        if hb < 1:
            diagnostics.append(OffsetBuildDiagnostic(seed.signal_id, seed.slot_id, seed.asset_group, seed.symbol, seed.timeframe, offset, "SKIPPED", "observation horizon not explicitly configured", entry_bar_time)); continue
        end_idx = idx + hb
        if end_idx >= len(g):
            diagnostics.append(OffsetBuildDiagnostic(seed.signal_id, seed.slot_id, seed.asset_group, seed.symbol, seed.timeframe, offset, "SKIPPED", "INCOMPLETE_DATA: full bar horizon unavailable", entry_bar_time)); continue
        horizon_exclusive = _utc(g.loc[end_idx, "open_time"])
        if window_end_exclusive is not None and horizon_exclusive > window_end_exclusive:
            diagnostics.append(OffsetBuildDiagnostic(seed.signal_id, seed.slot_id, seed.asset_group, seed.symbol, seed.timeframe, offset, "SKIPPED", "episode horizon crosses split boundary", entry_bar_time)); continue
        if require_complete_horizon and _utc(tg["timestamp"].max()) < horizon_exclusive:
            diagnostics.append(OffsetBuildDiagnostic(seed.signal_id, seed.slot_id, seed.asset_group, seed.symbol, seed.timeframe, offset, "SKIPPED", "INCOMPLETE_DATA: ticks do not cover full horizon", entry_bar_time)); continue

        path_df = tg[(tg["timestamp"] >= pd.Timestamp(entry_bar_time)) & (tg["timestamp"] < pd.Timestamp(horizon_exclusive))]
        if path_df.empty:
            diagnostics.append(OffsetBuildDiagnostic(seed.signal_id, seed.slot_id, seed.asset_group, seed.symbol, seed.timeframe, offset, "SKIPPED", "no ticks in horizon", entry_bar_time)); continue
        first = next(path_df.itertuples(index=False))
        first_pt = MarketPoint(_utc(first.timestamp), float(first.bid), float(first.ask))
        decision = causality.classify(seed, offset, first_pt.ts)
        data_cutoff = decision.latest_data_time or (seed.signal_time if offset >= 0 else first_pt.ts)
        if data_cutoff > first_pt.ts:
            decision = type(decision)(
                status=decision.status if not decision.production_eligible else decision.status,
                production_eligible=False, evidence_id=decision.evidence_id, evidence_hash=decision.evidence_hash,
                latest_data_time=data_cutoff, reasons=tuple(decision.reasons) + ("data cutoff after entry",),
            )
        scenario = OffsetScenario(
            signal_id=seed.signal_id, offset=offset, source_signal_time=seed.signal_time,
            entry_bar_time=entry_bar_time, candidate_entry_time=first_pt.ts,
            entry_price=entry_price(first_pt, seed.direction), data_cutoff_time=data_cutoff,
            causality_status=decision.status, production_eligible=decision.production_eligible,
            causality_evidence_id=decision.evidence_id, causality_evidence_hash=decision.evidence_hash,
        )
        path = tuple(MarketPoint(_utc(r.timestamp), float(r.bid), float(r.ask)) for r in path_df.itertuples(index=False))
        episodes.append(RawEpisode(
            episode_id=f"{seed.signal_id}|offset={offset:+d}", seed=seed, scenario=scenario,
            horizon_end=horizon_exclusive, path=path,
            metadata={"base_bar_index": base_idx, "entry_bar_index": idx, "horizon_exclusive": horizon_exclusive.isoformat()},
        ))
        diagnostics.append(OffsetBuildDiagnostic(
            seed.signal_id, seed.slot_id, seed.asset_group, seed.symbol, seed.timeframe, offset,
            "BUILT", "", entry_bar_time, first_pt.ts, decision.status.value, decision.production_eligible,
        ))
    return OffsetBuildResult(episodes, diagnostics)

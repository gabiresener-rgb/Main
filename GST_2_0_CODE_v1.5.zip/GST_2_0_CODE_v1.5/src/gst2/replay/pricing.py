from __future__ import annotations

import math

from gst2.domain.models import Direction, MarketPoint


def entry_price(point: MarketPoint, direction: Direction) -> float:
    return point.ask if direction is Direction.BUY else point.bid


def exit_price(point: MarketPoint, direction: Direction) -> float:
    return point.bid if direction is Direction.BUY else point.ask


def favorable_pct(entry: float, exit_px: float, direction: Direction) -> float:
    if entry <= 0:
        raise ValueError("entry must be > 0")
    raw = (exit_px - entry) / entry * 100.0
    return raw if direction is Direction.BUY else -raw


def level_price(entry: float, favorable_pct_points: float, direction: Direction) -> float:
    """Price level from percentage points; 0.40 means 0.40%, never 40%."""
    mult = 1.0 + favorable_pct_points / 100.0 if direction is Direction.BUY else 1.0 - favorable_pct_points / 100.0
    return entry * mult


def stop_price(entry: float, sl_pct: float, direction: Direction) -> float:
    return level_price(entry, -sl_pct, direction)


def target_price(entry: float, target_pct: float, direction: Direction) -> float:
    return level_price(entry, target_pct, direction)


def round_to_tick(price: float, tick_size: float | None, mode: str = "nearest") -> float:
    if not tick_size or tick_size <= 0:
        return float(price)
    q = price / tick_size
    if mode == "down":
        return math.floor(q + 1e-12) * tick_size
    if mode == "up":
        return math.ceil(q - 1e-12) * tick_size
    if mode != "nearest":
        raise ValueError(f"unsupported tick rounding mode: {mode}")
    return round(q) * tick_size


def executable_stop(entry: float, sl_pct: float, direction: Direction, tick_size: float) -> float:
    raw = stop_price(entry, sl_pct, direction)
    # Conservative/outward rounding: never silently reduce the requested initial risk.
    return round_to_tick(raw, tick_size, "down" if direction is Direction.BUY else "up")


def executable_target(entry: float, target_pct: float, direction: Direction, tick_size: float) -> float:
    raw = target_price(entry, target_pct, direction)
    # Conservative target rounding: do not claim a farther target than the configured raw level.
    return round_to_tick(raw, tick_size, "down" if direction is Direction.BUY else "up")


def effective_favorable_pct(entry: float, level: float, direction: Direction) -> float:
    return favorable_pct(entry, level, direction)


def stop_triggered(quote: float, stop_level: float, direction: Direction) -> bool:
    return quote <= stop_level + 1e-12 if direction is Direction.BUY else quote >= stop_level - 1e-12


def target_triggered(quote: float, target_level: float, direction: Direction) -> bool:
    return quote >= target_level - 1e-12 if direction is Direction.BUY else quote <= target_level + 1e-12


def apply_adverse_slippage(quote: float, direction: Direction, slippage_price: float) -> float:
    if slippage_price <= 0:
        return quote
    return quote - slippage_price if direction is Direction.BUY else quote + slippage_price

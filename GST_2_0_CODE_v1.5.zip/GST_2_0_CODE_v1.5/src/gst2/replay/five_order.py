from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

from gst2.domain.models import (
    ChildOrderResult, CloseReason, Direction, EpisodeEquityPoint, EpisodeStatus,
    InstrumentSpec, JointCandidate, OpenOrderMark, RawEpisode,
    SignalEpisodeResult, SignalOutcome, TradeEvent,
)
from gst2.replay.pricing import (
    apply_adverse_slippage, effective_favorable_pct, executable_stop,
    executable_target, exit_price, round_to_tick, stop_triggered, target_triggered,
)


class ExecutionModelError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class ExecutionPolicy:
    order_weights: tuple[float, float, float, float, float] = (1, 1, 1, 1, 1)
    modified_stop_profit_pct: float = 0.10
    cost_R_per_weight: float = 0.0  # RESEARCH fallback only
    fill_model: str = "FIRST_EXECUTABLE_QUOTE"
    require_instrument_specs: bool = False
    require_account_economics: bool = False
    default_tick_size: float = 0.00001
    instrument_specs: dict[str, InstrumentSpec] = field(default_factory=dict, compare=False, hash=False)

    def __post_init__(self) -> None:
        if len(self.order_weights) != 5 or any(w <= 0 for w in self.order_weights):
            raise ValueError("five positive order weights required")
        if self.modified_stop_profit_pct < 0:
            raise ValueError("modified stop profit pct must be >= 0")
        if self.cost_R_per_weight < 0:
            raise ValueError("cost_R_per_weight must be >= 0")
        if self.fill_model not in {"FIRST_EXECUTABLE_QUOTE", "IDEAL_LEVEL_FILL"}:
            raise ValueError("unsupported fill_model")
        if self.default_tick_size <= 0:
            raise ValueError("default_tick_size must be > 0")

    def spec_for(self, symbol: str) -> InstrumentSpec:
        spec = self.instrument_specs.get(symbol)
        if spec is not None:
            if self.require_account_economics and (
                spec.value_per_price_unit_per_unit is None
                or spec.order_units is None
                or spec.order_units <= 0
                or not spec.account_currency
            ):
                raise ExecutionModelError(f"incomplete account-economics instrument spec for {symbol}")
            return spec
        if self.require_instrument_specs:
            raise ExecutionModelError(f"missing instrument execution spec for {symbol}")
        if self.require_account_economics:
            raise ExecutionModelError(f"missing account-economics instrument spec for {symbol}")
        return InstrumentSpec(symbol=symbol, tick_size=self.default_tick_size, spec_id="RESEARCH_DEFAULT")


def validate_candidate_execution(candidate: JointCandidate, policy: ExecutionPolicy) -> None:
    # This is only a nominal pre-filter.  Replay performs the authoritative
    # executable-level check after tick normalization and against the market side.
    tp1_pct = candidate.sl_pct * candidate.rr_ladder[0]
    if policy.modified_stop_profit_pct > tp1_pct + 1e-12:
        raise ValueError(
            f"TP1 ({tp1_pct:.6g}%) is below BE+ profit stop ({policy.modified_stop_profit_pct:.6g}%); "
            "modified stop cannot be assumed executable at TP1"
        )


def _outcome_from_level(level: int) -> SignalOutcome:
    return [SignalOutcome.BAD, SignalOutcome.TP1, SignalOutcome.TP2, SignalOutcome.TP3, SignalOutcome.TP4, SignalOutcome.TP5][level]


def _modified_stop_level(entry: float, pct: float, direction: Direction, tick_size: float) -> float:
    raw = entry * (1 + direction.sign * pct / 100.0)
    # Conservative rounding toward entry / less profit.
    return round_to_tick(raw, tick_size, "down" if direction is Direction.BUY else "up")


def _can_place_modified_stop(current_exit_quote: float, stop: float, direction: Direction, spec: InstrumentSpec) -> bool:
    minimum = max(spec.stops_level_price, spec.freeze_level_price)
    if direction is Direction.BUY:
        return (current_exit_quote - stop) + 1e-12 >= minimum
    return (stop - current_exit_quote) + 1e-12 >= minimum


def _initial_level_distance(current_exit_quote: float, level: float, direction: Direction, *, stop: bool) -> float:
    """Broker placement distance from the quote side relevant to closing the position.

    BUY protective levels are measured from Bid; SELL protective levels from Ask.
    The same exit-side quote is used for target placement.  This is deliberately
    separate from |Entry-SL|, which defines economic R.
    """
    if direction is Direction.BUY:
        return (current_exit_quote - level) if stop else (level - current_exit_quote)
    return (level - current_exit_quote) if stop else (current_exit_quote - level)


def _rollover_adjustment_account(
    entry_time: datetime, close_time: datetime, direction: Direction, weight: float, spec: InstrumentSpec
) -> float:
    """Signed account-currency swap adjustment.

    New per-day fields are signed cash adjustments (negative=cost, positive=credit).
    If they are both zero, the legacy fixed positive cost field is used for
    backward-compatible RESEARCH runs.
    """
    if close_time <= entry_time:
        return 0.0
    daily = spec.swap_long_per_day_account if direction is Direction.BUY else spec.swap_short_per_day_account
    if abs(daily) <= 1e-15:
        return -spec.swap_per_order_account * weight

    start = entry_time.astimezone(timezone.utc) if entry_time.tzinfo else entry_time.replace(tzinfo=timezone.utc)
    end = close_time.astimezone(timezone.utc) if close_time.tzinfo else close_time.replace(tzinfo=timezone.utc)
    day = (start - timedelta(days=1)).date()
    last = (end + timedelta(days=1)).date()
    total = 0.0
    while day <= last:
        roll = datetime(day.year, day.month, day.day, int(spec.rollover_hour_utc), tzinfo=timezone.utc)
        if start < roll <= end:
            mult = 3.0 if roll.weekday() == int(spec.triple_swap_weekday) else 1.0
            total += daily * mult * weight
        day += timedelta(days=1)
    return total


def _account_values(
    entry: float, close: float, sl_distance: float, direction: Direction, weight: float,
    spec: InstrumentSpec, entry_time: datetime, close_time: datetime,
):
    if spec.value_per_price_unit_per_unit is None or spec.order_units is None:
        return None, None
    mult = spec.value_per_price_unit_per_unit * spec.order_units * weight
    initial_risk = sl_distance * mult
    gross = direction.sign * (close - entry) * mult
    commission = spec.commission_per_order_account * weight
    swap_adjustment = _rollover_adjustment_account(entry_time, close_time, direction, weight, spec)
    net = gross - commission + swap_adjustment
    return initial_risk, net


def _weighted_order_economics(
    *, entry: float, px: float, sl_distance: float, direction: Direction, weight: float,
    spec: InstrumentSpec, policy: ExecutionPolicy, entry_time: datetime, ts: datetime,
) -> tuple[float, float, float | None, float | None]:
    raw_r = direction.sign * (px - entry) / sl_distance
    fallback_cost = policy.cost_R_per_weight * weight
    initial_risk_account, net_pnl_account = _account_values(entry, px, sl_distance, direction, weight, spec, entry_time, ts)
    if initial_risk_account is not None and initial_risk_account > 0 and net_pnl_account is not None:
        weighted_net_r = net_pnl_account / (initial_risk_account / weight)
        cost_r = raw_r * weight - weighted_net_r
    else:
        cost_r = fallback_cost
        weighted_net_r = raw_r * weight - cost_r
    return raw_r * weight, cost_r, initial_risk_account, net_pnl_account if net_pnl_account is not None else None


def replay_episode(episode: RawEpisode, candidate: JointCandidate, policy: ExecutionPolicy = ExecutionPolicy()) -> SignalEpisodeResult:
    """Tick/Bid-Ask replay with executable levels and horizon mark-to-market.

    BAD is assigned only when the initial stop is actually triggered before TP1.
    UNRESOLVED_TIMEOUT is excluded from BAD/TP1..TP5 distribution but its open
    positions are marked at the last in-window executable quote and remain in
    financial expectancy/equity metrics.
    """
    validate_candidate_execution(candidate, policy)
    if not episode.path:
        raise ValueError(f"episode {episode.episode_id} has empty path")
    spec = policy.spec_for(episode.seed.symbol)
    entry_time = episode.scenario.candidate_entry_time
    entry = float(episode.entry_price)
    initial_quote = exit_price(episode.path[0], episode.direction)

    initial_sl = executable_stop(entry, candidate.sl_pct, episode.direction, spec.tick_size)
    sl_distance = abs(entry - initial_sl)
    if sl_distance <= 0:
        raise ExecutionModelError("effective SL distance is zero after tick normalization")
    if _initial_level_distance(initial_quote, initial_sl, episode.direction, stop=True) + 1e-12 < spec.stops_level_price:
        raise ExecutionModelError("initial SL violates broker stops level from current Bid/Ask side")
    effective_sl_pct = sl_distance / entry * 100.0

    tp_prices = tuple(
        executable_target(entry, (sl_distance * rr / entry) * 100.0, episode.direction, spec.tick_size)
        for rr in candidate.rr_ladder
    )
    eff_rr = tuple(episode.direction.sign * (p - entry) / sl_distance for p in tp_prices)
    eff_tp_pct = tuple(effective_favorable_pct(entry, p, episode.direction) for p in tp_prices)
    if episode.direction is Direction.BUY:
        collapsed = any(a >= b - 1e-12 for a, b in zip(tp_prices, tp_prices[1:]))
    else:
        collapsed = any(a <= b + 1e-12 for a, b in zip(tp_prices, tp_prices[1:]))
    if collapsed:
        raise ExecutionModelError("tick normalization collapsed/reordered TP ladder")
    if any(a >= b - 1e-12 for a, b in zip(eff_rr, eff_rr[1:])):
        raise ExecutionModelError("effective RR ladder is not strictly increasing")
    if _initial_level_distance(initial_quote, tp_prices[0], episode.direction, stop=False) + 1e-12 < spec.stops_level_price:
        raise ExecutionModelError("TP1 violates broker stops level from current Bid/Ask side")

    modified_stop = _modified_stop_level(entry, policy.modified_stop_profit_pct, episode.direction, spec.tick_size)
    modified_stop_r = episode.direction.sign * (modified_stop - entry) / sl_distance

    events: list[TradeEvent] = [TradeEvent("ENTRY", entry_time, entry)]
    equity_path: list[EpisodeEquityPoint] = []
    open_orders = {1, 2, 3, 4, 5}
    results: dict[int, ChildOrderResult] = {}
    highest_tp = 0
    mod_active = False
    mod_time: datetime | None = None
    active_sl = initial_sl
    execution_invalid_reason = ""
    total_initial_weight = float(sum(policy.order_weights))

    def close_order(idx: int, ts: datetime, px: float, reason: CloseReason) -> None:
        weight = policy.order_weights[idx - 1]
        gross_r, cost_r, initial_risk_account, net_pnl_account = _weighted_order_economics(
            entry=entry, px=px, sl_distance=sl_distance, direction=episode.direction, weight=weight,
            spec=spec, policy=policy, entry_time=entry_time, ts=ts,
        )
        net_r = gross_r - cost_r
        results[idx] = ChildOrderResult(
            order_index=idx, target_level=idx,
            target_R=candidate.rr_ladder[idx - 1], target_pct=candidate.tp_pct_ladder[idx - 1],
            effective_target_R=eff_rr[idx - 1], effective_target_pct=eff_tp_pct[idx - 1],
            target_price=tp_prices[idx - 1], entry_time=entry_time, entry_price=entry,
            direction=episode.direction, weight=weight, close_time=ts, close_price=px,
            close_reason=reason, gross_R=gross_r, cost_R=cost_r, net_R=net_r,
            initial_risk_account=initial_risk_account, net_pnl_account=net_pnl_account,
            initial_sl_price=initial_sl, active_sl_price_at_close=active_sl,
            instrument_spec_fingerprint=spec.fingerprint,
            stop_modified=mod_active and idx > 1, stop_modified_time=mod_time if idx > 1 else None,
            modified_stop_price=modified_stop if (mod_active and idx > 1) else None,
        )
        open_orders.discard(idx)
        events.append(TradeEvent(
            "ORDER_CLOSE", ts, px, order_index=idx, pnl_order_R=net_r / max(weight, 1e-15),
            pnl_pool_R=net_r / total_initial_weight,
            details={"reason": reason.value, "weight": weight},
        ))

    def current_equity(ts: datetime, quote: float) -> tuple[float, float | None]:
        total_weighted_r = 0.0
        account_parts: list[float] = []
        account_complete = True
        for idx in range(1, 6):
            if idx in results:
                total_weighted_r += results[idx].net_R
                if results[idx].net_pnl_account is None:
                    account_complete = False
                else:
                    account_parts.append(float(results[idx].net_pnl_account))
            else:
                weight = policy.order_weights[idx - 1]
                gross_r, cost_r, _risk_account, net_pnl_account = _weighted_order_economics(
                    entry=entry, px=quote, sl_distance=sl_distance, direction=episode.direction,
                    weight=weight, spec=spec, policy=policy, entry_time=entry_time, ts=ts,
                )
                total_weighted_r += gross_r - cost_r
                if net_pnl_account is None:
                    account_complete = False
                else:
                    account_parts.append(float(net_pnl_account))
        return total_weighted_r / total_initial_weight, (sum(account_parts) if account_complete else None)

    for point in episode.path:
        quote = exit_price(point, episode.direction)
        stop_level = active_sl
        if stop_triggered(quote, stop_level, episode.direction):
            fill = apply_adverse_slippage(quote, episode.direction, spec.slippage_price) if policy.fill_model == "FIRST_EXECUTABLE_QUOTE" else stop_level
            reason = CloseReason.MODIFIED_SL if mod_active else CloseReason.INITIAL_SL
            for idx in sorted(open_orders):
                close_order(idx, point.ts, fill, reason)
            events.append(TradeEvent(f"{reason.value}_HIT", point.ts, fill, details={"trigger_level": stop_level, "observed_quote": quote}))
        else:
            # Targets are limit-style exits; fill at the target, never at a better gap quote.
            for idx in range(1, 6):
                if idx not in open_orders:
                    continue
                if target_triggered(quote, tp_prices[idx - 1], episode.direction):
                    close_order(idx, point.ts, tp_prices[idx - 1], CloseReason.TARGET)
                    highest_tp = max(highest_tp, idx)
                    events.append(TradeEvent("TP_HIT", point.ts, tp_prices[idx - 1], order_index=idx, level=idx))
                    if idx == 1 and not mod_active:
                        if not _can_place_modified_stop(quote, modified_stop, episode.direction, spec):
                            execution_invalid_reason = "modified stop violates stops/freeze distance at TP1"
                            events.append(TradeEvent("STOP_MODIFICATION_REJECTED", point.ts, modified_stop, details={"quote": quote}))
                            break
                        mod_active = True
                        mod_time = point.ts
                        active_sl = modified_stop
                        events.append(TradeEvent("STOP_MODIFIED", point.ts, modified_stop, details={
                            "old_stop": initial_sl, "new_stop": modified_stop, "effective_new_stop_R": modified_stop_r,
                        }))
        eq_r, eq_account = current_equity(point.ts, quote)
        equity_path.append(EpisodeEquityPoint(point.ts, eq_r, eq_account))
        if execution_invalid_reason or not open_orders:
            break

    if execution_invalid_reason:
        completion = EpisodeStatus.EXECUTION_INVALID
        outcome = None
    elif not open_orders:
        completion = EpisodeStatus.COMPLETE
        outcome = _outcome_from_level(highest_tp)
    else:
        completion = EpisodeStatus.UNRESOLVED_TIMEOUT
        outcome = None
        events.append(TradeEvent("UNRESOLVED_HORIZON", episode.path[-1].ts, exit_price(episode.path[-1], episode.direction)))

    valuation_pt = episode.path[-1] if open_orders else next(
        (pt for pt in reversed(episode.path) if not equity_path or pt.ts <= equity_path[-1].ts), episode.path[-1]
    )
    valuation_time = equity_path[-1].ts if equity_path else valuation_pt.ts
    valuation_price = exit_price(valuation_pt, episode.direction)

    ordered = [results[i] for i in sorted(results)]
    open_marks: list[OpenOrderMark] = []
    for idx in sorted(open_orders):
        weight = policy.order_weights[idx - 1]
        gross_r, cost_r, initial_risk_account, net_pnl_account = _weighted_order_economics(
            entry=entry, px=valuation_price, sl_distance=sl_distance, direction=episode.direction,
            weight=weight, spec=spec, policy=policy, entry_time=entry_time, ts=valuation_time,
        )
        open_marks.append(OpenOrderMark(
            order_index=idx, target_level=idx,
            target_R=candidate.rr_ladder[idx - 1], target_pct=candidate.tp_pct_ladder[idx - 1],
            effective_target_R=eff_rr[idx - 1], effective_target_pct=eff_tp_pct[idx - 1],
            target_price=tp_prices[idx - 1], weight=weight, mark_time=valuation_time, mark_price=valuation_price,
            gross_R=gross_r, estimated_cost_R=cost_r, net_R_if_closed=gross_r-cost_r,
            initial_risk_account=initial_risk_account, net_pnl_account_if_closed=net_pnl_account,
            active_sl_price=active_sl, stop_modified=mod_active and idx > 1,
            modified_stop_price=modified_stop if (mod_active and idx > 1) else None,
        ))

    realized_sum = sum(x.net_R for x in ordered)
    unrealized_sum = sum(x.net_R_if_closed for x in open_marks)
    order_r_sum = realized_sum + unrealized_sum
    realized_pool_r = realized_sum / total_initial_weight
    unrealized_pool_r = unrealized_sum / total_initial_weight
    pool_r = order_r_sum / total_initial_weight
    cost_r = (sum(x.cost_R for x in ordered) + sum(x.estimated_cost_R for x in open_marks)) / total_initial_weight

    realized_account_vals = [x.net_pnl_account for x in ordered]
    open_account_vals = [x.net_pnl_account_if_closed for x in open_marks]
    realized_account = sum(float(x) for x in realized_account_vals) if all(x is not None for x in realized_account_vals) else (0.0 if not realized_account_vals else None)
    unrealized_account = sum(float(x) for x in open_account_vals) if all(x is not None for x in open_account_vals) else (0.0 if not open_account_vals else None)
    account_total = (realized_account + unrealized_account) if realized_account is not None and unrealized_account is not None else None

    # Cost estimates at immediate entry are exported for deterministic reconstruction;
    # time-dependent swap is represented by equity_path/open marks instead.
    estimated_costs=[]
    for idx in range(1,6):
        w=policy.order_weights[idx-1]
        gross0,cost0,_,_=_weighted_order_economics(
            entry=entry,px=entry,sl_distance=sl_distance,direction=episode.direction,weight=w,
            spec=spec,policy=policy,entry_time=entry_time,ts=entry_time,
        )
        estimated_costs.append(cost0)

    residual_open_weight = sum(policy.order_weights[i-1] for i in open_orders)
    giveback_to_stop = max(0.0, episode.direction.sign * (valuation_price - active_sl) / sl_distance)
    residual_risk_r = giveback_to_stop * residual_open_weight / total_initial_weight
    mod_count = sum(1 for x in ordered if x.close_reason is CloseReason.MODIFIED_SL)

    # Ensure the terminal equity point exactly matches the exported economic pool-R.
    if equity_path and completion is not EpisodeStatus.EXECUTION_INVALID:
        equity_path[-1] = EpisodeEquityPoint(equity_path[-1].ts, pool_r, account_total)

    return SignalEpisodeResult(
        episode_id=episode.episode_id, signal_id=episode.seed.signal_id, slot_id=episode.seed.slot_id,
        asset_group=episode.seed.asset_group, symbol=episode.seed.symbol, timeframe=episode.seed.timeframe,
        direction=episode.seed.direction, offset=candidate.offset, source_signal_time=episode.seed.signal_time,
        candidate_entry_time=entry_time, data_cutoff_time=episode.scenario.data_cutoff_time,
        causality_status=episode.scenario.causality_status, production_eligible=episode.scenario.production_eligible,
        completion_status=completion, exclusion_reason=execution_invalid_reason, entry_price=entry,
        sl_pct=candidate.sl_pct, effective_sl_pct=effective_sl_pct, initial_sl_price=initial_sl,
        rr_ladder=candidate.rr_ladder, effective_rr_ladder=eff_rr,
        tp_pct_ladder=candidate.tp_pct_ladder, effective_tp_pct_ladder=eff_tp_pct,
        tp_price_ladder=tp_prices, outcome=outcome, orders=ordered, open_orders=open_marks, events=events,
        equity_path=equity_path, order_weights=policy.order_weights,
        estimated_exit_cost_R_by_order=tuple(float(x) for x in estimated_costs),
        instrument_tick_size=spec.tick_size, instrument_spec_fingerprint=spec.fingerprint,
        valuation_time=valuation_time, valuation_price=valuation_price,
        pool_realized_order_R_sum=realized_sum, pool_unrealized_order_R_sum=unrealized_sum,
        pool_order_R_sum=order_r_sum, pool_realized_R=realized_pool_r,
        pool_unrealized_R=unrealized_pool_r, pool_R=pool_r, pool_cost_R=cost_r,
        pool_realized_pnl_account=realized_account, pool_unrealized_pnl_account=unrealized_account,
        pool_net_pnl_account=account_total, residual_open_weight=residual_open_weight,
        residual_risk_R=residual_risk_r, modified_stop_close_count=mod_count,
    )


# Bulk profile API is retained for research-only diagnostics. Production search
# uses exact replay for candidate selection to avoid execution-model drift.
@dataclass(frozen=True, slots=True)
class PathProfile:
    signal_id: str
    symbol: str
    entry_time: datetime
    tp1_reached: bool
    bad_initial_sl: bool
    max_R_after_tp1: float
    common_exit_R: float
    common_exit_reason: CloseReason
    modified_stop_close_possible: bool


def build_path_profile(episode: RawEpisode, sl_pct: float, rr1: float, modified_stop_profit_pct: float = 0.10) -> PathProfile:
    candidate = JointCandidate(episode.scenario.offset, sl_pct, (rr1, rr1+1, rr1+2, rr1+3, rr1+4))
    entry = episode.entry_price
    tp1_pct = sl_pct * rr1
    tp1 = False
    maxr = float("-inf")
    last_r = 0.0
    from gst2.replay.pricing import favorable_pct
    for p in episode.path:
        q = exit_price(p, episode.direction)
        m = favorable_pct(entry, q, episode.direction)
        last_r = m / sl_pct
        if not tp1:
            if m <= -sl_pct:
                return PathProfile(episode.seed.signal_id, episode.seed.symbol, episode.scenario.candidate_entry_time, False, True, maxr, last_r, CloseReason.INITIAL_SL, False)
            if m >= tp1_pct:
                tp1 = True; maxr = max(maxr, last_r)
        else:
            maxr = max(maxr, last_r)
            if m <= modified_stop_profit_pct:
                return PathProfile(episode.seed.signal_id, episode.seed.symbol, episode.scenario.candidate_entry_time, True, False, maxr, last_r, CloseReason.MODIFIED_SL, True)
    return PathProfile(episode.seed.signal_id, episode.seed.symbol, episode.scenario.candidate_entry_time, tp1, False, maxr, last_r, CloseReason.HORIZON, False)

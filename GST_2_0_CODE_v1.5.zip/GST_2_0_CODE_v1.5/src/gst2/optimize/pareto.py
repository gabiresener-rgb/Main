from __future__ import annotations

from gst2.domain.models import CandidateMetrics


def dominates(a: CandidateMetrics, b: CandidateMetrics) -> bool:
    """Canonical multi-objective dominance without an arbitrary composite score."""
    no_worse = (
        a.pool_expectancy_R_per_episode >= b.pool_expectancy_R_per_episode - 1e-12
        and a.equal_symbol_expectancy_R >= b.equal_symbol_expectancy_R - 1e-12
        and a.pool_max_drawdown_R <= b.pool_max_drawdown_R + 1e-12
        and a.high_tp_share_pct >= b.high_tp_share_pct - 1e-12
        and a.sl_pct <= b.sl_pct + 1e-12
    )
    strictly = (
        a.pool_expectancy_R_per_episode > b.pool_expectancy_R_per_episode + 1e-12
        or a.equal_symbol_expectancy_R > b.equal_symbol_expectancy_R + 1e-12
        or a.pool_max_drawdown_R < b.pool_max_drawdown_R - 1e-12
        or a.high_tp_share_pct > b.high_tp_share_pct + 1e-12
        or a.sl_pct < b.sl_pct - 1e-12
    )
    return no_worse and strictly


def pareto_front(rows: list[CandidateMetrics]) -> list[CandidateMetrics]:
    front = []
    for i, r in enumerate(rows):
        if not any(i != j and dominates(other, r) for j, other in enumerate(rows)):
            r.pareto_efficient = True
            front.append(r)
    return front

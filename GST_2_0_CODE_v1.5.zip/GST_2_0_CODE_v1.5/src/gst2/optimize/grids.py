from __future__ import annotations

from itertools import combinations, product
from math import comb


def float_grid(minimum: float, maximum: float, step: float) -> list[float]:
    if step <= 0 or maximum < minimum:
        raise ValueError("invalid grid")
    vals = []
    x = minimum
    while x < maximum - step * 1e-8:
        vals.append(round(x, 10)); x += step
    # Endpoint is always explicit even when step does not land on it.
    vals.append(round(maximum, 10))
    vals = sorted(set(vals))
    if abs(vals[0] - minimum) > 1e-9 or abs(vals[-1] - maximum) > 1e-9:
        raise AssertionError("grid endpoints not preserved")
    return vals


def adaptive_rr_grid(minimum: float, maximum: float, requested_step: float, *, target_count: int = 5, max_ladders: int = 5000) -> tuple[list[float], float]:
    step = requested_step
    while True:
        grid = float_grid(minimum, maximum, step)
        if len(grid) < target_count:
            raise ValueError("RR bounds cannot form five targets")
        if comb(len(grid), target_count) <= max_ladders:
            return grid, step
        step = round(step + requested_step, 10)


def legal_ladders(grid: list[float], min_separation: float) -> list[tuple[float, float, float, float, float]]:
    return [tuple(float(x) for x in c) for c in combinations(grid, 5) if all((b-a)+1e-12 >= min_separation for a,b in zip(c,c[1:]))]


def local_ladder_neighbors(seed: tuple[float, ...], step: float, minimum: float, maximum: float, min_separation: float) -> list[tuple[float, float, float, float, float]]:
    values=[]
    for x in seed:
        opts=sorted(set(round(y,10) for y in (x-step,x,x+step) if minimum-1e-12<=y<=maximum+1e-12)); values.append(opts)
    out=set()
    for c in product(*values):
        if len(c)==5 and all(a+min_separation<=b+1e-12 for a,b in zip(c,c[1:])): out.add(tuple(float(x) for x in c))
    return sorted(out)

from __future__ import annotations

from dataclasses import dataclass, field, replace

from gst2.config import SearchSettings
from gst2.domain.models import CandidateMetrics, JointCandidate, RawEpisode
from gst2.metrics.core import summarize_replayed
from gst2.metrics.equivalence import paired_equal_symbol_difference_ci, ci_within_practical_equivalence
from gst2.optimize.grids import adaptive_rr_grid, float_grid, legal_ladders
from gst2.optimize.pareto import pareto_front
from gst2.optimize.robustness import mark_local_robustness
from gst2.replay.five_order import ExecutionModelError, ExecutionPolicy, replay_episode


@dataclass(slots=True)
class JointSearchResult:
    offset: int
    effective_coarse_rr_step: float
    rows: list[CandidateMetrics]
    best_research: CandidateMetrics | None
    best_production: CandidateMetrics | None
    pareto: list[CandidateMetrics] = field(default_factory=list)
    boundary_status: str = "SEARCH_BOUNDS_OK"
    boundary_hit_dimensions: tuple[str, ...] = ()
    boundary_expansion_rounds: int = 0
    boundary_history: list[dict] = field(default_factory=list)
    search_bounds: dict[str, float] = field(default_factory=dict)
    sample_status: str = "SUFFICIENT"


def _candidate_sort_key(r: CandidateMetrics):
    # Equal-symbol economics is primary; pooled results are secondary diagnostics.
    return (
        r.equal_symbol_expectancy_R,
        r.positive_symbol_share,
        r.pool_expectancy_R_per_episode,
        -r.pool_max_drawdown_R,
        r.high_tp_share_pct,
        -r.sl_pct,
    )


def _select(rows: list[CandidateMetrics], *, production_only: bool, min_positive_symbol_share: float = 0.60, equivalence_abs_R: float = 0.0) -> CandidateMetrics | None:
    pool = [r for r in rows if (r.production_eligible or not production_only)]
    if production_only:
        pool = [r for r in pool if r.robust and r.pareto_efficient and r.equal_symbol_expectancy_R > 0 and r.positive_symbol_share >= min_positive_symbol_share]
    if not pool:
        return None
    best = max(pool, key=_candidate_sort_key)
    if equivalence_abs_R > 0:
        near = [r for r in pool if best.equal_symbol_expectancy_R - r.equal_symbol_expectancy_R <= equivalence_abs_R + 1e-12 and r.pool_max_drawdown_R <= best.pool_max_drawdown_R * 1.05 + 1e-12]
        if near:
            best = min(near, key=lambda r: (r.sl_pct, -r.equal_symbol_expectancy_R, r.pool_max_drawdown_R))
    return best


def _evaluate_candidate(
    episodes: list[RawEpisode], candidate: JointCandidate, policy: ExecutionPolicy, stage: str, min_episodes: int,
    *, source_signal_count: int | None = None, built_episode_count: int | None = None,
) -> CandidateMetrics | None:
    if candidate.sl_pct * candidate.rr_ladder[0] + 1e-12 < policy.modified_stop_profit_pct:
        return None
    rows = []
    replay_errors = 0
    for e in episodes:
        try:
            rows.append(replay_episode(e, candidate, policy))
        except (ValueError, ExecutionModelError):
            replay_errors += 1
    if not rows:
        return None
    try:
        m = summarize_replayed(
            candidate, rows, search_stage=stage, episodes=episodes,
            source_signal_count=source_signal_count if source_signal_count is not None else len(episodes),
            built_episode_count=built_episode_count if built_episode_count is not None else len(episodes),
            replay_error_count=replay_errors,
        )
    except ValueError:
        return None
    # Insufficient completed sample can be inspected but cannot be production-selected.
    if m.episode_count < min_episodes:
        m.production_eligible = False
    return m



def _replay_rows(episodes: list[RawEpisode], cm: CandidateMetrics, policy: ExecutionPolicy):
    c = JointCandidate(cm.offset, cm.sl_pct, cm.rr_ladder)
    out=[]
    for e in episodes:
        try:
            out.append(replay_episode(e,c,policy))
        except (ValueError, ExecutionModelError):
            continue
    return out


def _prefer_lower_sl_if_statistically_equivalent(
    pool: list[CandidateMetrics], best: CandidateMetrics, episodes: list[RawEpisode], policy: ExecutionPolicy,
    *, prefilter_abs_R: float, samples: int, alpha: float,
) -> CandidateMetrics:
    # ``prefilter_abs_R`` is the declared practical-equivalence margin.  The
    # smaller-SL alternative is accepted only if the ENTIRE confidence interval
    # of (best-alt) lies inside ±margin.
    if prefilter_abs_R <= 0:
        return best
    candidates=[
        r for r in pool
        if r.sl_pct < best.sl_pct-1e-12
        and abs(best.equal_symbol_expectancy_R-r.equal_symbol_expectancy_R) <= prefilter_abs_R*2.0+1e-12
    ]
    best_rows=_replay_rows(episodes,best,policy)
    accepted=[]
    for r in candidates:
        alt_rows=_replay_rows(episodes,r,policy)
        ci=paired_equal_symbol_difference_ci(best_rows,alt_rows,samples=samples,alpha=alpha,require_identical_signal_sets=True)
        if ci is None:
            continue
        r.equivalence_vs_best_ci_low_R, r.equivalence_vs_best_ci_high_R = ci
        r.practically_equivalent_to_best = ci_within_practical_equivalence(ci,prefilter_abs_R)
        r.statistically_indistinguishable_from_best = r.practically_equivalent_to_best  # legacy field
        if r.practically_equivalent_to_best:
            accepted.append(r)
    if accepted:
        return min(accepted,key=lambda r:(r.sl_pct,-r.equal_symbol_expectancy_R,r.pool_max_drawdown_R))
    return best

def _valid_ladder(values: tuple[float, ...], s: SearchSettings) -> bool:
    return len(values)==5 and all(s.rr_min-1e-12<=x<=s.rr_max+1e-12 for x in values) and all(b-a+1e-12>=s.rr_min_separation for a,b in zip(values,values[1:]))


def _seed_union(rows: list[CandidateMetrics], n: int) -> list[CandidateMetrics]:
    if not rows: return []
    chosen: dict[str,CandidateMetrics]={}
    for key, reverse in [
        (lambda r:r.equal_symbol_expectancy_R,True),(lambda r:r.positive_symbol_share,True),
        (lambda r:r.pool_expectancy_R_per_episode,True),(lambda r:r.pool_max_drawdown_R,False),
        (lambda r:r.sl_pct,False),
    ]:
        for r in sorted(rows,key=key,reverse=reverse)[:max(1,n//5)]: chosen[r.joint_config_id]=r
    return list(chosen.values())[:max(n,n*2)]


def _refine_seed(
    seed: CandidateMetrics, episodes: list[RawEpisode], s: SearchSettings, policy: ExecutionPolicy, eff_rr_step: float,
    *, source_signal_count: int | None = None, built_episode_count: int | None = None,
) -> list[CandidateMetrics]:
    current=JointCandidate(seed.offset,seed.sl_pct,seed.rr_ladder); rows={}
    for _ in range(s.refinement_passes):
        changed=False
        for dim in range(6):
            cs=[]
            if dim==0:
                for v in float_grid(max(s.sl_min,current.sl_pct-s.sl_coarse_step),min(s.sl_max,current.sl_pct+s.sl_coarse_step),s.sl_refine_step): cs.append(JointCandidate(current.offset,v,current.rr_ladder))
            else:
                idx=dim-1
                for v in float_grid(max(s.rr_min,current.rr_ladder[idx]-eff_rr_step),min(s.rr_max,current.rr_ladder[idx]+eff_rr_step),s.rr_refine_step):
                    rr=list(current.rr_ladder); rr[idx]=v; tup=tuple(rr)
                    if _valid_ladder(tup,s): cs.append(JointCandidate(current.offset,current.sl_pct,tup))
            ev=[]
            for c in cs:
                m=_evaluate_candidate(episodes,c,policy,"REFINE",s.min_episodes,source_signal_count=source_signal_count,built_episode_count=built_episode_count)
                if m is not None: rows[m.joint_config_id]=m; ev.append(m)
            if ev:
                b=max(ev,key=_candidate_sort_key)
                if b.joint_config_id!=current.config_id: current=JointCandidate(b.offset,b.sl_pct,b.rr_ladder); changed=True
        if not changed: break
    return list(rows.values())


def _search_offset_once(
    episodes: list[RawEpisode], settings: SearchSettings, policy: ExecutionPolicy, *,
    legacy_ladder=(0.4,0.7,1.2,2.0,3.0), robustness_cfg: dict|None=None,
    source_signal_count: int | None = None, built_episode_count: int | None = None,
) -> JointSearchResult:
    if not episodes: raise ValueError("episodes empty")
    offsets={e.scenario.offset for e in episodes}
    if len(offsets)!=1: raise ValueError("search_offset requires one fixed Offset")
    offset=next(iter(offsets)); rob=robustness_cfg or {}
    rr_grid,eff_step=adaptive_rr_grid(settings.rr_min,settings.rr_max,settings.rr_coarse_step,max_ladders=settings.max_coarse_ladders_per_sl)
    ladders=legal_ladders(rr_grid,settings.rr_min_separation)
    legacy=tuple(float(x) for x in legacy_ladder)
    if _valid_ladder(legacy,settings) and legacy not in ladders: ladders.append(legacy)
    rows=[]
    for sl in float_grid(settings.sl_min,settings.sl_max,settings.sl_coarse_step):
        for ladder in ladders:
            m=_evaluate_candidate(episodes,JointCandidate(offset,sl,ladder),policy,"COARSE",settings.min_episodes,source_signal_count=source_signal_count,built_episode_count=built_episode_count)
            if m is not None: rows.append(m)
    refined={}
    for seed in _seed_union(rows,settings.refinement_seed_count):
        for r in _refine_seed(seed,episodes,settings,policy,eff_step,source_signal_count=source_signal_count,built_episode_count=built_episode_count): refined[r.joint_config_id]=r
    by={r.joint_config_id:r for r in rows}; by.update(refined); all_rows=list(by.values())
    for r in all_rows: r.pareto_efficient=False
    front=pareto_front(all_rows)
    mark_local_robustness(
        all_rows, sl_radius=max(settings.sl_refine_step,settings.sl_coarse_step), rr_radius=max(settings.rr_refine_step,eff_step),
        min_neighbors=int(rob.get("min_neighbors",2)), min_neighbor_expectancy_ratio=float(rob.get("min_neighbor_expectancy_ratio",0.70)),
        max_neighbor_dd_ratio=float(rob.get("max_neighbor_dd_ratio",1.50)), min_profitable_neighbor_share=float(rob.get("min_profitable_neighbor_share",0.70)),
        min_worst_neighbor_expectancy_R=float(rob.get("min_worst_neighbor_expectancy_R",0.0)),
    )
    min_pos=float(rob.get("min_positive_symbol_share",0.60)); eq=float(rob.get("expectancy_equivalence_abs_R",0.0))
    # First identify the economically strongest candidates without using an arbitrary
    # fixed-tolerance smaller-SL override. Statistical equivalence is assessed below.
    best_research=_select(all_rows,production_only=False,min_positive_symbol_share=min_pos,equivalence_abs_R=0.0)
    best_production=_select(all_rows,production_only=True,min_positive_symbol_share=min_pos,equivalence_abs_R=0.0)
    samples=int(rob.get("equivalence_bootstrap_samples",500)); alpha=float(rob.get("equivalence_alpha",0.05))
    if best_research is not None:
        research_pool=[r for r in all_rows if r.production_eligible or True]
        best_research=_prefer_lower_sl_if_statistically_equivalent(research_pool,best_research,episodes,policy,prefilter_abs_R=eq,samples=samples,alpha=alpha)
    if best_production is not None:
        prod_pool=[r for r in all_rows if r.production_eligible and r.robust and r.pareto_efficient and r.equal_symbol_expectancy_R>0 and r.positive_symbol_share>=min_pos]
        best_production=_prefer_lower_sl_if_statistically_equivalent(prod_pool,best_production,episodes,policy,prefilter_abs_R=eq,samples=samples,alpha=alpha)
    return JointSearchResult(offset,eff_step,all_rows,best_research,best_production,front,sample_status="SUFFICIENT" if len(episodes)>=settings.min_episodes else "INSUFFICIENT")


def _boundary_hits(best: CandidateMetrics|None,s:SearchSettings,tol=1e-9)->list[str]:
    if best is None:return []
    hits=[]
    if abs(best.sl_pct-s.sl_min)<=tol:hits.append("SL_MIN")
    if abs(best.sl_pct-s.sl_max)<=tol:hits.append("SL_MAX")
    if abs(best.rr_ladder[0]-s.rr_min)<=tol:hits.append("RR_MIN")
    if abs(best.rr_ladder[-1]-s.rr_max)<=tol:hits.append("RR_MAX")
    return hits


def _expand_settings(s:SearchSettings,hits:list[str],cfg:dict):
    factor=float(cfg.get("expansion_factor",1.5)); sl_floor=float(cfg.get("sl_floor_pct",0.05)); sl_ceil=float(cfg.get("sl_ceiling_pct",20)); rr_floor=float(cfg.get("rr_floor_R",0.05)); rr_ceil=float(cfg.get("rr_ceiling_R",12)); expand_rr=bool(cfg.get("expand_rr",True))
    a,b,c,d=s.sl_min,s.sl_max,s.rr_min,s.rr_max; applied=[]
    if "SL_MIN" in hits and a>sl_floor+1e-12: a=max(sl_floor,a/factor);applied.append("SL_MIN")
    if "SL_MAX" in hits and b<sl_ceil-1e-12: b=min(sl_ceil,b*factor);applied.append("SL_MAX")
    if expand_rr and "RR_MIN" in hits and c>rr_floor+1e-12:c=max(rr_floor,c/factor);applied.append("RR_MIN")
    if expand_rr and "RR_MAX" in hits and d<rr_ceil-1e-12:d=min(rr_ceil,d*factor);applied.append("RR_MAX")
    return replace(s,sl_min=round(a,10),sl_max=round(b,10),rr_min=round(c,10),rr_max=round(d,10)),applied


def search_offset(
    episodes:list[RawEpisode],settings:SearchSettings,policy:ExecutionPolicy,*,
    legacy_ladder=(0.4,0.7,1.2,2.0,3.0),robustness_cfg:dict|None=None,boundary_cfg:dict|None=None,
    source_signal_count:int|None=None,built_episode_count:int|None=None,
)->JointSearchResult:
    bcfg=boundary_cfg or {}; enabled=bool(bcfg.get("enabled",False)); rounds=int(bcfg.get("max_rounds",0)); current=settings; history=[]; result=None
    for i in range(rounds+1):
        result=_search_offset_once(episodes,current,policy,legacy_ladder=legacy_ladder,robustness_cfg=robustness_cfg,source_signal_count=source_signal_count,built_episode_count=built_episode_count)
        ref=result.best_production or result.best_research; hits=_boundary_hits(ref,current)
        history.append({"round":i,"sl_min":current.sl_min,"sl_max":current.sl_max,"rr_min":current.rr_min,"rr_max":current.rr_max,"best_config_id":ref.joint_config_id if ref else None,"boundary_hits":hits})
        if not enabled or not hits or i>=rounds: break
        nxt,applied=_expand_settings(current,hits,bcfg)
        if not applied:break
        current=nxt
    assert result is not None
    ref=result.best_production or result.best_research; hits=_boundary_hits(ref,current)
    result.boundary_history=history; result.boundary_hit_dimensions=tuple(hits); result.boundary_expansion_rounds=max(0,len(history)-1); result.search_bounds={"sl_min":current.sl_min,"sl_max":current.sl_max,"rr_min":current.rr_min,"rr_max":current.rr_max}
    result.boundary_status="SEARCH_BOUNDARY_HIT_UNRESOLVED" if hits else "SEARCH_BOUNDARY_EXPANDED" if result.boundary_expansion_rounds else "SEARCH_BOUNDS_OK"
    return result

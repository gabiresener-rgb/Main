from __future__ import annotations

from statistics import median

from gst2.domain.models import CandidateMetrics


def mark_local_robustness(
    rows: list[CandidateMetrics], *, sl_radius: float, rr_radius: float,
    min_neighbors: int = 2, min_neighbor_expectancy_ratio: float = 0.70,
    max_neighbor_dd_ratio: float = 1.50, min_profitable_neighbor_share: float = 0.70,
    min_worst_neighbor_expectancy_R: float = 0.0,
) -> None:
    """Require a stable local plateau, not a single spike.

    Production robustness checks median performance, worst neighbor expectancy,
    profitable-neighbor share and worst-neighbor drawdown.
    """
    for r in rows:
        neigh = []
        for o in rows:
            if o is r or o.offset != r.offset:
                continue
            if abs(o.sl_pct - r.sl_pct) > sl_radius + 1e-12:
                continue
            if all(abs(a - b) <= rr_radius + 1e-12 for a, b in zip(o.rr_ladder, r.rr_ladder)):
                neigh.append(o)
        if len(neigh) < min_neighbors:
            r.robust = False; continue
        exps = [x.equal_symbol_expectancy_R for x in neigh]
        dds = [x.pool_max_drawdown_R for x in neigh]
        base_exp = max(abs(r.equal_symbol_expectancy_R), 1e-9)
        median_ok = median(exps) >= r.equal_symbol_expectancy_R - base_exp * (1 - min_neighbor_expectancy_ratio)
        worst_exp = min(exps)
        profitable_share = sum(1 for x in exps if x > 0) / len(exps)
        worst_dd = max(dds)
        base_dd = max(r.pool_max_drawdown_R, 1e-9)
        dd_ok = worst_dd <= base_dd * max_neighbor_dd_ratio
        r.worst_neighbor_expectancy_R = worst_exp
        r.profitable_neighbor_share = profitable_share
        r.worst_neighbor_dd_R = worst_dd
        r.robust = bool(
            median_ok and dd_ok and profitable_share >= min_profitable_neighbor_share
            and worst_exp >= min_worst_neighbor_expectancy_R
        )
        if r.robust:
            r.robust_region_id = f"O{r.offset:+d}_SL{r.sl_pct:.6g}_LOCAL"

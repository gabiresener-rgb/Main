from __future__ import annotations

import csv
import hashlib
import json
from dataclasses import asdict, is_dataclass
from pathlib import Path

import pandas as pd

from gst2.reporting.serialize import to_jsonable, write_json


class ArtifactWriter:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def json(self, rel: str, obj) -> Path:
        p = self.root / rel
        write_json(p, obj)
        return p

    def csv(self, rel: str, rows) -> Path:
        p = self.root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        data = [to_jsonable(r) for r in rows]
        if not data:
            p.write_text("", encoding="utf-8")
            return p
        # Flatten nested RR ladders for practical spreadsheet use.
        flat = []
        for r in data:
            d = dict(r)
            if isinstance(d.get("rr_ladder"), list):
                for i, v in enumerate(d.pop("rr_ladder"), 1):
                    d[f"rr{i}"] = v
            flat.append(d)
        pd.DataFrame(flat).to_csv(p, index=False)
        return p

    def manifest_sha256(self, rel: str = "MANIFEST_SHA256.txt") -> Path:
        p = self.root / rel
        lines = []
        for f in sorted(x for x in self.root.rglob("*") if x.is_file() and x != p):
            h = hashlib.sha256(f.read_bytes()).hexdigest()
            lines.append(f"{h}  {f.relative_to(self.root).as_posix()}")
        p.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return p

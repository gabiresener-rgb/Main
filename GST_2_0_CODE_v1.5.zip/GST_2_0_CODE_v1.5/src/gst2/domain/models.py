from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict, dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class Direction(str, Enum):
    BUY = "BUY"
    SELL = "SELL"

    @property
    def sign(self) -> int:
        return 1 if self is Direction.BUY else -1


class SignalOutcome(str, Enum):
    BAD = "BAD"
    TP1 = "TP1"
    TP2 = "TP2"
    TP3 = "TP3"
    TP4 = "TP4"
    TP5 = "TP5"

    @property
    def level(self) -> int:
        return {"BAD": 0, "TP1": 1, "TP2": 2, "TP3": 3, "TP4": 4, "TP5": 5}[self.value]


class EpisodeStatus(str, Enum):
    COMPLETE = "COMPLETE"
    UNRESOLVED_TIMEOUT = "UNRESOLVED_TIMEOUT"
    INCOMPLETE_DATA = "INCOMPLETE_DATA"
    EXECUTION_INVALID = "EXECUTION_INVALID"


class CloseReason(str, Enum):
    TARGET = "TARGET"
    INITIAL_SL = "INITIAL_SL"
    MODIFIED_SL = "MODIFIED_SL"
    HORIZON = "HORIZON"
    FORCED_EXIT = "FORCED_EXIT"
    DATA_AMBIGUITY = "DATA_AMBIGUITY"
    EXECUTION_INVALID = "EXECUTION_INVALID"


class CausalityStatus(str, Enum):
    STANDARD_CAUSAL = "STANDARD_CAUSAL"
    CAUSAL_PASS = "CAUSAL_PASS"
    CAUSAL_FAIL = "CAUSAL_FAIL"
    NON_CAUSAL_DIAGNOSTIC = "NON_CAUSAL_DIAGNOSTIC"
    NOT_APPLICABLE = "NOT_APPLICABLE"


@dataclass(frozen=True, slots=True)
class MarketPoint:
    ts: datetime
    bid: float
    ask: float

    @property
    def mid(self) -> float:
        return (self.bid + self.ask) / 2.0


@dataclass(frozen=True, slots=True)
class InstrumentSpec:
    symbol: str
    tick_size: float
    stops_level_price: float = 0.0
    freeze_level_price: float = 0.0
    slippage_price: float = 0.0
    commission_per_order_account: float = 0.0
    # Legacy fixed-per-order swap retained for RESEARCH compatibility only.
    swap_per_order_account: float = 0.0
    # Optional time-aware account-currency swap schedule.  Production may use
    # these fields and must still prove broker reconciliation externally.
    swap_long_per_day_account: float = 0.0
    swap_short_per_day_account: float = 0.0
    rollover_hour_utc: int = 0
    triple_swap_weekday: int = 2  # Python weekday: Monday=0, Wednesday=2
    value_per_price_unit_per_unit: float | None = None
    order_units: float | None = None
    account_currency: str = ""
    spec_id: str = ""

    def __post_init__(self) -> None:
        if self.tick_size <= 0:
            raise ValueError("tick_size must be > 0")
        if self.stops_level_price < 0 or self.freeze_level_price < 0 or self.slippage_price < 0:
            raise ValueError("instrument execution distances must be >= 0")
        if self.commission_per_order_account < 0:
            raise ValueError("commission_per_order_account must be >= 0")
        if not 0 <= int(self.rollover_hour_utc) <= 23:
            raise ValueError("rollover_hour_utc must be in 0..23")
        if not 0 <= int(self.triple_swap_weekday) <= 6:
            raise ValueError("triple_swap_weekday must be in 0..6")
        if self.value_per_price_unit_per_unit is not None and self.value_per_price_unit_per_unit <= 0:
            raise ValueError("value_per_price_unit_per_unit must be > 0 when supplied")
        if self.order_units is not None and self.order_units <= 0:
            raise ValueError("order_units must be > 0 when supplied")

    @property
    def fingerprint(self) -> str:
        blob = json.dumps(asdict(self), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
        return hashlib.sha256(blob).hexdigest()


@dataclass(frozen=True, slots=True)
class SignalSeed:
    signal_id: str
    slot_id: str
    asset_group: str
    symbol: str
    timeframe: str
    direction: Direction
    signal_time: datetime
    provider_version: str = ""
    provider_hash: str = ""
    source_channel: str = ""
    offset_semantics_id: str = "canonical_earlier_negative_later_positive_v1"
    metadata: dict[str, Any] = field(default_factory=dict, compare=False, hash=False)


@dataclass(frozen=True, slots=True)
class OffsetScenario:
    signal_id: str
    offset: int
    source_signal_time: datetime
    entry_bar_time: datetime
    candidate_entry_time: datetime
    entry_price: float
    data_cutoff_time: datetime
    causality_status: CausalityStatus
    production_eligible: bool
    causality_evidence_id: str = ""
    causality_evidence_hash: str = ""


@dataclass(frozen=True, slots=True)
class RawEpisode:
    episode_id: str
    seed: SignalSeed
    scenario: OffsetScenario
    horizon_end: datetime
    path: tuple[MarketPoint, ...]
    metadata: dict[str, Any] = field(default_factory=dict, compare=False, hash=False)

    @property
    def entry_price(self) -> float:
        return self.scenario.entry_price

    @property
    def direction(self) -> Direction:
        return self.seed.direction


@dataclass(frozen=True, slots=True)
class JointCandidate:
    offset: int
    sl_pct: float
    rr_ladder: tuple[float, float, float, float, float]

    def __post_init__(self) -> None:
        if self.offset < -5 or self.offset > 5:
            raise ValueError("offset must be in -5..+5")
        if self.sl_pct <= 0:
            raise ValueError("sl_pct must be > 0")
        if len(self.rr_ladder) != 5:
            raise ValueError("exactly five RR targets are required")
        if not all(x > 0 for x in self.rr_ladder):
            raise ValueError("all RR targets must be positive")
        if any(a >= b for a, b in zip(self.rr_ladder, self.rr_ladder[1:])):
            raise ValueError("RR ladder must be strictly increasing")

    @property
    def config_id(self) -> str:
        rr = "_".join(f"{x:.6g}" for x in self.rr_ladder)
        return f"O{self.offset:+d}_SL{self.sl_pct:.6g}_RR{rr}"

    @property
    def tp_pct_ladder(self) -> tuple[float, float, float, float, float]:
        return tuple(round(self.sl_pct * x, 12) for x in self.rr_ladder)


@dataclass(slots=True)
class TradeEvent:
    event_type: str
    ts: datetime
    price: float
    order_index: int | None = None
    level: int | None = None
    pnl_order_R: float | None = None
    pnl_pool_R: float | None = None
    details: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class EpisodeEquityPoint:
    ts: datetime
    pool_R: float
    account_pnl: float | None = None


@dataclass(slots=True)
class ChildOrderResult:
    order_index: int
    target_level: int
    # Nominal configured target values.
    target_R: float
    target_pct: float
    # Executable values after tick normalization.
    effective_target_R: float
    effective_target_pct: float
    target_price: float
    entry_time: datetime
    entry_price: float
    direction: Direction
    weight: float
    close_time: datetime
    close_price: float
    close_reason: CloseReason
    gross_R: float
    cost_R: float
    net_R: float
    initial_risk_account: float | None
    net_pnl_account: float | None
    initial_sl_price: float
    active_sl_price_at_close: float
    instrument_spec_fingerprint: str = ""
    stop_modified: bool = False
    stop_modified_time: datetime | None = None
    modified_stop_price: float | None = None


@dataclass(slots=True)
class OpenOrderMark:
    order_index: int
    target_level: int
    target_R: float
    target_pct: float
    effective_target_R: float
    effective_target_pct: float
    target_price: float
    weight: float
    mark_time: datetime
    mark_price: float
    gross_R: float
    estimated_cost_R: float
    net_R_if_closed: float
    initial_risk_account: float | None
    net_pnl_account_if_closed: float | None
    active_sl_price: float
    stop_modified: bool
    modified_stop_price: float | None


@dataclass(slots=True)
class SignalEpisodeResult:
    episode_id: str
    signal_id: str
    slot_id: str
    asset_group: str
    symbol: str
    timeframe: str
    direction: Direction
    offset: int
    source_signal_time: datetime
    candidate_entry_time: datetime
    data_cutoff_time: datetime
    causality_status: CausalityStatus
    production_eligible: bool
    completion_status: EpisodeStatus
    exclusion_reason: str
    entry_price: float
    sl_pct: float
    effective_sl_pct: float
    initial_sl_price: float
    rr_ladder: tuple[float, float, float, float, float]
    effective_rr_ladder: tuple[float, float, float, float, float]
    tp_pct_ladder: tuple[float, float, float, float, float]
    effective_tp_pct_ladder: tuple[float, float, float, float, float]
    tp_price_ladder: tuple[float, float, float, float, float]
    outcome: SignalOutcome | None
    orders: list[ChildOrderResult]
    open_orders: list[OpenOrderMark]
    events: list[TradeEvent]
    equity_path: list[EpisodeEquityPoint]
    order_weights: tuple[float, float, float, float, float]
    estimated_exit_cost_R_by_order: tuple[float, float, float, float, float]
    instrument_tick_size: float
    instrument_spec_fingerprint: str
    valuation_time: datetime
    valuation_price: float
    pool_realized_order_R_sum: float
    pool_unrealized_order_R_sum: float
    pool_order_R_sum: float
    pool_realized_R: float
    pool_unrealized_R: float
    pool_R: float
    pool_cost_R: float
    pool_realized_pnl_account: float | None
    pool_unrealized_pnl_account: float | None
    pool_net_pnl_account: float | None
    residual_open_weight: float
    residual_risk_R: float
    modified_stop_close_count: int

    @property
    def valid_for_distribution(self) -> bool:
        return self.completion_status is EpisodeStatus.COMPLETE and self.outcome is not None

    @property
    def valid_for_economics(self) -> bool:
        return self.completion_status in {EpisodeStatus.COMPLETE, EpisodeStatus.UNRESOLVED_TIMEOUT} and math.isfinite(self.pool_R)

    @property
    def pool_net_R(self) -> float:
        """Backward-compatible alias: economic pool-R at the episode valuation time."""
        return self.pool_R


@dataclass(slots=True)
class CandidateMetrics:
    joint_config_id: str
    offset: int
    sl_pct: float
    rr_ladder: tuple[float, float, float, float, float]
    production_eligible: bool
    causality_status: CausalityStatus
    # Completed episodes are the denominator for BAD/TP1..TP5 only.
    episode_count: int
    bad_pct: float
    tp1_pct: float
    tp2_pct: float
    tp3_pct: float
    tp4_pct: float
    tp5_pct: float
    # Economics use COMPLETE + UNRESOLVED_TIMEOUT with open positions marked at
    # the last in-window executable quote.
    pool_net_R: float
    pool_expectancy_R_per_episode: float
    profit_factor: float
    pool_max_drawdown_R: float
    max_losing_streak: int
    modified_stop_close_count: int
    modified_stop_net_R: float
    equal_symbol_expectancy_R: float
    positive_symbol_share: float
    high_tp_share_pct: float
    pareto_efficient: bool = False
    robust: bool = False
    robust_region_id: str = ""
    search_stage: str = "COARSE"
    # Full denominator/reconciliation.
    source_signal_count: int = 0
    built_episode_count: int = 0
    replay_result_count: int = 0
    replay_error_count: int = 0
    financial_episode_count: int = 0
    total_episode_count: int = 0  # canonical source-signal denominator
    excluded_episode_count: int = 0
    distribution_excluded_count: int = 0
    builder_excluded_count: int = 0
    unresolved_timeout_count: int = 0
    incomplete_data_count: int = 0
    execution_invalid_count: int = 0
    residual_open_episode_count: int = 0
    residual_open_weight_share: float = 0.0
    realized_pool_R: float = 0.0
    unrealized_pool_R: float = 0.0
    worst_neighbor_expectancy_R: float | None = None
    profitable_neighbor_share: float | None = None
    worst_neighbor_dd_R: float | None = None
    event_chronology_drawdown_R: float | None = None
    account_currency_pnl: float | None = None
    mark_to_market_drawdown_R: float | None = None
    equivalence_vs_best_ci_low_R: float | None = None
    equivalence_vs_best_ci_high_R: float | None = None
    statistically_indistinguishable_from_best: bool = False  # legacy name
    practically_equivalent_to_best: bool = False


@dataclass(frozen=True, slots=True)
class CausalityEvidence:
    slot_id: str
    asset_group: str
    symbol: str
    timeframe: str
    offset: int
    provider_hash: str
    evidence_id: str
    evidence_hash: str
    window_start: datetime
    window_end: datetime
    latest_data_time: datetime
    streaming_replay_pass: bool
    future_mutation_pass: bool
    mtf_cutoff_pass: bool
    provider_semantics_pass: bool
    entry_executability_pass: bool
    data_cutoff_lte_entry: bool
    evidence_path: str = ""
    artifact_hash_verified: bool = False

    @property
    def passed(self) -> bool:
        return bool(self.evidence_id and self.evidence_hash and self.provider_hash and self.artifact_hash_verified) and all((
            self.streaming_replay_pass,
            self.future_mutation_pass,
            self.mtf_cutoff_pass,
            self.provider_semantics_pass,
            self.entry_executability_pass,
            self.data_cutoff_lte_entry,
        ))

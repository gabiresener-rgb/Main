from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from gst2.domain.models import SignalSeed


@dataclass(slots=True)
class AuditIssue:
    severity: str
    code: str
    message: str
    scope: str = "GLOBAL"


@dataclass(slots=True)
class PreGSTAuditReport:
    signal_count: int
    slot_count: int
    scopes: int
    duplicate_signal_ids: int
    issues: list[AuditIssue]

    @property
    def pass_gate(self) -> bool:
        return not any(x.severity == "P0" for x in self.issues)


def run_pre_gst_audit(seeds: list[SignalSeed], bars: pd.DataFrame, ticks: pd.DataFrame, *, production_mode: bool = False) -> PreGSTAuditReport:
    issues: list[AuditIssue] = []
    ids=[s.signal_id for s in seeds]; dup=len(ids)-len(set(ids))
    if dup: issues.append(AuditIssue("P0","DUPLICATE_SIGNAL_ID",f"{dup} duplicate signal ids"))
    valid_groups={"FOREX","COMMODITIES","CRYPTO","INDICES","STOCKS"}
    valid_tfs={"M15","M30","H1","H4","D1","W1"}
    for s in seeds:
        if s.asset_group not in valid_groups: issues.append(AuditIssue("P0","UNKNOWN_ASSET_GROUP",f"{s.signal_id}: {s.asset_group}"))
        if s.timeframe not in valid_tfs: issues.append(AuditIssue("P0","UNSUPPORTED_TIMEFRAME",f"{s.signal_id}: {s.timeframe}"))
        ch=s.source_channel.upper().strip()
        if ch:
            if ch=="BUY_BUFFER" and s.direction.value!="BUY": issues.append(AuditIssue("P0","SOURCE_CHANNEL_DIRECTION_MISMATCH",s.signal_id))
            if ch=="SELL_BUFFER" and s.direction.value!="SELL": issues.append(AuditIssue("P0","SOURCE_CHANNEL_DIRECTION_MISMATCH",s.signal_id))
            if ch not in {"BUY_BUFFER","SELL_BUFFER","DIRECTION_BUFFER"}: issues.append(AuditIssue("P0","INVALID_SOURCE_CHANNEL",f"{s.signal_id}: {ch}"))
        elif production_mode:
            issues.append(AuditIssue("P0","SOURCE_CHANNEL_UNVERIFIED",s.signal_id))
        if production_mode and not s.provider_hash:
            issues.append(AuditIssue("P0","MISSING_PROVIDER_HASH",s.signal_id))
        if s.offset_semantics_id != "canonical_earlier_negative_later_positive_v1":
            issues.append(AuditIssue("P0","NONCANONICAL_OFFSET_SEMANTICS",f"{s.signal_id}: {s.offset_semantics_id}"))
    bar_keys=set(zip(bars["symbol"].astype(str),bars["timeframe"].astype(str))); tick_symbols=set(ticks["symbol"].astype(str))
    # Basic market-data structural checks.
    if ticks[["symbol","timestamp"]].duplicated().any(): issues.append(AuditIssue("P1","DUPLICATE_TICK_TIMESTAMP","duplicate symbol/timestamp rows exist"))
    if bars[["symbol","timeframe","open_time"]].duplicated().any(): issues.append(AuditIssue("P0","DUPLICATE_BAR","duplicate symbol/timeframe/open_time rows exist"))
    if ((bars["high"] < bars[["open","close","low"]].max(axis=1)) | (bars["low"] > bars[["open","close","high"]].min(axis=1))).any():
        issues.append(AuditIssue("P0","INVALID_OHLC","bar OHLC ordering invalid"))
    for scope,group in _scope_groups(seeds).items():
        missing_bars=sorted({s.symbol for s in group if (s.symbol,s.timeframe) not in bar_keys}); missing_ticks=sorted({s.symbol for s in group if s.symbol not in tick_symbols})
        if missing_bars: issues.append(AuditIssue("P0","MISSING_BARS",",".join(missing_bars),scope))
        if missing_ticks: issues.append(AuditIssue("P0","MISSING_TICKS",",".join(missing_ticks),scope))
        for s in group:
            b=bars[(bars.symbol.astype(str)==s.symbol)&(bars.timeframe.astype(str)==s.timeframe)]
            t=ticks[ticks.symbol.astype(str)==s.symbol]
            if not b.empty and pd.Timestamp(s.signal_time) > b.open_time.max(): issues.append(AuditIssue("P0","SIGNAL_AFTER_BAR_HISTORY",s.signal_id,scope))
            if not t.empty and pd.Timestamp(s.signal_time) > t.timestamp.max(): issues.append(AuditIssue("P0","SIGNAL_AFTER_TICK_HISTORY",s.signal_id,scope))
    return PreGSTAuditReport(len(seeds),len({s.slot_id for s in seeds}),len(_scope_groups(seeds)),dup,issues)


def _scope_groups(seeds:list[SignalSeed]):
    out={}
    for s in seeds: out.setdefault(f"{s.slot_id}|{s.asset_group}|{s.timeframe}",[]).append(s)
    return out

from __future__ import annotations

from collections import Counter, defaultdict
from math import inf
from statistics import mean

from gst2.domain.models import CandidateMetrics, EpisodeStatus, JointCandidate, RawEpisode, SignalEpisodeResult, SignalOutcome

OUTCOME_ORDER = [SignalOutcome.BAD, SignalOutcome.TP1, SignalOutcome.TP2, SignalOutcome.TP3, SignalOutcome.TP4, SignalOutcome.TP5]


def max_drawdown(values: list[float]) -> float:
    equity = peak = mdd = 0.0
    for x in values:
        equity += x
        peak = max(peak, equity)
        mdd = max(mdd, peak - equity)
    return mdd


def max_losing_streak(values: list[float]) -> int:
    best = cur = 0
    for x in values:
        if x < 0:
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best


def profit_factor(values: list[float]) -> float:
    gp = sum(x for x in values if x > 0)
    gl = -sum(x for x in values if x < 0)
    if gl <= 1e-15:
        return inf if gp > 0 else 0.0
    return gp / gl


def _distribution_percentages(outcomes: list[SignalOutcome]) -> dict[SignalOutcome, float]:
    n = len(outcomes)
    if n == 0:
        return {o: 0.0 for o in OUTCOME_ORDER}
    c = Counter(outcomes)
    return {o: c[o] / n * 100.0 for o in OUTCOME_ORDER}


def execution_event_drawdown(rows: list[SignalEpisodeResult]) -> float:
    """Realized-close-event drawdown; diagnostic, not a substitute for MTM equity."""
    events: list[tuple] = []
    for r in rows:
        if not r.valid_for_economics:
            continue
        total_weight = sum(r.order_weights) or 1.0
        for o in r.orders:
            events.append((o.close_time, r.episode_id, o.order_index, o.net_R / total_weight))
    events.sort(key=lambda x: (x[0], x[1], x[2]))
    return max_drawdown([x[3] for x in events])


def mark_to_market_drawdown(episodes: list[RawEpisode], rows: list[SignalEpisodeResult]) -> float:
    """Synchronous portfolio MTM drawdown using replay-generated equity paths.

    All episode updates sharing one timestamp are applied as one portfolio state
    before peak/drawdown is evaluated.  This prevents artificial intermediate
    states caused by episode_id ordering.  Unresolved episodes remain marked at
    their final in-window value; no post-horizon information is consumed.
    """
    del episodes  # retained in API for compatibility/audit context
    by_ts: dict[object, dict[str, float]] = defaultdict(dict)
    for r in rows:
        if not r.valid_for_economics:
            continue
        for pt in r.equity_path:
            by_ts[pt.ts][r.episode_id] = float(pt.pool_R)
        if not r.equity_path:
            by_ts[r.valuation_time][r.episode_id] = float(r.pool_R)

    current: dict[str, float] = {}
    total = peak = mdd = 0.0
    for ts in sorted(by_ts):
        # Atomic timestamp update: update every position first.
        for eid, value in by_ts[ts].items():
            current[eid] = value
        total = sum(current.values())
        peak = max(peak, total)
        mdd = max(mdd, peak - total)
    return mdd


def summarize_replayed(
    candidate: JointCandidate,
    rows: list[SignalEpisodeResult],
    search_stage: str = "FINAL",
    episodes: list[RawEpisode] | None = None,
    *,
    source_signal_count: int | None = None,
    built_episode_count: int | None = None,
    replay_error_count: int = 0,
    builder_incomplete_data_count: int = 0,
) -> CandidateMetrics:
    if not rows and replay_error_count <= 0:
        raise ValueError("cannot summarize empty result set")

    completed = [r for r in rows if r.valid_for_distribution]
    economic = [r for r in rows if r.valid_for_economics]
    if not economic:
        raise ValueError("no financially accountable episodes for candidate")

    economic = sorted(economic, key=lambda r: (r.candidate_entry_time, r.signal_id))
    completed = sorted(completed, key=lambda r: (r.candidate_entry_time, r.signal_id))
    outcomes = [r.outcome for r in completed if r.outcome is not None]
    dist = _distribution_percentages(outcomes)

    pool = [r.pool_R for r in economic]
    by_symbol: dict[str, list[float]] = {}
    for r in economic:
        by_symbol.setdefault(r.symbol, []).append(r.pool_R)
    sym_exp = [mean(v) for v in by_symbol.values()]
    equal_symbol = mean(sym_exp) if sym_exp else 0.0
    positive_share = sum(1 for x in sym_exp if x > 0) / len(sym_exp) if sym_exp else 0.0

    status = economic[0].causality_status
    eligible = all(r.production_eligible for r in economic) and replay_error_count == 0
    mod_count = sum(r.modified_stop_close_count for r in economic)
    mod_net = sum(
        o.net_R / max(sum(r.order_weights), 1e-15)
        for r in economic for o in r.orders if o.close_reason.value == "MODIFIED_SL"
    )

    account_vals = [r.pool_net_pnl_account for r in economic]
    account_pnl = sum(float(x) for x in account_vals) if account_vals and all(x is not None for x in account_vals) else None
    cnt = Counter(r.completion_status for r in rows)
    event_dd = execution_event_drawdown(economic)
    mtm_dd = mark_to_market_drawdown(episodes or [], economic)

    src = int(source_signal_count if source_signal_count is not None else len(rows) + replay_error_count)
    built = int(built_episode_count if built_episode_count is not None else len(rows) + replay_error_count)
    replay_count = len(rows)
    financial_count = len(economic)
    builder_excluded = max(0, src - built)
    excluded = max(0, src - financial_count)
    distribution_excluded = max(0, src - len(completed))
    residual_open = [r for r in economic if r.open_orders]
    total_weight = sum(sum(r.order_weights) for r in economic)
    residual_weight = sum(r.residual_open_weight for r in residual_open)

    return CandidateMetrics(
        joint_config_id=candidate.config_id,
        offset=candidate.offset,
        sl_pct=candidate.sl_pct,
        rr_ladder=candidate.rr_ladder,
        production_eligible=eligible,
        causality_status=status,
        episode_count=len(completed),
        bad_pct=dist[SignalOutcome.BAD],
        tp1_pct=dist[SignalOutcome.TP1],
        tp2_pct=dist[SignalOutcome.TP2],
        tp3_pct=dist[SignalOutcome.TP3],
        tp4_pct=dist[SignalOutcome.TP4],
        tp5_pct=dist[SignalOutcome.TP5],
        pool_net_R=sum(pool),
        pool_expectancy_R_per_episode=mean(pool),
        profit_factor=profit_factor(pool),
        pool_max_drawdown_R=mtm_dd,
        max_losing_streak=max_losing_streak(pool),
        modified_stop_close_count=mod_count,
        modified_stop_net_R=mod_net,
        equal_symbol_expectancy_R=equal_symbol,
        positive_symbol_share=positive_share,
        high_tp_share_pct=dist[SignalOutcome.TP4] + dist[SignalOutcome.TP5],
        search_stage=search_stage,
        source_signal_count=src,
        built_episode_count=built,
        replay_result_count=replay_count,
        replay_error_count=int(replay_error_count),
        financial_episode_count=financial_count,
        total_episode_count=src,
        excluded_episode_count=excluded,
        distribution_excluded_count=distribution_excluded,
        builder_excluded_count=builder_excluded,
        unresolved_timeout_count=cnt[EpisodeStatus.UNRESOLVED_TIMEOUT],
        incomplete_data_count=cnt[EpisodeStatus.INCOMPLETE_DATA] + int(builder_incomplete_data_count),
        execution_invalid_count=cnt[EpisodeStatus.EXECUTION_INVALID],
        residual_open_episode_count=len(residual_open),
        residual_open_weight_share=(residual_weight / total_weight if total_weight > 0 else 0.0),
        realized_pool_R=sum(r.pool_realized_R for r in economic),
        unrealized_pool_R=sum(r.pool_unrealized_R for r in economic),
        event_chronology_drawdown_R=event_dd,
        account_currency_pnl=account_pnl,
        mark_to_market_drawdown_R=mtm_dd,
    )


def distribution_sums_to_100(m: CandidateMetrics, tol: float = 1e-8) -> bool:
    if m.episode_count == 0:
        return False
    return abs(m.bad_pct + m.tp1_pct + m.tp2_pct + m.tp3_pct + m.tp4_pct + m.tp5_pct - 100.0) <= tol

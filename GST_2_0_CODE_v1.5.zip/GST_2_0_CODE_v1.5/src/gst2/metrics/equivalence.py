from __future__ import annotations

import random
from math import sqrt
from statistics import mean

from gst2.domain.models import SignalEpisodeResult


def _moving_block_group_indices(n: int, rng: random.Random, block: int) -> list[int]:
    if n <= 0:
        return []
    block = max(1, min(block, n))
    out: list[int] = []
    while len(out) < n:
        start = rng.randrange(n)
        for j in range(block):
            out.append((start + j) % n)
            if len(out) >= n:
                break
    return out


def paired_equal_symbol_difference_ci(
    best_rows: list[SignalEpisodeResult],
    alt_rows: list[SignalEpisodeResult],
    *,
    samples: int = 500,
    alpha: float = 0.05,
    seed: int = 20260925,
    require_identical_signal_sets: bool = True,
) -> tuple[float, float] | None:
    """Paired time-cluster moving-block bootstrap for equal-symbol mean(best-alt).

    Economics include COMPLETE and UNRESOLVED_TIMEOUT rows because unresolved
    positions are marked-to-market instead of silently removed.  The resampling
    unit is a timestamp group, not an independently resampled symbol series, so
    contemporaneous cross-symbol dependence is preserved.  By default the two
    configurations must expose the identical signal-id set; parameter-dependent
    intersections are rejected.
    """
    bm = {r.signal_id: r for r in best_rows if r.valid_for_economics}
    am = {r.signal_id: r for r in alt_rows if r.valid_for_economics}
    if require_identical_signal_sets and set(bm) != set(am):
        return None
    common = set(bm) & set(am)
    if len(common) < 10:
        return None

    grouped: dict[object, list[tuple[str, float]]] = {}
    symbols: set[str] = set()
    for sid in common:
        b, a = bm[sid], am[sid]
        if b.symbol != a.symbol or b.source_signal_time != a.source_signal_time:
            return None
        grouped.setdefault(b.source_signal_time, []).append((b.symbol, b.pool_R - a.pool_R))
        symbols.add(b.symbol)
    times = sorted(grouped)
    if not times or not symbols:
        return None

    rng = random.Random(int(seed))
    target_samples = max(100, int(samples))
    block = max(1, round(sqrt(len(times))))
    stats: list[float] = []
    # Reject bootstrap draws that omit an original symbol.  This keeps the
    # equal-symbol estimand fixed rather than changing the symbol universe.
    max_attempts = target_samples * 20
    attempts = 0
    while len(stats) < target_samples and attempts < max_attempts:
        attempts += 1
        values_by_symbol: dict[str, list[float]] = {s: [] for s in symbols}
        for idx in _moving_block_group_indices(len(times), rng, block):
            for symbol, diff in grouped[times[idx]]:
                values_by_symbol[symbol].append(diff)
        if any(not v for v in values_by_symbol.values()):
            continue
        stats.append(mean(mean(v) for v in values_by_symbol.values()))

    if len(stats) < 100:
        return None
    stats.sort()
    n = len(stats)
    lo = max(0, min(n - 1, int((alpha / 2) * n)))
    hi = max(0, min(n - 1, int((1 - alpha / 2) * n) - 1))
    return float(stats[lo]), float(stats[hi])


def ci_within_practical_equivalence(ci: tuple[float, float] | None, margin_abs_R: float) -> bool:
    """CI-based practical equivalence: the whole CI lies inside ±margin."""
    if ci is None or margin_abs_R <= 0:
        return False
    lo, hi = ci
    return lo >= -margin_abs_R - 1e-12 and hi <= margin_abs_R + 1e-12

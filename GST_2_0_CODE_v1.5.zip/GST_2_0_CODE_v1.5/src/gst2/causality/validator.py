from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

import pandas as pd

from gst2.domain.models import CausalityEvidence, CausalityStatus, SignalSeed


@dataclass(frozen=True, slots=True)
class CausalityDecision:
    status: CausalityStatus
    production_eligible: bool
    evidence_id: str = ""
    evidence_hash: str = ""
    latest_data_time: datetime | None = None
    reasons: tuple[str, ...] = ()


def _utc(v) -> datetime:
    ts = pd.Timestamp(v)
    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")
    else:
        ts = ts.tz_convert("UTC")
    return ts.to_pydatetime()


class NegativeOffsetCausalityValidator:
    """Strict causality gate.

    Offset semantics are canonical and immutable: negative=earlier, zero=source,
    positive=later. Negative offsets require provider-specific evidence bound to
    slot+symbol+TF+provider_hash+offset+time window. GST verifies provenance and
    timing; it does not pretend to reconstruct an unavailable indicator formula.
    """

    def __init__(self, evidence: Iterable[CausalityEvidence] = (), evidence_file_hash: str = "") -> None:
        self.evidence_file_hash = evidence_file_hash
        self._rows = list(evidence)

    def classify(self, seed: SignalSeed, offset: int, candidate_entry_time: datetime | None = None) -> CausalityDecision:
        if offset < -5 or offset > 5:
            return CausalityDecision(CausalityStatus.CAUSAL_FAIL, False, reasons=("offset outside -5..+5",))
        if candidate_entry_time is not None:
            if offset < 0 and not (candidate_entry_time < seed.signal_time):
                return CausalityDecision(CausalityStatus.CAUSAL_FAIL, False, reasons=("negative offset did not enter earlier than source signal",))
            if offset == 0 and candidate_entry_time < seed.signal_time:
                return CausalityDecision(CausalityStatus.CAUSAL_FAIL, False, reasons=("offset 0 entered before source signal availability",))
            if offset > 0 and not (candidate_entry_time > seed.signal_time):
                return CausalityDecision(CausalityStatus.CAUSAL_FAIL, False, reasons=("positive offset did not enter later than source signal",))
        if offset >= 0:
            return CausalityDecision(CausalityStatus.STANDARD_CAUSAL, True, latest_data_time=seed.signal_time)

        matches = []
        for e in self._rows:
            if (
                e.slot_id == str(seed.slot_id)
                and e.asset_group == str(seed.asset_group)
                and e.symbol == str(seed.symbol)
                and e.timeframe == str(seed.timeframe)
                and e.offset == int(offset)
                and e.provider_hash == str(seed.provider_hash)
                and e.window_start <= seed.signal_time <= e.window_end
            ):
                matches.append(e)
        if not matches:
            return CausalityDecision(CausalityStatus.NON_CAUSAL_DIAGNOSTIC, False, reasons=("missing provenance-bound provider causality evidence",))
        # Prefer the narrowest/latest matching evidence window deterministically.
        e = sorted(matches, key=lambda x: (x.window_end - x.window_start, x.window_end, x.evidence_id))[0]
        if not e.passed:
            failed = [name for name in (
                "streaming_replay_pass", "future_mutation_pass", "mtf_cutoff_pass",
                "provider_semantics_pass", "entry_executability_pass", "data_cutoff_lte_entry",
            ) if not getattr(e, name)]
            return CausalityDecision(CausalityStatus.CAUSAL_FAIL, False, e.evidence_id, e.evidence_hash, e.latest_data_time, tuple(failed))
        if candidate_entry_time is not None and e.latest_data_time > candidate_entry_time:
            return CausalityDecision(CausalityStatus.CAUSAL_FAIL, False, e.evidence_id, e.evidence_hash, e.latest_data_time, ("evidence latest_data_time exceeds candidate entry",))
        return CausalityDecision(CausalityStatus.CAUSAL_PASS, True, e.evidence_id, e.evidence_hash, e.latest_data_time)


def _bool(v) -> bool:
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in {"1", "true", "yes", "y", "pass", "passed"}


def load_causality_evidence(path: str | None) -> tuple[list[CausalityEvidence], str]:
    if not path:
        return [], ""
    p = Path(path)
    file_hash = hashlib.sha256(p.read_bytes()).hexdigest()
    if p.suffix.lower() == ".json":
        raw = json.loads(p.read_text(encoding="utf-8"))
        rows = raw if isinstance(raw, list) else raw.get("rows", [])
    else:
        rows = pd.read_csv(p).to_dict(orient="records")
    out = []
    required = {"slot_id","asset_group","symbol","timeframe","offset","provider_hash","evidence_id","evidence_hash","evidence_path","window_start","window_end","latest_data_time"}
    for r in rows:
        missing = [k for k in required if str(r.get(k, "")).strip() == ""]
        if missing:
            raise ValueError(f"causality evidence row missing mandatory provenance fields: {missing}")
        ep=Path(str(r["evidence_path"]))
        if not ep.is_absolute(): ep=(p.parent/ep).resolve()
        verified=ep.exists() and hashlib.sha256(ep.read_bytes()).hexdigest().lower()==str(r["evidence_hash"]).lower()
        out.append(CausalityEvidence(
            slot_id=str(r["slot_id"]), asset_group=str(r["asset_group"]), symbol=str(r["symbol"]),
            timeframe=str(r["timeframe"]), offset=int(r["offset"]), provider_hash=str(r["provider_hash"]),
            evidence_id=str(r["evidence_id"]), evidence_hash=str(r["evidence_hash"]),
            window_start=_utc(r["window_start"]), window_end=_utc(r["window_end"]), latest_data_time=_utc(r["latest_data_time"]),
            streaming_replay_pass=_bool(r.get("streaming_replay_pass", False)),
            future_mutation_pass=_bool(r.get("future_mutation_pass", False)),
            mtf_cutoff_pass=_bool(r.get("mtf_cutoff_pass", False)),
            provider_semantics_pass=_bool(r.get("provider_semantics_pass", False)),
            entry_executability_pass=_bool(r.get("entry_executability_pass", False)),
            data_cutoff_lte_entry=_bool(r.get("data_cutoff_lte_entry", False)),
            evidence_path=str(ep), artifact_hash_verified=verified,
        ))
    return out, file_hash

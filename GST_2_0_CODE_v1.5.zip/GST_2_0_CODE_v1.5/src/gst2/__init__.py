"""GST 2.0 audited canonical engine (spec v1.6.0)."""
__version__ = "1.5.0"
SPEC_VERSION = "1.6.0"

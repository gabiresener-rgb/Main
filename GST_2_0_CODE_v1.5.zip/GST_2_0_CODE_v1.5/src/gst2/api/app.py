from __future__ import annotations

from fastapi import FastAPI
from pydantic import BaseModel

from gst2 import SPEC_VERSION, __version__
from gst2.service import run_from_files

app = FastAPI(title="GST 2.0 API", version=__version__)


class RunRequest(BaseModel):
    signals: str
    bars: str
    ticks: str
    config: str
    out: str
    causality_evidence: str | None = None


@app.get("/health")
def health():
    return {"status": "ok", "code_version": __version__, "spec_version": SPEC_VERSION}


@app.post("/runs")
def run(req: RunRequest):
    return run_from_files(**req.model_dump())

from __future__ import annotations

import copy
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

CANONICAL_TIMEFRAMES: tuple[str, ...] = ("M15", "M30", "H1", "H4", "D1", "W1")
CANONICAL_ASSET_GROUPS: tuple[str, ...] = ("FOREX", "COMMODITIES", "CRYPTO", "INDICES", "STOCKS")

# These are SEARCH BOUNDS, not recommended trading stops.  The optimizer may
# expand them automatically when the selected candidate touches a boundary.
# Values are percentage points of entry price (e.g. 0.40 means 0.40%).
_SL_SCOPE_TABLE: dict[str, dict[str, tuple[float, float, float, float]]] = {
    "FOREX": {
        "M15": (0.10, 0.80, 0.05, 0.01), "M30": (0.10, 1.00, 0.05, 0.01),
        "H1": (0.15, 1.25, 0.05, 0.01), "H4": (0.20, 2.00, 0.10, 0.02),
        "D1": (0.30, 3.00, 0.10, 0.05), "W1": (0.50, 5.00, 0.25, 0.05),
    },
    "COMMODITIES": {
        "M15": (0.15, 1.00, 0.05, 0.01), "M30": (0.15, 1.25, 0.05, 0.01),
        "H1": (0.20, 1.75, 0.05, 0.01), "H4": (0.30, 2.50, 0.10, 0.02),
        "D1": (0.50, 4.00, 0.20, 0.05), "W1": (0.75, 6.00, 0.25, 0.05),
    },
    "CRYPTO": {
        "M15": (0.20, 2.00, 0.10, 0.02), "M30": (0.25, 2.50, 0.10, 0.02),
        "H1": (0.30, 3.00, 0.10, 0.02), "H4": (0.50, 5.00, 0.25, 0.05),
        "D1": (0.75, 8.00, 0.25, 0.10), "W1": (1.00, 12.00, 0.50, 0.10),
    },
    "INDICES": {
        "M15": (0.15, 1.00, 0.05, 0.01), "M30": (0.15, 1.25, 0.05, 0.01),
        "H1": (0.20, 1.75, 0.05, 0.01), "H4": (0.30, 2.50, 0.10, 0.02),
        "D1": (0.50, 4.00, 0.20, 0.05), "W1": (0.75, 6.00, 0.25, 0.05),
    },
    "STOCKS": {
        "M15": (0.20, 1.50, 0.05, 0.01), "M30": (0.20, 1.75, 0.05, 0.01),
        "H1": (0.25, 2.50, 0.10, 0.02), "H4": (0.40, 4.00, 0.20, 0.05),
        "D1": (0.75, 6.00, 0.25, 0.05), "W1": (1.00, 10.00, 0.50, 0.10),
    },
}


def _default_scope_overrides() -> dict[str, dict[str, dict[str, float]]]:
    out: dict[str, dict[str, dict[str, float]]] = {}
    for group, by_tf in _SL_SCOPE_TABLE.items():
        for tf, (mn, mx, coarse, refine) in by_tf.items():
            out[f"{group}:{tf}"] = {"sl": {
                "min_pct": mn, "max_pct": mx,
                "coarse_step_pct": coarse, "refine_step_pct": refine,
            }}
    return out

import yaml


@dataclass(frozen=True, slots=True)
class SearchSettings:
    sl_min: float
    sl_max: float
    sl_coarse_step: float
    sl_refine_step: float
    rr_min: float
    rr_max: float
    rr_coarse_step: float
    rr_refine_step: float
    rr_min_separation: float
    max_coarse_ladders_per_sl: int = 3000
    refinement_seed_count: int = 12
    refinement_passes: int = 2
    min_episodes: int = 20


DEFAULT_CONFIG: dict[str, Any] = {
    "schema_version": "1.6.0",
    "run_mode": "RESEARCH",
    "scope": {"slots": [], "asset_groups": [], "timeframes": list(CANONICAL_TIMEFRAMES), "symbols": []},
    "offset_search": {
        "full_sweep_min": -5, "full_sweep_max": 5, "full_sweep_step": 1,
        "causality_evidence": None,
    },
    "joint_search": {
        "sl": {"min_pct": 0.20, "max_pct": 1.00, "coarse_step_pct": 0.05, "refine_step_pct": 0.01},
        "rr_ladder": {
            "min_R": 0.20, "max_R": 6.0, "coarse_step_R": 0.20, "refine_step_R": 0.05,
            "min_separation_R": 0.10, "legacy_ladder_R": [0.4, 0.7, 1.2, 2.0, 3.0],
        },
        "max_coarse_ladders_per_sl": 3000,
        "refinement_seed_count": 12,
        "refinement_passes": 2,
        "min_episodes": 30,
        "scope_overrides": _default_scope_overrides(),
        "boundary_expansion": {
            "enabled": True,
            "max_rounds": 3,
            "expansion_factor": 1.50,
            "sl_floor_pct": 0.05,
            "sl_ceiling_pct": 20.0,
            "rr_floor_R": 0.05,
            "rr_ceiling_R": 12.0,
            "expand_rr": True,
            "fail_if_unresolved": True,
        },
    },
    "execution_policy": {
        "order_weights": [1, 1, 1, 1, 1],
        "modified_stop_profit_pct": 0.10,
        "cost_R_per_weight": 0.0,
        "fill_model": "FIRST_EXECUTABLE_QUOTE",
        "require_instrument_specs": False,
        "require_account_economics": False,
        "instrument_specs_csv": None,
        "default_tick_size": 0.00001,
        "observation_horizon_bars": {"default": 48},
    },
    "validation": {
        "final_holdout_fraction": 0.20,
        "selection_oos_fraction": 0.15,
        "selection_candidates_per_offset": 5,
        "walk_forward": {"enabled": True, "folds": 4, "min_train_fraction": 0.40, "min_positive_fold_share": 0.75, "require_positive_aggregate_oos": True},
        "robustness": {
            "min_neighbors": 3,
            "min_neighbor_expectancy_ratio": 0.70,
            "max_neighbor_dd_ratio": 1.50,
            "min_profitable_neighbor_share": 0.70,
            "min_worst_neighbor_expectancy_R": 0.0,
            "min_positive_symbol_share": 0.60,
            "expectancy_equivalence_abs_R": 0.10,
            "equivalence_bootstrap_samples": 500,
            "equivalence_alpha": 0.05,
        },
        "external_evidence": {
            "provider_equivalence_csv": None,
            "execution_reconciliation_json": None,
            "min_matched_trade_count": 1,
            "max_price_error_ticks": 0.0,
            "max_time_error_seconds": 0.0,
            "max_account_pnl_error": None,
        },
        "production_gates": {
            "require_walk_forward": True,
            "require_holdout": True,
            "require_robust": True,
            "require_cross_symbol": True,
            "require_boundary_resolved": True,
            "require_zero_execution_invalid": True,
            "require_zero_replay_errors": True,
            "max_excluded_episode_share": 0.20,
            "max_unresolved_episode_share": 0.20
        },
    },
    "input_validation": {"slot_registry_csv": None, "allow_non_mt5_input": True},
    "storage": {"persist_full_surface": True},
}


def deep_merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def load_config(path: str) -> dict:
    raw = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
    cfg = deep_merge(DEFAULT_CONFIG, raw)
    if str(cfg.get("run_mode", "RESEARCH")).upper() == "PRODUCTION" and isinstance(raw.get("execution_policy"), dict) and "observation_horizon_bars" in raw["execution_policy"]:
        # Do not inherit the research-only default horizon into production.
        cfg["execution_policy"]["observation_horizon_bars"] = copy.deepcopy(raw["execution_policy"]["observation_horizon_bars"])
    if str(cfg.get("run_mode", "RESEARCH")).upper() == "PRODUCTION":
        # Production must be an explicit user configuration, never silently inherited defaults.
        required_paths = [
            ("joint_search", "scope_overrides"),
            ("execution_policy", "observation_horizon_bars"),
            ("execution_policy", "instrument_specs_csv"),
            ("validation", "final_holdout_fraction"),
            ("validation", "selection_oos_fraction"),
            ("validation", "external_evidence"),
            ("validation", "production_gates"),
        ]
        missing=[]
        for a,b in required_paths:
            if not isinstance(raw.get(a), dict) or b not in raw[a]: missing.append(f"{a}.{b}")
        if missing:
            raise ValueError(f"PRODUCTION config must explicitly set: {missing}")
    validate_config(cfg)
    return cfg


def validate_config(cfg: dict) -> None:
    mode = str(cfg.get("run_mode", "RESEARCH")).upper()
    if mode not in {"RESEARCH", "PRODUCTION"}:
        raise ValueError("run_mode must be RESEARCH or PRODUCTION")
    cfg["run_mode"] = mode
    scope = cfg.get("scope", {})
    raw_tfs = [str(x).upper() for x in scope.get("timeframes", [])]
    if not raw_tfs:
        raw_tfs = list(CANONICAL_TIMEFRAMES)
        scope["timeframes"] = raw_tfs
    unknown_tfs = sorted(set(raw_tfs) - set(CANONICAL_TIMEFRAMES))
    if unknown_tfs:
        raise ValueError(f"unsupported timeframe(s): {unknown_tfs}; allowed: {list(CANONICAL_TIMEFRAMES)}")
    if len(raw_tfs) != len(set(raw_tfs)):
        raise ValueError("scope.timeframes contains duplicates")

    off = cfg["offset_search"]
    values = list(range(int(off["full_sweep_min"]), int(off["full_sweep_max"]) + 1, int(off["full_sweep_step"])))
    if values != list(range(-5, 6)):
        raise ValueError("production full sweep must be exactly -5..+5")
    if "positive_offset_is_later" in off and off.get("positive_offset_is_later") is not True:
        raise ValueError("offset semantics are fixed: negative=earlier, positive=later")
    ep = cfg["execution_policy"]
    if len(ep.get("order_weights", [])) != 5:
        raise ValueError("execution_policy.order_weights must contain exactly five values")
    if ep.get("fill_model") not in {"FIRST_EXECUTABLE_QUOTE", "IDEAL_LEVEL_FILL"}:
        raise ValueError("execution_policy.fill_model invalid")
    horizon = ep.get("observation_horizon_bars", {})
    if not isinstance(horizon, dict):
        raise ValueError("execution_policy.observation_horizon_bars must be a mapping")
    def _horizon_int(key: str) -> int:
        value = horizon.get(key, 0)
        try:
            return int(value or 0)
        except (TypeError, ValueError):
            return 0
    if mode == "PRODUCTION":
        missing_h = [tf for tf in CANONICAL_TIMEFRAMES if tf not in horizon]
        if missing_h:
            raise ValueError(f"PRODUCTION requires explicit observation_horizon_bars for every TF: {missing_h}")
        bad_h = [tf for tf in CANONICAL_TIMEFRAMES if _horizon_int(tf) < 1]
        if bad_h:
            raise ValueError(
                "PRODUCTION observation_horizon_bars must be explicitly set to the real validated observation/EA rule "
                f"for every TF; unresolved TFs: {bad_h}"
            )
        if "default" in horizon:
            raise ValueError("PRODUCTION must not use observation_horizon_bars.default; configure each TF explicitly")
    else:
        has_default = _horizon_int("default") >= 1
        has_all = all(_horizon_int(tf) >= 1 for tf in CANONICAL_TIMEFRAMES)
        if not (has_default or has_all):
            raise ValueError("RESEARCH requires observation_horizon_bars.default>=1 or explicit values for all TFs")
    js = cfg["joint_search"]
    if js["sl"]["min_pct"] <= 0 or js["sl"]["max_pct"] < js["sl"]["min_pct"]:
        raise ValueError("invalid SL bounds")
    rr = js["rr_ladder"]
    if rr["min_R"] <= 0 or rr["max_R"] <= rr["min_R"]:
        raise ValueError("invalid RR bounds")
    if rr["min_separation_R"] <= 0:
        raise ValueError("min RR separation must be > 0")

    overrides = js.get("scope_overrides", {})
    required = {f"{g}:{tf}" for g in CANONICAL_ASSET_GROUPS for tf in CANONICAL_TIMEFRAMES}
    missing = sorted(required - set(overrides))
    if missing:
        raise ValueError(f"missing mandatory AssetGroup:TF SL scope overrides: {missing}")
    unknown = sorted(set(overrides) - required)
    if unknown:
        raise ValueError(f"unknown AssetGroup:TF scope overrides: {unknown}")
    for key in sorted(required):
        sl_ov = overrides[key].get("sl", {})
        mn = float(sl_ov.get("min_pct", js["sl"]["min_pct"]))
        mx = float(sl_ov.get("max_pct", js["sl"]["max_pct"]))
        coarse = float(sl_ov.get("coarse_step_pct", js["sl"]["coarse_step_pct"]))
        refine = float(sl_ov.get("refine_step_pct", js["sl"]["refine_step_pct"]))
        if mn <= 0 or mx <= mn or coarse <= 0 or refine <= 0:
            raise ValueError(f"invalid SL scope override for {key}")

    sel_frac = float(cfg.get("validation", {}).get("selection_oos_fraction", 0.0))
    if not 0 < sel_frac < 0.5:
        raise ValueError("validation.selection_oos_fraction must be in (0,0.5)")
    if mode == "PRODUCTION":
        if not bool(cfg.get("validation", {}).get("walk_forward", {}).get("enabled", False)):
            raise ValueError("PRODUCTION requires walk_forward.enabled=true")
        if float(cfg.get("validation", {}).get("final_holdout_fraction", 0)) <= 0:
            raise ValueError("PRODUCTION requires a non-zero final holdout")
        if ep.get("fill_model") != "FIRST_EXECUTABLE_QUOTE":
            raise ValueError("PRODUCTION requires FIRST_EXECUTABLE_QUOTE fill_model")
        if not bool(ep.get("require_instrument_specs", False)) or not ep.get("instrument_specs_csv"):
            raise ValueError("PRODUCTION requires instrument_specs_csv and require_instrument_specs=true")
        if not bool(ep.get("require_account_economics", False)):
            raise ValueError("PRODUCTION requires require_account_economics=true")
        if not cfg.get("input_validation", {}).get("slot_registry_csv"):
            raise ValueError("PRODUCTION requires input_validation.slot_registry_csv with real enabled provider mappings")
        ext=cfg.get("validation",{}).get("external_evidence",{})
        if not ext.get("provider_equivalence_csv") or not ext.get("execution_reconciliation_json"):
            raise ValueError("PRODUCTION requires provider_equivalence_csv and execution_reconciliation_json evidence")
        if int(ext.get("min_matched_trade_count",0)) < 1:
            raise ValueError("PRODUCTION execution reconciliation requires min_matched_trade_count >= 1")
        for key in ("max_price_error_ticks","max_time_error_seconds"):
            try:
                v=float(ext.get(key))
            except (TypeError,ValueError) as exc:
                raise ValueError(f"PRODUCTION external_evidence.{key} must be explicit numeric") from exc
            if v < 0:
                raise ValueError(f"PRODUCTION external_evidence.{key} must be >= 0")
        if ext.get("max_account_pnl_error") is None:
            raise ValueError("PRODUCTION requires explicit external_evidence.max_account_pnl_error")
        if float(ext.get("max_account_pnl_error")) < 0:
            raise ValueError("PRODUCTION external_evidence.max_account_pnl_error must be >= 0")
        gates=cfg.get("validation",{}).get("production_gates",{})
        mandatory=(
            "require_walk_forward","require_holdout","require_robust","require_cross_symbol",
            "require_boundary_resolved","require_zero_execution_invalid","require_zero_replay_errors",
        )
        disabled=[k for k in mandatory if gates.get(k) is not True]
        if disabled:
            raise ValueError(f"PRODUCTION cannot disable mandatory gates: {disabled}")
        for key in ("max_excluded_episode_share","max_unresolved_episode_share"):
            try:
                v=float(gates.get(key))
            except (TypeError,ValueError) as exc:
                raise ValueError(f"PRODUCTION production_gates.{key} must be explicit numeric") from exc
            if not 0 <= v <= 1:
                raise ValueError(f"PRODUCTION production_gates.{key} must be in [0,1]")
    b = js.get("boundary_expansion", {})
    if int(b.get("max_rounds", 0)) < 0:
        raise ValueError("boundary_expansion.max_rounds must be >= 0")
    if float(b.get("expansion_factor", 1.0)) <= 1.0:
        raise ValueError("boundary_expansion.expansion_factor must be > 1")
    if float(b.get("sl_floor_pct", 0)) <= 0 or float(b.get("sl_ceiling_pct", 0)) <= float(b.get("sl_floor_pct", 0)):
        raise ValueError("invalid boundary expansion SL floor/ceiling")
    if float(b.get("rr_floor_R", 0)) <= 0 or float(b.get("rr_ceiling_R", 0)) <= float(b.get("rr_floor_R", 0)):
        raise ValueError("invalid boundary expansion RR floor/ceiling")


def scope_search_settings(cfg: dict, asset_group: str, timeframe: str) -> SearchSettings:
    js = copy.deepcopy(cfg["joint_search"])
    group = str(asset_group).upper()
    tf = str(timeframe).upper()
    key = f"{group}:{tf}"
    if group not in CANONICAL_ASSET_GROUPS:
        raise ValueError(f"unsupported asset group {asset_group!r}; allowed: {list(CANONICAL_ASSET_GROUPS)}")
    if tf not in CANONICAL_TIMEFRAMES:
        raise ValueError(f"unsupported timeframe {timeframe!r}; allowed: {list(CANONICAL_TIMEFRAMES)}")
    ov = js.get("scope_overrides", {}).get(key, {})
    if ov:
        js = deep_merge(js, ov)
    sl = js["sl"]
    rr = js["rr_ladder"]
    return SearchSettings(
        sl_min=float(sl["min_pct"]), sl_max=float(sl["max_pct"]),
        sl_coarse_step=float(sl["coarse_step_pct"]), sl_refine_step=float(sl["refine_step_pct"]),
        rr_min=float(rr["min_R"]), rr_max=float(rr["max_R"]),
        rr_coarse_step=float(rr["coarse_step_R"]), rr_refine_step=float(rr["refine_step_R"]),
        rr_min_separation=float(rr["min_separation_R"]),
        max_coarse_ladders_per_sl=int(js.get("max_coarse_ladders_per_sl", 3000)),
        refinement_seed_count=int(js.get("refinement_seed_count", 12)),
        refinement_passes=int(js.get("refinement_passes", 2)),
        min_episodes=int(js.get("min_episodes", 20)),
    )


def config_hash(cfg: dict) -> str:
    blob = json.dumps(cfg, sort_keys=True, separators=(",", ":"), default=str).encode()
    return hashlib.sha256(blob).hexdigest()
